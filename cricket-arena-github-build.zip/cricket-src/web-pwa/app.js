import {
  deleteRecord,
  exportFullArenaBackup,
  exportPersonalBackup,
  getAll,
  getById,
  getMeta,
  hashSecret,
  putRecord,
  restoreFullArenaBackup,
  restorePersonalBackup,
  setMeta,
  validateFullBackupJson,
  verifySecret
} from "./db.js";
import {
  CRICKET_FORMATS,
  calculateTournamentStandings,
  computePlayerStatisticsAndLeaderboards,
  generateMatchShareSummary,
  generateNextKnockoutRound,
  generateTournamentFixtures,
  getFormatConfig,
  recalculateMatch
} from "./engine.js";

const MAJOR_LEAGUES = [
  "IPL", "BPL", "BBL", "PSL", "CPL", "LPL", "SA20", "ILT20",
  "Global T20 Canada", "Canada 60", "European Cricket League",
  "The Hundred", "T20 Blast", "Super Smash", "Abu Dhabi T10"
];

const STRINGS = {
  en: {
    home: "Home",
    matches: "Matches",
    teams: "Teams",
    tournaments: "Tournaments",
    profile: "Profile",
    stats: "Statistics",
    backup: "Backup",
    personalPanel: "Personal Control Panel",
    createMatch: "Create Match",
    createTournament: "Create Tournament",
    offlineReady: "Offline Ready",
    offlineMode: "Offline Mode"
  },
  bn: {
    home: "হোম",
    matches: "ম্যাচ",
    teams: "দল",
    tournaments: "টুর্নামেন্ট",
    profile: "প্রোফাইল",
    stats: "পরিসংখ্যান",
    backup: "ব্যাকআপ",
    personalPanel: "পার্সোনাল কন্ট্রোল প্যানেল",
    createMatch: "ম্যাচ তৈরি",
    createTournament: "টুর্নামেন্ট তৈরি",
    offlineReady: "অফলাইন প্রস্তুত",
    offlineMode: "অফলাইন মোড"
  }
};

const state = {
  route: "home",
  teams: [],
  players: [],
  matches: [],
  tournaments: [],
  activeUser: null,
  activeSettings: null,
  activeFavourites: [],
  selectedTeamId: null,
  editingTeamId: null,
  editingPlayerId: null,
  teamSearch: "",
  selectedMatchId: null,
  matchTab: "live", // live | scorecard | details
  scorerPanel: null, // null | { type: "WICKET" } | { type: "EXTRA", extraType: "WIDE"|"NO_BALL"|"BYE"|"LEG_BYE" } | { type: "END_CONFIRM" }
  swapStrikeActive: false,
  selectedTournamentId: null,
  editingTournamentId: null,
  selectedGroupFilter: "ALL",
  editingFixtureId: null,
  recordingFixtureId: null,
  selectedPlayerName: null,
  statsFilter: { format: "ALL", tournamentId: "ALL", teamName: "ALL", dateFrom: "", dateTo: "" },
  leaderboardKey: "mostRuns",
  authTab: "login",
  deferredInstallPrompt: null,
  swReady: false,
  online: navigator.onLine
};

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function uid(prefix = "id") {
  if (crypto.randomUUID) return `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

function t() {
  const lang = state.activeSettings?.languageCode === "bn" ? "bn" : "en";
  return STRINGS[lang];
}

function showToast(msg) {
  const region = document.getElementById("toast-region");
  if (!region) return;
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  region.innerHTML = "";
  region.appendChild(el);
  setTimeout(() => {
    if (el.parentNode) el.remove();
  }, 3400);
}

async function readImageAsDataUrl(file) {
  if (!file) return null;
  if (file.size > 2 * 1024 * 1024) {
    throw new Error("Please select an image smaller than 2 MB.");
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Failed to read image."));
    reader.readAsDataURL(file);
  });
}

function updateThemeAndMetadata() {
  const theme = state.activeSettings?.themeMode === "LIGHT" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", theme);
  document.documentElement.lang = state.activeSettings?.languageCode === "bn" ? "bn" : "en";

  const titles = {
    home: "Home — Cricket Arena",
    matches: "Matches & Live Scoring — Cricket Arena",
    teams: "Team & Player Management — Cricket Arena",
    tournaments: "Tournaments & Points Table — Cricket Arena",
    stats: "Player Statistics & Leaderboards — Cricket Arena",
    account: "Profile & Personal Control Panel — Cricket Arena",
    backup: "Offline Storage, Backup & Restore — Cricket Arena"
  };
  document.title = titles[state.route] || "Cricket Arena";
}

function updateOfflineIndicator() {
  const pill = document.getElementById("offline-pill");
  const text = document.getElementById("offline-pill-text");
  const banner = document.getElementById("offline-banner");
  const labels = t();

  if (!pill || !text || !banner) return;
  if (!state.online) {
    pill.classList.add("is-offline");
    text.textContent = `${labels.offlineMode} • IndexedDB`;
    banner.classList.remove("hidden");
  } else {
    pill.classList.remove("is-offline");
    text.textContent = state.swReady ? `${labels.offlineReady} • Cached` : "Online • Local DB";
    banner.classList.add("hidden");
  }
}

function renderNavigation() {
  const labels = t();
  const bottomItems = [
    { id: "home", label: labels.home, icon: "🏏" },
    { id: "matches", label: labels.matches, icon: "⚡" },
    { id: "teams", label: labels.teams, icon: "🛡️" },
    { id: "tournaments", label: labels.tournaments, icon: "🏆" },
    { id: "account", label: labels.profile, icon: "👤" }
  ];
  const railItems = [
    { id: "home", label: labels.home, icon: "🏏" },
    { id: "matches", label: labels.matches, icon: "⚡" },
    { id: "teams", label: labels.teams, icon: "🛡️" },
    { id: "tournaments", label: labels.tournaments, icon: "🏆" },
    { id: "stats", label: labels.stats, icon: "📊" },
    { id: "account", label: labels.profile, icon: "👤" },
    { id: "backup", label: labels.backup, icon: "💾" }
  ];

  const rail = document.getElementById("rail-nav");
  const bottom = document.getElementById("bottom-nav");
  if (rail) {
    rail.innerHTML = railItems
      .map(
        (item) => `
      <button type="button" class="nav-item-btn" data-nav="${item.id}" ${
          state.route === item.id ? 'aria-current="page"' : ""
        }>
        <span aria-hidden="true">${item.icon}</span>
        <span>${esc(item.label)}</span>
      </button>`
      )
      .join("");
  }

  if (bottom) {
    bottom.innerHTML = bottomItems
      .map(
        (item) => `
      <button type="button" class="bottom-nav-btn" data-nav="${item.id}" ${
          state.route === item.id ? 'aria-current="page"' : ""
        }>
        <span aria-hidden="true">${item.icon}</span>
        <span>${esc(item.label)}</span>
      </button>`
      )
      .join("");
  }

  const accLabel = document.getElementById("header-account-label");
  if (accLabel) {
    accLabel.textContent = state.activeUser
      ? state.activeUser.fullName.split(" ")[0].slice(0, 10)
      : labels.profile;
  }

  document.querySelectorAll("[data-nav]").forEach((btn) => {
    btn.addEventListener("click", () => navigate(btn.getAttribute("data-nav")));
  });
}

function navigate(route) {
  state.route = route;
  if (window.location.hash !== `#${route}`) {
    window.history.replaceState(null, "", `#${route}`);
  }
  renderAll();
  document.getElementById("main-content")?.focus({ preventScroll: true });
}

async function loadStateFromDb() {
  const [teams, players, matches, tournaments, activeUserId] = await Promise.all([
    getAll("teams"),
    getAll("players"),
    getAll("matches"),
    getAll("tournaments"),
    getMeta("active_user_id")
  ]);

  state.teams = teams.sort((a, b) => a.name.localeCompare(b.name));
  state.players = players.sort((a, b) => a.fullName.localeCompare(b.fullName));
  state.matches = matches.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  state.tournaments = tournaments.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  if (activeUserId) {
    state.activeUser = await getById("user_accounts", activeUserId);
    state.activeSettings =
      (await getById("user_settings", activeUserId)) || {
        userId: activeUserId,
        languageCode: "en",
        themeMode: "DARK",
        notificationsEnabled: false,
        matchStartAlerts: true,
        profilePrivate: true
      };
    const allFavs = await getAll("user_favourites");
    state.activeFavourites = allFavs.filter((f) => f.userId === activeUserId);
  } else {
    state.activeUser = null;
    state.activeSettings = null;
    state.activeFavourites = [];
  }
}

// ---------- HOME DASHBOARD ----------
function renderHome(main) {
  const liveMatches = state.matches.filter((m) => m.status === "LIVE");
  const labels = t();

  main.innerHTML = `
    <section class="hero-card" aria-labelledby="hero-heading">
      <img src="./assets/stadium-hero.jpg" alt="" class="hero-bg-img" aria-hidden="true" />
      <div class="hero-content">
        <span class="hero-badge">CRICKET ARENA • OFFLINE-FIRST PWA</span>
        <h1 id="hero-heading">Score Every Ball. Manage Every League.</h1>
        <p>T10, T20, ODI, Test Cricket (5-Day, Follow-On &amp; Declaration), Custom Overs &amp; 20–50+ Team Tournaments stored locally in IndexedDB.</p>
        <div class="row-gap">
          <button type="button" class="btn btn-white" id="home-create-match">+ ${esc(labels.createMatch)}</button>
          <button type="button" class="btn btn-ghost" id="home-create-tourney">🏆 ${esc(labels.createTournament)}</button>
        </div>
      </div>
    </section>

    <section class="card" aria-label="User Account Status">
      <div class="row-between">
        <div>
          <strong>${
            state.activeUser
              ? `${esc(state.activeUser.fullName)} (ID: ${esc(state.activeUser.userId)})`
              : "User Profile & Personal Control Panel"
          }</strong>
          <div class="muted">${
            state.activeUser
              ? `${state.activeFavourites.length} Favourites • Language: ${state.activeSettings?.languageCode === "bn" ? "বাংলা" : "English"}`
              : "Sign Up or Login for your personal profile, favourites, বাংলা/English toggle & backups."
          }</div>
        </div>
        <button type="button" class="btn btn-primary btn-sm" id="home-open-account">
          ${state.activeUser ? esc(labels.personalPanel) : "Login / Sign Up"}
        </button>
      </div>
    </section>

    <section aria-labelledby="live-section-title">
      <div class="page-title-row">
        <h2 id="live-section-title">Live Matches (${liveMatches.length})</h2>
        <button type="button" class="btn btn-outline btn-sm" id="home-all-matches">All Matches (${state.matches.length})</button>
      </div>
      ${
        liveMatches.length === 0
          ? `<div class="card">
              <strong>No live matches right now</strong>
              <span class="muted">Create two teams first, then launch a T10, T20, ODI, Test, or Custom Overs match to score ball-by-ball offline.</span>
            </div>`
          : `<div class="grid-2">${liveMatches
              .map((m) => {
                const calc = recalculateMatch(m);
                const inn = calc.innings[Math.min(m.currentInnings || 0, calc.innings.length - 1)];
                return `
                  <article class="card">
                    <div class="row-between">
                      <strong>${esc(m.teamA)} vs ${esc(m.teamB)}</strong>
                      <span class="badge">${esc(m.format)}</span>
                    </div>
                    <div class="muted">${esc(inn.battingTeam)}: <strong>${inn.runs}/${inn.wickets}</strong> (${inn.oversText} ov)</div>
                    <button type="button" class="btn btn-primary btn-sm" data-open-match="${esc(m.id)}">Open Live Scorer</button>
                  </article>`;
              })
              .join("")}</div>`
      }
    </section>

    <section aria-labelledby="hub-modules-title">
      <h2 id="hub-modules-title">Arena Modules</h2>
      <div class="grid-3">
        <article class="card">
          <div class="row-between"><strong>🛡️ Teams</strong><span class="badge">${state.teams.length} Saved</span></div>
          <p class="muted">Create teams with logo upload, location, player roster &amp; match history.</p>
          <button type="button" class="btn btn-outline btn-sm" data-nav-card="teams">Open Teams</button>
        </article>
        <article class="card">
          <div class="row-between"><strong>🏏 Players</strong><span class="badge">${state.players.length} Saved</span></div>
          <p class="muted">Manage batters, bowlers, all-rounders, wicketkeepers, C &amp; VC.</p>
          <button type="button" class="btn btn-outline btn-sm" data-nav-card="teams">Open Players</button>
        </article>
        <article class="card card-highlight">
          <div class="row-between"><strong>🏆 Tournaments</strong><span class="badge">${state.tournaments.length} Active</span></div>
          <p class="muted">20, 24, 32, 40, 50+ teams • Round Robin, Groups, Knockout, Hybrid &amp; NRR.</p>
          <button type="button" class="btn btn-white btn-sm" data-nav-card="tournaments">Open Tournaments</button>
        </article>
        <article class="card">
          <div class="row-between"><strong>📊 Statistics &amp; Leaderboards</strong><span class="badge">${state.matches.length} Matches</span></div>
          <p class="muted">Event-derived batting &amp; bowling stats, 9 leaderboards &amp; filters.</p>
          <button type="button" class="btn btn-outline btn-sm" data-nav-card="stats">Open Statistics</button>
        </article>
        <article class="card">
          <div class="row-between"><strong>💾 Backup &amp; Restore</strong><span class="badge">IndexedDB</span></div>
          <p class="muted">Versioned JSON export &amp; validated restore with confirmation.</p>
          <button type="button" class="btn btn-outline btn-sm" data-nav-card="backup">Open Backup</button>
        </article>
        <article class="card">
          <div class="row-between"><strong>👤 Profile &amp; Settings</strong><span class="badge">${state.activeUser ? "Signed In" : "Guest"}</span></div>
          <p class="muted">Personal control panel, language (বাংলা/EN), favourites &amp; privacy.</p>
          <button type="button" class="btn btn-outline btn-sm" data-nav-card="account">Open Profile</button>
        </article>
      </div>
    </section>
  `;

  main.querySelector("#home-create-match").onclick = () => navigate("matches");
  main.querySelector("#home-create-tourney").onclick = () => navigate("tournaments");
  main.querySelector("#home-all-matches").onclick = () => navigate("matches");
  main.querySelector("#home-open-account").onclick = () => navigate("account");
  main.querySelectorAll("[data-nav-card]").forEach((btn) => {
    btn.onclick = () => navigate(btn.getAttribute("data-nav-card"));
  });
  main.querySelectorAll("[data-open-match]").forEach((btn) => {
    btn.onclick = () => {
      state.selectedMatchId = btn.getAttribute("data-open-match");
      state.matchTab = "live";
      navigate("matches");
    };
  });
}

// ---------- TEAM & PLAYER MANAGEMENT (333) ----------
function renderTeams(main) {
  const selectedTeam = state.teams.find((tm) => tm.id === state.selectedTeamId) || null;

  if (selectedTeam) {
    const roster = state.players.filter((p) => p.teamId === selectedTeam.id);
    const teamMatches = state.matches.filter(
      (m) => m.teamA === selectedTeam.name || m.teamB === selectedTeam.name
    );

    const editingPlayer = roster.find((p) => p.id === state.editingPlayerId) || null;

    main.innerHTML = `
      <div class="page-title-row">
        <h1>${esc(selectedTeam.name)} (${esc(selectedTeam.shortCode)})</h1>
        <div class="row-gap">
          <button type="button" class="btn btn-outline btn-sm" id="back-to-teams">All Teams</button>
          <button type="button" class="btn btn-danger btn-sm" id="delete-team-btn">Delete Team</button>
        </div>
      </div>

      <section class="card card-highlight">
        <div class="row-gap">
          ${selectedTeam.logoDataUrl ? `<img src="${selectedTeam.logoDataUrl}" alt="${esc(selectedTeam.name)} logo" width="64" height="64" style="border-radius:14px; object-fit:cover;" />` : ""}
          <div>
            <strong>${esc(selectedTeam.name)} • ${esc(selectedTeam.location || "No Location")}</strong>
            <div class="muted">Created: ${esc(selectedTeam.createdDate || "—")} • Players: ${roster.length} • Matches: ${teamMatches.length}</div>
            <div class="muted">${esc(selectedTeam.description || "No description")}</div>
          </div>
        </div>
      </section>

      <form id="add-roster-player-form" class="card">
        <h2>${editingPlayer ? `Edit Player: ${esc(editingPlayer.fullName)}` : `Add Player to ${esc(selectedTeam.name)}`}</h2>
        <div class="grid-3">
          <label class="field">Full Name *<input name="fullName" required value="${esc(editingPlayer?.fullName || "")}" placeholder="e.g. Litton Das" /></label>
          <label class="field">Jersey Number *<input type="number" name="jerseyNumber" min="0" max="999" required value="${editingPlayer ? esc(editingPlayer.jerseyNumber) : roster.length + 1}" /></label>
          <label class="field">Role *
            <select name="role">
              ${["Batter", "Bowler", "All-rounder", "Wicketkeeper"]
                .map((r) => `<option value="${r}" ${editingPlayer?.role === r ? "selected" : ""}>${r}</option>`)
                .join("")}
            </select>
          </label>
          <label class="field">Batting Style
            <select name="battingStyle">
              ${["Right-hand bat", "Left-hand bat"]
                .map((b) => `<option ${editingPlayer?.battingStyle === b ? "selected" : ""}>${b}</option>`)
                .join("")}
            </select>
          </label>
          <label class="field">Bowling Style
            <select name="bowlingStyle">
              ${["Right-arm fast", "Right-arm medium", "Right-arm offbreak", "Right-arm legbreak", "Left-arm fast", "Left-arm orthodox", "None"]
                .map((bw) => `<option ${editingPlayer?.bowlingStyle === bw ? "selected" : ""}>${bw}</option>`)
                .join("")}
            </select>
          </label>
          <label class="field">Player Photo (Optional)
            <input type="file" name="photoFile" accept="image/*" />
          </label>
        </div>
        <div class="row-gap">
          <label class="row-gap"><input type="checkbox" name="isCaptain" ${editingPlayer?.isCaptain ? "checked" : ""} style="width:auto;min-height:auto;" /> Captain</label>
          <label class="row-gap"><input type="checkbox" name="isViceCaptain" ${editingPlayer?.isViceCaptain ? "checked" : ""} style="width:auto;min-height:auto;" /> Vice-Captain</label>
        </div>
        <div class="row-gap">
          <button type="submit" class="btn btn-primary">${editingPlayer ? "Save Player Changes" : "Add Player to Squad"}</button>
          ${editingPlayer ? `<button type="button" class="btn btn-outline" id="cancel-edit-player">Cancel</button>` : ""}
        </div>
      </form>

      <section class="card">
        <h2>Squad Roster (${roster.length})</h2>
        ${
          roster.length === 0
            ? `<span class="muted">No players in this squad yet. Add players above (11+ recommended for Playing XI).</span>`
            : `<div class="grid-2">${roster
                .map(
                  (p) => `
              <article class="stat-cell">
                <div class="row-between">
                  <div class="row-gap">
                    ${p.photoDataUrl ? `<img src="${p.photoDataUrl}" alt="${esc(p.fullName)}" width="40" height="40" style="border-radius:50%; object-fit:cover;" />` : ""}
                    <div>
                      <strong>#${esc(p.jerseyNumber)} ${esc(p.fullName)}</strong>
                      <div class="muted">${esc(p.role)} • ${esc(p.battingStyle)} / ${esc(p.bowlingStyle)}</div>
                    </div>
                  </div>
                  <div class="row-gap">
                    ${p.isCaptain ? `<span class="badge">C</span>` : ""}
                    ${p.isViceCaptain ? `<span class="badge">VC</span>` : ""}
                  </div>
                </div>
                <div class="row-gap" style="margin-top:8px;">
                  <button type="button" class="btn btn-outline btn-sm" data-edit-player="${esc(p.id)}">Edit</button>
                  <button type="button" class="btn btn-outline btn-sm" data-set-cap="${esc(p.id)}">Set Captain</button>
                  <button type="button" class="btn btn-outline btn-sm" data-set-vc="${esc(p.id)}">Set VC</button>
                  <button type="button" class="btn btn-danger btn-sm" data-rem-player="${esc(p.id)}">Remove</button>
                </div>
              </article>`
                )
                .join("")}</div>`
        }
      </section>

      <section class="card">
        <h2>Team Match History (${teamMatches.length})</h2>
        ${
          teamMatches.length === 0
            ? `<span class="muted">No matches played by ${esc(selectedTeam.name)} yet.</span>`
            : teamMatches
                .map((m) => {
                  const calc = recalculateMatch(m);
                  return `<div class="stat-cell row-between">
                    <div>
                      <strong>${esc(m.teamA)} vs ${esc(m.teamB)}</strong>
                      <div class="muted">${esc(m.format)} • ${esc(m.matchDate || "")} • ${esc(calc.resultSummary || m.status)}</div>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm" data-jump-match="${esc(m.id)}">Open</button>
                  </div>`;
                })
                .join("")
        }
      </section>
    `;

    main.querySelector("#back-to-teams").onclick = () => {
      state.selectedTeamId = null;
      state.editingPlayerId = null;
      renderAll();
    };

    main.querySelector("#cancel-edit-player")?.addEventListener("click", () => {
      state.editingPlayerId = null;
      renderAll();
    });

    main.querySelector("#delete-team-btn").onclick = async () => {
      if (!window.confirm(`Delete team "${selectedTeam.name}" and unlink its squad?`)) return;
      for (const p of roster) await deleteRecord("players", p.id);
      await deleteRecord("teams", selectedTeam.id);
      state.selectedTeamId = null;
      state.editingPlayerId = null;
      await loadStateFromDb();
      showToast("Team deleted.");
      renderAll();
    };

    main.querySelector("#add-roster-player-form").onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const fullName = String(fd.get("fullName")).trim();
      const jerseyNumber = Number(fd.get("jerseyNumber"));

      // Duplicate player check within same team (excluding player currently being edited)
      const duplicate = roster.some(
        (p) =>
          p.id !== editingPlayer?.id &&
          (p.fullName.toLowerCase() === fullName.toLowerCase() || Number(p.jerseyNumber) === jerseyNumber)
      );
      if (duplicate) {
        showToast("Duplicate player name or jersey number in this team!");
        return;
      }

      const photoFile = fd.get("photoFile");
      let photoDataUrl = editingPlayer?.photoDataUrl || null;
      if (photoFile && photoFile.size > 0) {
        try {
          photoDataUrl = await readImageAsDataUrl(photoFile);
        } catch (err) {
          showToast(err.message);
          return;
        }
      }

      const isCaptain = fd.get("isCaptain") === "on";
      const isViceCaptain = fd.get("isViceCaptain") === "on";
      if (isCaptain) {
        for (const p of roster) if (p.isCaptain && p.id !== editingPlayer?.id) await putRecord("players", { ...p, isCaptain: false });
      }
      if (isViceCaptain) {
        for (const p of roster) if (p.isViceCaptain && p.id !== editingPlayer?.id) await putRecord("players", { ...p, isViceCaptain: false });
      }

      await putRecord("players", {
        id: editingPlayer?.id || uid("player"),
        teamId: selectedTeam.id,
        teamName: selectedTeam.name,
        fullName,
        jerseyNumber,
        role: String(fd.get("role")),
        battingStyle: String(fd.get("battingStyle")),
        bowlingStyle: String(fd.get("bowlingStyle")),
        isCaptain,
        isViceCaptain,
        photoDataUrl,
        createdAt: editingPlayer?.createdAt || Date.now()
      });

      state.editingPlayerId = null;
      await loadStateFromDb();
      showToast(editingPlayer ? `Updated ${fullName}.` : `Added ${fullName} to ${selectedTeam.name}.`);
      renderAll();
    };

    main.querySelectorAll("[data-edit-player]").forEach((btn) => {
      btn.onclick = () => {
        state.editingPlayerId = btn.getAttribute("data-edit-player");
        renderAll();
      };
    });

    main.querySelectorAll("[data-set-cap]").forEach((btn) => {
      btn.onclick = async () => {
        const pid = btn.getAttribute("data-set-cap");
        for (const p of roster) {
          await putRecord("players", { ...p, isCaptain: p.id === pid });
        }
        await loadStateFromDb();
        renderAll();
      };
    });

    main.querySelectorAll("[data-set-vc]").forEach((btn) => {
      btn.onclick = async () => {
        const pid = btn.getAttribute("data-set-vc");
        for (const p of roster) {
          await putRecord("players", { ...p, isViceCaptain: p.id === pid });
        }
        await loadStateFromDb();
        renderAll();
      };
    });

    main.querySelectorAll("[data-rem-player]").forEach((btn) => {
      btn.onclick = async () => {
        if (!window.confirm("Remove this player from the squad?")) return;
        await deleteRecord("players", btn.getAttribute("data-rem-player"));
        await loadStateFromDb();
        renderAll();
      };
    });

    main.querySelectorAll("[data-jump-match]").forEach((btn) => {
      btn.onclick = () => {
        state.selectedMatchId = btn.getAttribute("data-jump-match");
        state.matchTab = "scorecard";
        navigate("matches");
      };
    });
    return;
  }

  const editingTeam = state.teams.find((tm) => tm.id === state.editingTeamId) || null;
  const query = state.teamSearch.trim().toLowerCase();
  const filteredTeams = state.teams.filter(
    (tm) =>
      !query ||
      tm.name.toLowerCase().includes(query) ||
      tm.shortCode.toLowerCase().includes(query) ||
      (tm.location || "").toLowerCase().includes(query)
  );

  main.innerHTML = `
    <div class="page-title-row">
      <h1>Team &amp; Squad Management</h1>
      <input type="search" id="team-search-input" value="${esc(state.teamSearch)}" placeholder="Search teams by name, code, or city..." style="max-width:290px;" aria-label="Search teams" />
    </div>

    <form id="team-form" class="card">
      <h2>${editingTeam ? `Edit Team: ${esc(editingTeam.name)}` : "Create New Team"}</h2>
      <div class="grid-3">
        <label class="field">Team Name *<input name="name" required value="${esc(editingTeam?.name || "")}" placeholder="e.g. Dhaka Tigers" /></label>
        <label class="field">Short Code *<input name="shortCode" required maxlength="6" value="${esc(editingTeam?.shortCode || "")}" placeholder="e.g. DHK" /></label>
        <label class="field">Location / City<input name="location" value="${esc(editingTeam?.location || "")}" placeholder="e.g. Dhaka" /></label>
        <label class="field">Creation Date<input type="date" name="createdDate" value="${esc(editingTeam?.createdDate || new Date().toISOString().slice(0, 10))}" /></label>
        <label class="field">Team Logo / Photo (Optional)<input type="file" name="logoFile" accept="image/*" /></label>
      </div>
      <label class="field">Team Description<textarea name="description" placeholder="Club history or squad notes...">${esc(editingTeam?.description || "")}</textarea></label>
      <div class="row-gap">
        <button type="submit" class="btn btn-primary">${editingTeam ? "Save Changes" : "Create Team"}</button>
        ${editingTeam ? `<button type="button" class="btn btn-outline" id="cancel-edit-team">Cancel</button>` : ""}
      </div>
    </form>

    <section class="grid-3">
      ${
        filteredTeams.length === 0
          ? `<div class="card"><strong>No teams yet</strong><span class="muted">Create at least 2 teams above to build squads and create matches.</span></div>`
          : filteredTeams
              .map((tm) => {
                const count = state.players.filter((p) => p.teamId === tm.id).length;
                return `
            <article class="card">
              <div class="row-between">
                <div class="row-gap">
                  ${tm.logoDataUrl ? `<img src="${tm.logoDataUrl}" alt="${esc(tm.name)} logo" width="40" height="40" style="border-radius:10px; object-fit:cover;" />` : ""}
                  <strong>${esc(tm.name)}</strong>
                </div>
                <span class="badge">${esc(tm.shortCode)}</span>
              </div>
              <div class="muted">${esc(tm.location || "Local Team")} • ${count} Player(s)</div>
              <div class="row-gap">
                <button type="button" class="btn btn-primary btn-sm" data-open-team="${esc(tm.id)}">Squad &amp; History</button>
                <button type="button" class="btn btn-outline btn-sm" data-edit-team="${esc(tm.id)}">Edit</button>
              </div>
            </article>`;
              })
              .join("")
      }
    </section>
  `;

  main.querySelector("#team-search-input").oninput = (e) => {
    const pos = e.target.selectionStart || e.target.value.length;
    state.teamSearch = e.target.value;
    renderAll();
    const nextInput = document.getElementById("team-search-input");
    if (nextInput) {
      nextInput.focus();
      nextInput.setSelectionRange(pos, pos);
    }
  };

  const cancelBtn = main.querySelector("#cancel-edit-team");
  if (cancelBtn) {
    cancelBtn.onclick = () => {
      state.editingTeamId = null;
      renderAll();
    };
  }

  main.querySelector("#team-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const name = String(fd.get("name")).trim();
    const shortCode = String(fd.get("shortCode")).trim().toUpperCase();
    if (!name || !shortCode) return;

    const duplicateTeam = state.teams.some(
      (tm) => tm.id !== editingTeam?.id && tm.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicateTeam) {
      showToast(`Team "${name}" already exists!`);
      return;
    }

    const logoFile = fd.get("logoFile");
    let logoDataUrl = editingTeam?.logoDataUrl || null;
    if (logoFile && logoFile.size > 0) {
      try {
        logoDataUrl = await readImageAsDataUrl(logoFile);
      } catch (err) {
        showToast(err.message);
        return;
      }
    }

    const record = {
      id: editingTeam?.id || uid("team"),
      name,
      shortCode,
      location: String(fd.get("location")).trim(),
      description: String(fd.get("description")).trim(),
      createdDate: String(fd.get("createdDate")),
      logoDataUrl,
      updatedAt: Date.now()
    };
    await putRecord("teams", record);
    if (editingTeam && editingTeam.name !== name) {
      for (const p of state.players) {
        if (p.teamId === record.id) {
          await putRecord("players", { ...p, teamName: name });
        }
      }
    }
    state.editingTeamId = null;
    await loadStateFromDb();
    showToast(`Saved team ${record.name}.`);
    renderAll();
  };

  main.querySelectorAll("[data-open-team]").forEach((b) => {
    b.onclick = () => {
      state.selectedTeamId = b.getAttribute("data-open-team");
      renderAll();
    };
  });
  main.querySelectorAll("[data-edit-team]").forEach((b) => {
    b.onclick = () => {
      state.editingTeamId = b.getAttribute("data-edit-team");
      renderAll();
    };
  });
}

// ---------- MATCH CREATION (444), LIVE SCORING (555) & FORMAT RULES (666) ----------
function renderMatches(main) {
  const activeMatch = state.matches.find((m) => m.id === state.selectedMatchId) || null;

  if (activeMatch) {
    const calc = recalculateMatch(activeMatch);
    const curIdx = Math.max(0, Math.min(calc.innings.length - 1, Number(activeMatch.currentInnings) || 0));
    const inn = calc.innings[curIdx];
    const isTest = calc.config.key === "TEST";

    const battingRoster = state.players.filter((p) => p.teamName === inn.battingTeam).map((p) => p.fullName);
    const bowlingRoster = state.players.filter((p) => p.teamName === inn.bowlingTeam).map((p) => p.fullName);

    const outSet = new Set(Object.values(inn.batters).filter((b) => b.out).map((b) => b.name));
    const availableBatters = [...new Set([...battingRoster, ...Object.keys(inn.batters)])].filter((n) => !outSet.has(n));
    const availableBowlers = [...new Set([...bowlingRoster, ...Object.keys(inn.bowlers)])];

    const rawDefaultStriker = inn.strikerName || availableBatters[0] || `${inn.battingTeam} Batter 1`;
    const rawDefaultNonStriker = inn.nonStrikerName || availableBatters.find((n) => n !== rawDefaultStriker) || `${inn.battingTeam} Batter 2`;
    const defaultStriker = state.swapStrikeActive ? rawDefaultNonStriker : rawDefaultStriker;
    const defaultNonStriker = state.swapStrikeActive ? rawDefaultStriker : rawDefaultNonStriker;
    const defaultBowler = inn.currentBowlerName || availableBowlers.find((n) => n !== inn.lastOverBowlerName) || `${inn.bowlingTeam} Bowler 1`;

    const activeXI = inn.battingTeam === activeMatch.teamA ? (activeMatch.teamAXI || []) : (activeMatch.teamBXI || []);
    const mergedBatters = [...new Set([...activeXI, ...availableBatters])].filter((n) => !outSet.has(n));

    let inlineScorerHtml = "";
    if (state.scorerPanel?.type === "EXTRA") {
      const exType = state.scorerPanel.extraType;
      const runOpts = exType === "WIDE" || exType === "NO_BALL" ? [0, 1, 2, 3, 4, 6] : [1, 2, 3, 4, 5];
      inlineScorerHtml = `
        <div class="inline-panel" role="region" aria-label="Record ${esc(exType)}">
          <div class="row-between">
            <strong>Record ${esc(exType.replace("_", "-"))} — Select Additional Runs</strong>
            <button type="button" class="btn btn-outline btn-sm" id="close-scorer-panel">Cancel</button>
          </div>
          <div class="row-gap">
            ${runOpts.map((r) => `<button type="button" class="btn btn-primary btn-sm" data-confirm-extra="${r}">${exType === "NO_BALL" ? `NB + ${r} bat` : exType === "WIDE" ? `WD + ${r}` : `${r}`}</button>`).join("")}
          </div>
        </div>`;
    } else if (state.scorerPanel?.type === "WICKET") {
      inlineScorerHtml = `
        <form id="inline-wicket-form" class="inline-panel">
          <div class="row-between">
            <strong>Record Wicket ${inn.nextBallFreeHit ? "(FREE HIT — Run Out Only!)" : ""}</strong>
            <button type="button" class="btn btn-outline btn-sm" id="close-scorer-panel">Cancel</button>
          </div>
          <div class="grid-3">
            <label class="field">Dismissal Type
              <select name="kind">
                ${
                  inn.nextBallFreeHit
                    ? `<option value="RUN_OUT">RUN_OUT</option>`
                    : `<option value="CAUGHT">CAUGHT</option>
                       <option value="BOWLED">BOWLED</option>
                       <option value="LBW">LBW</option>
                       <option value="RUN_OUT">RUN_OUT</option>
                       <option value="STUMPED">STUMPED</option>
                       <option value="HIT_WICKET">HIT_WICKET</option>
                       <option value="RETIRED">RETIRED</option>`
                }
              </select>
            </label>
            <label class="field">Dismissed Batter
              <select name="dismissedBatterName">
                <option value="${esc(defaultStriker)}">${esc(defaultStriker)} (Striker)</option>
                <option value="${esc(defaultNonStriker)}">${esc(defaultNonStriker)} (Non-Striker)</option>
              </select>
            </label>
            <label class="field">Fielder / Keeper (Optional)
              <input name="fielderName" placeholder="e.g. Litton Das" />
            </label>
          </div>
          <button type="submit" class="btn btn-danger btn-sm">Confirm Wicket</button>
        </form>`;
    } else if (state.scorerPanel?.type === "END_CONFIRM") {
      inlineScorerHtml = `
        <div class="inline-panel" role="region" aria-label="Confirm End Match">
          <strong>Finalize &amp; End Match?</strong>
          <span class="muted">This marks the match COMPLETED and locks further live ball entries (you can still undo the last ball if needed later or view full scorecard).</span>
          <div class="row-gap">
            <button type="button" class="btn btn-danger btn-sm" id="confirm-end-match-btn">Yes, End Match</button>
            <button type="button" class="btn btn-outline btn-sm" id="close-scorer-panel">Keep Scoring</button>
          </div>
        </div>`;
    }

    main.innerHTML = `
      <div class="page-title-row">
        <h1>${esc(activeMatch.teamA)} vs ${esc(activeMatch.teamB)}</h1>
        <button type="button" class="btn btn-outline btn-sm" id="back-to-matches">All Matches</button>
      </div>

      <section class="score-board">
        <div class="row-between">
          <strong>${esc(inn.battingTeam)} — Innings ${curIdx + 1}${isTest ? ` (Day ${activeMatch.currentDay || 1}/5)` : ""}</strong>
          <span class="badge">${esc(calc.config.label)}${calc.config.maxOvers ? ` • ${calc.config.maxOvers} ov` : ""} • ${esc(activeMatch.status)}</span>
        </div>
        <div class="score-big">${inn.runs}/${inn.wickets} <span style="font-size:1.1rem;font-weight:600;">(${inn.oversText} ov)</span></div>
        <div class="row-gap" style="margin-top:6px;">
          <span>CRR: <strong>${inn.legalBalls > 0 ? ((inn.runs / inn.legalBalls) * 6).toFixed(2) : "0.00"}</strong></span>
          ${calc.target !== null ? `<span>Target: <strong>${calc.target}</strong></span>` : ""}
          ${calc.runsRemaining !== null ? `<span>Need: <strong>${calc.runsRemaining}</strong></span>` : ""}
          ${calc.requiredRunRate ? `<span>RRR: <strong>${calc.requiredRunRate}</strong></span>` : ""}
          ${calc.leadDeficitText ? `<span>${esc(calc.leadDeficitText)}</span>` : ""}
          ${inn.nextBallFreeHit ? `<span class="badge" style="background:#f59e0b;color:#000;">FREE HIT NEXT BALL</span>` : ""}
        </div>
        ${calc.resultSummary ? `<div style="margin-top:10px;font-weight:800;color:#2ecc71;">${esc(calc.resultSummary)}</div>` : ""}
      </section>

      <div class="chip-row">
        <button type="button" class="chip ${state.matchTab === "live" ? "active" : ""}" data-mtab="live">Live Scorer</button>
        <button type="button" class="chip ${state.matchTab === "scorecard" ? "active" : ""}" data-mtab="scorecard">Full Scorecard &amp; Commentary</button>
        <button type="button" class="chip ${state.matchTab === "details" ? "active" : ""}" data-mtab="details">Match Details</button>
      </div>

      ${
        state.matchTab === "live"
          ? `<section class="card">
              <div class="grid-3">
                <label class="field">Striker
                  <input id="scorer-striker" value="${esc(defaultStriker)}" list="bat-roster-list" />
                </label>
                <label class="field">Non-Striker
                  <input id="scorer-nonstriker" value="${esc(defaultNonStriker)}" list="bat-roster-list" />
                </label>
                <label class="field">Current Bowler ${inn.overJustCompleted ? "(Over Complete — Pick New Bowler)" : ""}
                  <input id="scorer-bowler" value="${esc(defaultBowler)}" list="bowl-roster-list" />
                </label>
              </div>
              <datalist id="bat-roster-list">${mergedBatters.map((n) => `<option value="${esc(n)}"></option>`).join("")}</datalist>
              <datalist id="bowl-roster-list">${availableBowlers.map((n) => `<option value="${esc(n)}"></option>`).join("")}</datalist>

              <div class="muted">Partnership: <strong>${inn.currentPartnership.runs} (${inn.currentPartnership.balls})</strong> • Extras: <strong>${inn.extras.total}</strong> (wd ${inn.extras.wide}, nb ${inn.extras.noBall}, b ${inn.extras.bye}, lb ${inn.extras.legBye}, pen ${inn.extras.penalty})</div>

              <div class="ball-pad">
                <button type="button" class="btn btn-outline" data-run="0">0</button>
                <button type="button" class="btn btn-outline" data-run="1">1</button>
                <button type="button" class="btn btn-outline" data-run="2">2</button>
                <button type="button" class="btn btn-outline" data-run="3">3</button>
                <button type="button" class="btn btn-primary" data-run="4">4</button>
                <button type="button" class="btn btn-outline" data-run="5">5</button>
                <button type="button" class="btn btn-primary" data-run="6">6</button>
                <button type="button" class="btn btn-danger" id="record-wicket-btn">Wicket</button>
                <button type="button" class="btn btn-outline" data-extra="WIDE">Wide</button>
                <button type="button" class="btn btn-outline" data-extra="NO_BALL">No-Ball</button>
                <button type="button" class="btn btn-outline" data-extra="BYE">Bye</button>
                <button type="button" class="btn btn-outline" data-extra="LEG_BYE">Leg-Bye</button>
                <button type="button" class="btn btn-outline" data-extra="PENALTY">Penalty +5</button>
                <button type="button" class="btn btn-outline" id="swap-strike-btn">Swap Strike</button>
                <button type="button" class="btn btn-outline" id="undo-ball-btn">Undo Ball</button>
                <button type="button" class="btn btn-accent" id="end-match-btn">End Match</button>
              </div>

              ${inlineScorerHtml}

              <div class="row-gap" style="margin-top:8px;">
                ${curIdx + 1 < calc.innings.length ? `<button type="button" class="btn btn-primary btn-sm" id="next-innings-btn">Start Innings ${curIdx + 2}</button>` : ""}
                ${isTest ? `<button type="button" class="btn btn-outline btn-sm" id="declare-innings-btn">Declare Innings</button>` : ""}
                ${isTest && calc.canEnforceFollowOn ? `<button type="button" class="btn btn-primary btn-sm" id="follow-on-btn">Enforce Follow-On</button>` : ""}
                ${isTest ? `<button type="button" class="btn btn-outline btn-sm" id="next-day-btn">Advance Day (${activeMatch.currentDay || 1}/5)</button>` : ""}
              </div>
            </section>`
          : state.matchTab === "scorecard"
          ? `<section class="card">
              ${calc.innings
                .filter((iData, idx) => idx <= curIdx || iData.totalDeliveries > 0)
                .map(
                  (iData, idx) => `
                <h2>Innings ${idx + 1}: ${esc(iData.battingTeam)} — ${iData.runs}/${iData.wickets} (${iData.oversText} ov)</h2>
                <div class="table-wrap">
                  <table>
                    <thead><tr><th>Batter</th><th>Status</th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>SR</th></tr></thead>
                    <tbody>
                      ${
                        Object.values(iData.batters)
                          .sort((a, b) => a.order - b.order)
                          .map(
                            (b) => `<tr><td><strong>${esc(b.name)}</strong></td><td>${esc(b.dismissalText)}</td><td><strong>${b.runs}</strong></td><td>${b.balls}</td><td>${b.fours}</td><td>${b.sixes}</td><td>${b.balls > 0 ? ((b.runs / b.balls) * 100).toFixed(1) : "0.0"}</td></tr>`
                          )
                          .join("") || `<tr><td colspan="7">No batting entries yet</td></tr>`
                      }
                    </tbody>
                  </table>
                </div>
                <div class="muted">Extras: ${iData.extras.total} (wd ${iData.extras.wide}, nb ${iData.extras.noBall}, b ${iData.extras.bye}, lb ${iData.extras.legBye}, pen ${iData.extras.penalty})</div>
                <div class="muted">Fall of Wickets: ${iData.fallOfWickets.map((f) => `${f.scoreAtFall} (${f.batterName}, ${f.overText} ov)`).join(" • ") || "None"}</div>
                <div class="table-wrap" style="margin-top:8px;">
                  <table>
                    <thead><tr><th>Bowler</th><th>O</th><th>M</th><th>R</th><th>W</th><th>Econ</th><th>WD</th><th>NB</th></tr></thead>
                    <tbody>
                      ${
                        Object.values(iData.bowlers)
                          .map(
                            (bw) => `<tr><td><strong>${esc(bw.name)}</strong></td><td>${bw.oversText}</td><td>${bw.maidens}</td><td>${bw.runsConceded}</td><td><strong>${bw.wickets}</strong></td><td>${bw.economy}</td><td>${bw.wides}</td><td>${bw.noBalls}</td></tr>`
                          )
                          .join("") || `<tr><td colspan="8">No bowling entries yet</td></tr>`
                      }
                    </tbody>
                  </table>
                </div>`
                )
                .join("")}
              <h3>Ball-by-Ball Commentary</h3>
              <div style="max-height:220px;overflow:auto;">
                ${inn.commentary.map((c) => `<div class="muted" style="padding:4px 0;border-bottom:1px solid var(--border);">${esc(c.text)}</div>`).join("") || `<span class="muted">No deliveries recorded yet.</span>`}
              </div>
            </section>`
          : `<section class="card">
              <div class="row-between">
                <h2>Match Information</h2>
                <button type="button" class="btn btn-primary btn-sm" id="share-match-summary-btn" aria-label="Share match summary via other apps">
                  Share Match Summary
                </button>
              </div>
              <div class="grid-2">
                <div class="stat-cell"><div class="label">Teams</div><div class="value">${esc(activeMatch.teamA)} vs ${esc(activeMatch.teamB)}</div></div>
                <div class="stat-cell"><div class="label">Format &amp; Overs</div><div class="value">${esc(calc.config.label)}${calc.config.maxOvers ? ` (${calc.config.maxOvers} ov)` : " (Up to 5 Days)"}</div></div>
                <div class="stat-cell"><div class="label">Venue &amp; Date</div><div class="value">${esc(activeMatch.venue || "Not Specified")} • ${esc(activeMatch.matchDate || "—")}</div></div>
                <div class="stat-cell"><div class="label">Toss</div><div class="value">${esc(activeMatch.tossWinner || "—")} elected to ${esc(activeMatch.tossDecision || "Bat")}</div></div>
                <div class="stat-cell"><div class="label">${esc(activeMatch.teamA)} Leadership</div><div class="value">C: ${esc(activeMatch.teamACaptain || "—")} • WK: ${esc(activeMatch.teamAWicketkeeper || "—")}</div></div>
                <div class="stat-cell"><div class="label">${esc(activeMatch.teamB)} Leadership</div><div class="value">C: ${esc(activeMatch.teamBCaptain || "—")} • WK: ${esc(activeMatch.teamBWicketkeeper || "—")}</div></div>
              </div>
              <div class="muted"><strong>${esc(activeMatch.teamA)} XI:</strong> ${esc((activeMatch.teamAXI || []).join(", ") || "Default Squad")}</div>
              <div class="muted"><strong>${esc(activeMatch.teamB)} XI:</strong> ${esc((activeMatch.teamBXI || []).join(", ") || "Default Squad")}</div>
            </section>
            <section class="card" aria-label="Shareable Match Summary">
              <div class="row-between">
                <h3>Shareable Text Summary</h3>
                <button type="button" class="btn btn-outline btn-sm" id="copy-match-summary-btn">Copy Text</button>
              </div>
              <textarea id="share-summary-preview" readonly rows="8" aria-label="Generated match summary text">${esc(generateMatchShareSummary(activeMatch, calc))}</textarea>
            </section>`
      }
    `;

    main.querySelector("#back-to-matches").onclick = () => {
      state.selectedMatchId = null;
      state.scorerPanel = null;
      state.swapStrikeActive = false;
      renderAll();
    };
    main.querySelectorAll("[data-mtab]").forEach((btn) => {
      btn.onclick = () => {
        state.matchTab = btn.getAttribute("data-mtab");
        state.scorerPanel = null;
        renderAll();
      };
    });

    if (state.matchTab === "details") {
      const shareText = generateMatchShareSummary(activeMatch, calc);
      const copySummaryToClipboard = async () => {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(shareText);
        } else {
          const preview = main.querySelector("#share-summary-preview");
          preview?.select();
          document.execCommand?.("copy");
        }
        showToast("Match summary copied to clipboard!");
      };

      main.querySelector("#share-match-summary-btn")?.addEventListener("click", async () => {
        if (typeof navigator.share === "function") {
          try {
            await navigator.share({
              title: `${activeMatch.teamA} vs ${activeMatch.teamB} — Cricket Arena`,
              text: shareText
            });
            showToast("Match summary shared.");
            return;
          } catch (err) {
            if (err?.name === "AbortError") return;
          }
        }
        try {
          await copySummaryToClipboard();
        } catch {
          showToast("Select and copy the summary text below.");
        }
      });

      main.querySelector("#copy-match-summary-btn")?.addEventListener("click", async () => {
        try {
          await copySummaryToClipboard();
        } catch {
          showToast("Select and copy the summary text below.");
        }
      });
    }

    if (state.matchTab === "live") {
      const pushBallEvent = async (partial) => {
        if (activeMatch.status === "COMPLETED" || activeMatch.status === "ABANDONED") {
          showToast("Match is already finished.");
          return;
        }
        if (inn.completed) {
          showToast("Current innings is complete. Advance to next innings or end match.");
          return;
        }
        const strikerName = main.querySelector("#scorer-striker").value.trim() || defaultStriker;
        const nonStrikerName = main.querySelector("#scorer-nonstriker").value.trim() || defaultNonStriker;
        const bowlerName = main.querySelector("#scorer-bowler").value.trim() || defaultBowler;

        if (strikerName === nonStrikerName) {
          showToast("Striker and Non-Striker must be different batters.");
          return;
        }
        if (inn.overJustCompleted && bowlerName === inn.lastOverBowlerName) {
          showToast("Same bowler cannot bowl two consecutive overs!");
          return;
        }

        const event = {
          id: uid("ball"),
          inningsIndex: curIdx,
          day: activeMatch.currentDay || 1,
          strikerName,
          nonStrikerName,
          bowlerName,
          runsBat: 0,
          extraType: "NONE",
          extraRuns: 0,
          wicket: null,
          isFreeHit: Boolean(inn.nextBallFreeHit),
          timestamp: Date.now(),
          ...partial
        };

        activeMatch.ballEvents = [...(activeMatch.ballEvents || []), event];
        const postCalc = recalculateMatch(activeMatch);
        if (postCalc.resultSummary) {
          activeMatch.status = "COMPLETED";
        }
        state.scorerPanel = null;
        state.swapStrikeActive = false;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        renderAll();
      };

      main.querySelectorAll("[data-run]").forEach((btn) => {
        btn.onclick = () => pushBallEvent({ runsBat: Number(btn.getAttribute("data-run")) });
      });

      main.querySelectorAll("[data-extra]").forEach((btn) => {
        btn.onclick = () => {
          const ex = btn.getAttribute("data-extra");
          if (ex === "PENALTY") {
            pushBallEvent({ extraType: "PENALTY", extraRuns: 5 });
          } else {
            state.scorerPanel = { type: "EXTRA", extraType: ex };
            renderAll();
          }
        };
      });

      main.querySelectorAll("[data-confirm-extra]").forEach((btn) => {
        btn.onclick = () => {
          const val = Number(btn.getAttribute("data-confirm-extra")) || 0;
          const ex = state.scorerPanel?.extraType;
          if (ex === "NO_BALL") {
            pushBallEvent({ extraType: "NO_BALL", runsBat: val, extraRuns: 0 });
          } else {
            pushBallEvent({ extraType: ex, extraRuns: val });
          }
        };
      });

      main.querySelector("#record-wicket-btn").onclick = () => {
        state.scorerPanel = { type: "WICKET" };
        renderAll();
      };

      main.querySelector("#inline-wicket-form")?.addEventListener("submit", (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const kind = String(fd.get("kind")).trim().toUpperCase();
        const dismissedBatterName = String(fd.get("dismissedBatterName")).trim();
        const fielderName = String(fd.get("fielderName") || "").trim();
        if (inn.nextBallFreeHit && kind !== "RUN_OUT") {
          showToast("On a Free Hit, only RUN_OUT is permitted!");
          return;
        }
        pushBallEvent({
          runsBat: 0,
          wicket: { kind, dismissedBatterName, fielderName }
        });
      });

      main.querySelector("#close-scorer-panel")?.addEventListener("click", () => {
        state.scorerPanel = null;
        renderAll();
      });

      main.querySelector("#swap-strike-btn").onclick = () => {
        state.swapStrikeActive = !state.swapStrikeActive;
        renderAll();
      };

      main.querySelector("#undo-ball-btn").onclick = async () => {
        if (!activeMatch.ballEvents?.length) return;
        activeMatch.ballEvents = activeMatch.ballEvents.slice(0, -1);
        activeMatch.status = "LIVE";
        state.scorerPanel = null;
        state.swapStrikeActive = false;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        showToast("Undid last delivery.");
        renderAll();
      };

      main.querySelector("#end-match-btn").onclick = () => {
        state.scorerPanel = { type: "END_CONFIRM" };
        renderAll();
      };

      main.querySelector("#confirm-end-match-btn")?.addEventListener("click", async () => {
        activeMatch.status = "COMPLETED";
        state.scorerPanel = null;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        showToast("Match ended and saved.");
        renderAll();
      });

      main.querySelector("#next-innings-btn")?.addEventListener("click", async () => {
        activeMatch.currentInnings = Math.min(calc.innings.length - 1, curIdx + 1);
        state.swapStrikeActive = false;
        state.scorerPanel = null;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        renderAll();
      });

      main.querySelector("#declare-innings-btn")?.addEventListener("click", async () => {
        if (!window.confirm("Declare current Test innings?")) return;
        activeMatch.declaredInnings = { ...(activeMatch.declaredInnings || {}), [curIdx]: true };
        if (curIdx + 1 < 4) activeMatch.currentInnings = curIdx + 1;
        state.swapStrikeActive = false;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        renderAll();
      });

      main.querySelector("#follow-on-btn")?.addEventListener("click", async () => {
        activeMatch.followOnEnforced = true;
        activeMatch.currentInnings = 2;
        state.swapStrikeActive = false;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        showToast("Follow-on enforced!");
        renderAll();
      });

      main.querySelector("#next-day-btn")?.addEventListener("click", async () => {
        const nextDay = Math.min(5, (activeMatch.currentDay || 1) + 1);
        activeMatch.currentDay = nextDay;
        activeMatch.updatedAt = Date.now();
        await putRecord("matches", activeMatch);
        showToast(`Advanced to Day ${nextDay} of 5.`);
        renderAll();
      });
    }
    return;
  }

  // Match Creation + List
  const teamOptions = state.teams.map((tm) => `<option value="${esc(tm.name)}">${esc(tm.name)} (${esc(tm.shortCode)})</option>`).join("");
  const tourneyOptions = state.tournaments.map((tr) => `<option value="${esc(tr.id)}">${esc(tr.name)}</option>`).join("");

  main.innerHTML = `
    <div class="page-title-row">
      <h1>Match Creation &amp; Live Matches</h1>
    </div>

    ${
      state.teams.length < 2
        ? `<section class="card"><strong>Create 2 Teams First</strong><span class="muted">You currently have ${state.teams.length} team(s). Add at least two teams in the Teams tab before creating a match.</span><button type="button" class="btn btn-primary btn-sm" id="go-create-teams">Go to Teams</button></section>`
        : `<form id="create-match-form" class="card">
            <h2>Create New Match</h2>
            <div class="grid-2">
              <label class="field">Team A *<select name="teamA" id="mc-team-a" required>${teamOptions}</select></label>
              <label class="field">Team B *<select name="teamB" id="mc-team-b" required>${teamOptions}</select></label>
              <label class="field">Format *
                <select name="format" id="mc-format">
                  <option value="T10">T10 (10 Overs)</option>
                  <option value="T20" selected>T20 (20 Overs)</option>
                  <option value="ODI">ODI (50 Overs)</option>
                  <option value="TEST">Test Cricket (Up to 5 Days, 4 Innings)</option>
                  <option value="CUSTOM">Custom Overs</option>
                </select>
              </label>
              <label class="field" id="mc-overs-wrap">Overs per Innings
                <input type="number" name="overs" id="mc-overs" value="20" min="1" max="450" />
              </label>
              <label class="field">Match Date<input type="date" name="matchDate" value="${new Date().toISOString().slice(0, 10)}" /></label>
              <label class="field">Venue<input name="venue" placeholder="e.g. Sher-e-Bangla Stadium" /></label>
              <label class="field">Tournament (Optional)
                <select name="tournamentId"><option value="">Friendly / Standalone</option>${tourneyOptions}</select>
              </label>
              <label class="field">Match Status
                <select name="status">
                  <option value="LIVE" selected>Live</option>
                  <option value="UPCOMING">Upcoming</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="ABANDONED">Abandoned</option>
                </select>
              </label>
              <label class="field">Toss Winner
                <select name="tossWinner" id="mc-toss-winner"></select>
              </label>
              <label class="field">Toss Decision
                <select name="tossDecision">
                  <option value="Bat">Bat</option>
                  <option value="Bowl">Bowl</option>
                </select>
              </label>
            </div>

            <div class="grid-2" id="mc-lineups-container"></div>

            <button type="submit" class="btn btn-primary">Validate &amp; Create Match</button>
          </form>`
    }

    <section class="grid-2">
      ${
        state.matches.length === 0
          ? `<div class="card"><strong>No matches created yet</strong><span class="muted">Matches you create will persist offline in IndexedDB.</span></div>`
          : state.matches
              .map((m) => {
                const calc = recalculateMatch(m);
                const inn = calc.innings[0];
                return `
                  <article class="card">
                    <div class="row-between">
                      <strong>${esc(m.teamA)} vs ${esc(m.teamB)}</strong>
                      <span class="badge">${esc(m.format)} • ${esc(m.status)}</span>
                    </div>
                    <div class="muted">${esc(m.venue || "Local Ground")} • ${esc(m.matchDate || "")}</div>
                    <div class="muted">${esc(inn.battingTeam)}: ${inn.runs}/${inn.wickets} (${inn.oversText} ov) ${calc.resultSummary ? `• ${esc(calc.resultSummary)}` : ""}</div>
                    <div class="row-gap">
                      <button type="button" class="btn btn-primary btn-sm" data-open-match="${esc(m.id)}">Score / View Details</button>
                      <button type="button" class="btn btn-danger btn-sm" data-del-match="${esc(m.id)}">Delete</button>
                    </div>
                  </article>`;
              })
              .join("")
      }
    </section>
  `;

  main.querySelector("#go-create-teams")?.addEventListener("click", () => navigate("teams"));

  const form = main.querySelector("#create-match-form");
  if (form) {
    const selA = form.querySelector("#mc-team-a");
    const selB = form.querySelector("#mc-team-b");
    const tossSel = form.querySelector("#mc-toss-winner");
    const fmtSel = form.querySelector("#mc-format");
    const ovInput = form.querySelector("#mc-overs");
    const ovWrap = form.querySelector("#mc-overs-wrap");
    const lineupsBox = form.querySelector("#mc-lineups-container");

    if (state.teams.length >= 2) selB.selectedIndex = 1;

    const renderTeamLineupBlock = (teamName, side) => {
      const squad = state.players.filter((p) => p.teamName === teamName);
      if (squad.length === 0) {
        return `<div class="stat-cell"><strong>${esc(teamName)} Playing XI</strong><div class="muted">No squad players added yet — defaults will be available in Live Scorer.</div></div>`;
      }
      const capDefault = squad.find((p) => p.isCaptain)?.fullName || squad[0].fullName;
      const wkDefault = squad.find((p) => p.role === "Wicketkeeper")?.fullName || squad[0].fullName;
      const opts = squad.map((p) => `<option value="${esc(p.fullName)}">${esc(p.fullName)}</option>`).join("");
      return `
        <div class="stat-cell">
          <strong>${esc(teamName)} Playing XI (Select up to 11)</strong>
          <div class="xi-grid" style="margin-top:8px;">
            ${squad
              .map(
                (p, idx) => `<label class="xi-item"><input type="checkbox" name="xi_${side}" value="${esc(p.fullName)}" ${idx < 11 ? "checked" : ""} /> <span>#${esc(p.jerseyNumber)} ${esc(p.fullName)}</span></label>`
              )
              .join("")}
          </div>
          <div class="grid-2" style="margin-top:8px;">
            <label class="field">Captain<select name="cap_${side}">${opts.replace(`value="${esc(capDefault)}"`, `value="${esc(capDefault)}" selected`)}</select></label>
            <label class="field">Wicketkeeper<select name="wk_${side}">${opts.replace(`value="${esc(wkDefault)}"`, `value="${esc(wkDefault)}" selected`)}</select></label>
          </div>
        </div>`;
    };

    const syncTeamDependents = () => {
      tossSel.innerHTML = `<option value="${esc(selA.value)}">${esc(selA.value)}</option><option value="${esc(selB.value)}">${esc(selB.value)}</option>`;
      lineupsBox.innerHTML = `${renderTeamLineupBlock(selA.value, "A")}${renderTeamLineupBlock(selB.value, "B")}`;
    };
    syncTeamDependents();
    selA.onchange = syncTeamDependents;
    selB.onchange = syncTeamDependents;

    fmtSel.onchange = () => {
      const cfg = getFormatConfig(fmtSel.value);
      ovWrap.style.display = cfg.key === "TEST" ? "none" : "flex";
      if (cfg.maxOvers) ovInput.value = cfg.maxOvers;
    };

    form.onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const teamA = String(fd.get("teamA"));
      const teamB = String(fd.get("teamB"));
      if (teamA === teamB) {
        showToast("A team cannot play against itself. Select two different teams.");
        return;
      }

      const selectedXA = fd.getAll("xi_A").map(String);
      const selectedXB = fd.getAll("xi_B").map(String);
      if (selectedXA.length > 11 || selectedXB.length > 11) {
        showToast("Playing XI cannot exceed 11 players per team.");
        return;
      }

      const fmt = String(fd.get("format"));
      const overs = fmt === "TEST" ? null : Math.max(1, Number(fd.get("overs")) || 20);
      const tossWinner = String(fd.get("tossWinner"));
      const tossDecision = String(fd.get("tossDecision"));
      const firstBattingTeam =
        tossDecision === "Bat" ? tossWinner : tossWinner === teamA ? teamB : teamA;

      const match = {
        id: uid("match"),
        teamA,
        teamB,
        format: fmt,
        overs,
        matchDate: String(fd.get("matchDate")),
        venue: String(fd.get("venue")).trim(),
        tournamentId: String(fd.get("tournamentId")) || null,
        status: String(fd.get("status")),
        tossWinner,
        tossDecision,
        firstBattingTeam,
        teamAXI: selectedXA,
        teamBXI: selectedXB,
        teamACaptain: String(fd.get("cap_A") || ""),
        teamAWicketkeeper: String(fd.get("wk_A") || ""),
        teamBCaptain: String(fd.get("cap_B") || ""),
        teamBWicketkeeper: String(fd.get("wk_B") || ""),
        currentInnings: 0,
        currentDay: 1,
        followOnEnforced: false,
        declaredInnings: {},
        ballEvents: [],
        updatedAt: Date.now()
      };

      await putRecord("matches", match);
      state.selectedMatchId = match.id;
      state.matchTab = "live";
      state.scorerPanel = null;
      await loadStateFromDb();
      showToast("Match created and saved to IndexedDB.");
      renderAll();
    };
  }

  main.querySelectorAll("[data-open-match]").forEach((b) => {
    b.onclick = () => {
      state.selectedMatchId = b.getAttribute("data-open-match");
      state.matchTab = "live";
      state.scorerPanel = null;
      renderAll();
    };
  });
  main.querySelectorAll("[data-del-match]").forEach((b) => {
    b.onclick = async () => {
      if (!window.confirm("Delete this match and its ball events?")) return;
      await deleteRecord("matches", b.getAttribute("data-del-match"));
      await loadStateFromDb();
      renderAll();
    };
  });
}

// ---------- TOURNAMENT MANAGEMENT (777) ----------
function renderTournaments(main) {
  const activeTourney = state.tournaments.find((tr) => tr.id === state.selectedTournamentId) || null;

  if (activeTourney) {
    const linkedMatches = state.matches.filter((m) => m.tournamentId === activeTourney.id);
    const groups = activeTourney.groups || [];
    const selectedGroup =
      groups.find((g) => g.name === state.selectedGroupFilter) || null;
    const tableTeams = selectedGroup ? selectedGroup.teams : (activeTourney.teams || []);
    const tableFixtures = selectedGroup
      ? (activeTourney.fixtures || []).filter((f) => f.group === selectedGroup.name)
      : (activeTourney.fixtures || []);
    const tableQualify = selectedGroup ? 2 : (activeTourney.qualifyCount || 4);

    const standings = calculateTournamentStandings(
      tableTeams,
      tableFixtures,
      linkedMatches,
      activeTourney.overs,
      tableQualify
    );
    const overallStandings = calculateTournamentStandings(
      activeTourney.teams || [],
      activeTourney.fixtures || [],
      linkedMatches,
      activeTourney.overs,
      activeTourney.qualifyCount || 4
    );

    const recFixture = (activeTourney.fixtures || []).find((f) => f.id === state.recordingFixtureId) || null;
    const editFixture = (activeTourney.fixtures || []).find((f) => f.id === state.editingFixtureId) || null;

    main.innerHTML = `
      <div class="page-title-row">
        <h1>${esc(activeTourney.name)} (${(activeTourney.teams || []).length} Teams • ${esc(activeTourney.format)})</h1>
        <button type="button" class="btn btn-outline btn-sm" id="back-to-tourneys">All Tournaments</button>
      </div>

      <section class="card card-highlight">
        <div class="row-between">
          <div class="row-gap">
            ${activeTourney.logoDataUrl ? `<img src="${activeTourney.logoDataUrl}" alt="${esc(activeTourney.name)} logo" width="56" height="56" style="border-radius:12px;object-fit:cover;" />` : ""}
            <div>
              <strong>${esc(activeTourney.location || "Regional / Arena")} • ${esc(activeTourney.startDate || "")}${activeTourney.endDate ? ` to ${esc(activeTourney.endDate)}` : ""}</strong>
              <div class="muted">Fixtures: ${(activeTourney.fixtures || []).length} • Overs/Match: ${activeTourney.overs} ${activeTourney.champion ? `• 🏆 Champion: ${esc(activeTourney.champion)}` : ""}</div>
            </div>
          </div>
          <div class="row-gap">
            <button type="button" class="btn btn-white btn-sm" data-gen-ko="AUTO">Advance Knockouts</button>
            <button type="button" class="btn btn-ghost btn-sm" data-gen-ko="Quarter-Final">Quarter-Finals</button>
            <button type="button" class="btn btn-ghost btn-sm" data-gen-ko="Semi-Final">Semi-Finals</button>
            <button type="button" class="btn btn-ghost btn-sm" data-gen-ko="Final">Final</button>
          </div>
        </div>
      </section>

      ${
        recFixture
          ? `<form id="record-fixture-form" class="inline-panel">
              <div class="row-between">
                <strong>Record Result: ${esc(recFixture.teamA)} vs ${esc(recFixture.teamB)} (${esc(recFixture.stage)})</strong>
                <button type="button" class="btn btn-outline btn-sm" id="cancel-rec-fx">Cancel</button>
              </div>
              <div class="grid-3">
                <label class="field">${esc(recFixture.teamA)} Runs<input type="number" name="runsA" min="0" value="160" required /></label>
                <label class="field">${esc(recFixture.teamA)} Overs Faced<input type="number" step="0.1" name="oversA" min="0" max="${activeTourney.overs}" value="${activeTourney.overs}" required /></label>
                <label class="row-gap"><input type="checkbox" name="allOutA" style="width:auto;min-height:auto;" /> ${esc(recFixture.teamA)} All Out (full ${activeTourney.overs} ov NRR)</label>
                <label class="field">${esc(recFixture.teamB)} Runs<input type="number" name="runsB" min="0" value="145" required /></label>
                <label class="field">${esc(recFixture.teamB)} Overs Faced<input type="number" step="0.1" name="oversB" min="0" max="${activeTourney.overs}" value="${activeTourney.overs}" required /></label>
                <label class="row-gap"><input type="checkbox" name="allOutB" style="width:auto;min-height:auto;" /> ${esc(recFixture.teamB)} All Out (full ${activeTourney.overs} ov NRR)</label>
              </div>
              <label class="row-gap"><input type="checkbox" name="abandoned" style="width:auto;min-height:auto;" /> Abandoned / No Result (1 point each, excluded from NRR)</label>
              <button type="submit" class="btn btn-primary btn-sm">Save Fixture Result &amp; Update NRR</button>
            </form>`
          : ""
      }

      ${
        editFixture
          ? `<form id="edit-fixture-form" class="inline-panel">
              <div class="row-between">
                <strong>Edit Fixture (${esc(editFixture.stage)})</strong>
                <button type="button" class="btn btn-outline btn-sm" id="cancel-edit-fx">Cancel</button>
              </div>
              <div class="grid-2">
                <label class="field">Team A<input name="teamA" value="${esc(editFixture.teamA)}" required /></label>
                <label class="field">Team B<input name="teamB" value="${esc(editFixture.teamB)}" required /></label>
              </div>
              <button type="submit" class="btn btn-primary btn-sm">Save Fixture</button>
            </form>`
          : ""
      }

      <section class="card">
        <div class="row-between">
          <h2>Points Table &amp; Official NRR (All-Out Quota Rule Applied)</h2>
          ${
            groups.length > 0
              ? `<select id="group-filter-sel" style="max-width:180px;" aria-label="Filter points table by group">
                  <option value="ALL">All Teams (${(activeTourney.teams || []).length})</option>
                  ${groups.map((g) => `<option value="${esc(g.name)}" ${state.selectedGroupFilter === g.name ? "selected" : ""}>${esc(g.name)}</option>`).join("")}
                </select>`
              : ""
          }
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>#</th><th>Team</th><th>P</th><th>W</th><th>L</th><th>T</th><th>NR</th><th>Pts</th><th>RF/OF</th><th>RA/OB</th><th>NRR</th><th>Status</th></tr>
            </thead>
            <tbody>
              ${standings
                .map(
                  (r, idx) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td><strong>${esc(r.team)}</strong></td>
                  <td>${r.played}</td><td>${r.won}</td><td>${r.lost}</td><td>${r.tied}</td><td>${r.noResult}</td>
                  <td><strong>${r.points}</strong></td>
                  <td>${r.runsFor}/${r.oversFacedText}</td>
                  <td>${r.runsAgainst}/${r.oversBowledText}</td>
                  <td>${r.nrr >= 0 ? "+" : ""}${r.nrr.toFixed(3)}</td>
                  <td>${r.qualified ? `<span class="badge">Q</span>` : "—"}</td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>

      <section class="card">
        <h2>Fixtures (${(activeTourney.fixtures || []).length})</h2>
        <div style="max-height:360px;overflow:auto;display:flex;flex-direction:column;gap:8px;">
          ${(activeTourney.fixtures || [])
            .map(
              (fx) => `
            <div class="stat-cell row-between">
              <div>
                <strong>${esc(fx.stage)}${fx.group ? ` (${esc(fx.group)})` : ""}: ${esc(fx.teamA)} vs ${esc(fx.teamB)}</strong>
                <div class="muted">Status: ${esc(fx.status)}${fx.result ? ` • ${fx.result.abandoned ? "Abandoned (1 pt each)" : `${fx.result.runsA} vs ${fx.result.runsB}`}` : ""}</div>
              </div>
              <div class="row-gap">
                <button type="button" class="btn btn-primary btn-sm" data-rec-fx="${esc(fx.id)}">Record Result</button>
                <button type="button" class="btn btn-outline btn-sm" data-score-fx="${esc(fx.id)}">Score Live</button>
                <button type="button" class="btn btn-outline btn-sm" data-edit-fx="${esc(fx.id)}">Edit</button>
              </div>
            </div>`
            )
            .join("")}
        </div>
      </section>
    `;

    main.querySelector("#back-to-tourneys").onclick = () => {
      state.selectedTournamentId = null;
      state.selectedGroupFilter = "ALL";
      state.recordingFixtureId = null;
      state.editingFixtureId = null;
      renderAll();
    };

    main.querySelector("#group-filter-sel")?.addEventListener("change", (e) => {
      state.selectedGroupFilter = e.target.value;
      renderAll();
    });

    main.querySelectorAll("[data-gen-ko]").forEach((btn) => {
      btn.onclick = async () => {
        const targetStage = btn.getAttribute("data-gen-ko");
        const { stage, fixtures } = generateNextKnockoutRound(
          activeTourney.fixtures || [],
          overallStandings,
          linkedMatches,
          targetStage
        );
        if (!fixtures.length) {
          showToast("Not enough teams or completed knockout results to generate that stage yet.");
          return;
        }
        activeTourney.fixtures = [...(activeTourney.fixtures || []), ...fixtures];
        activeTourney.updatedAt = Date.now();
        await putRecord("tournaments", activeTourney);
        showToast(`Generated ${fixtures.length} ${stage} fixture(s).`);
        renderAll();
      };
    });

    main.querySelectorAll("[data-rec-fx]").forEach((btn) => {
      btn.onclick = () => {
        state.recordingFixtureId = btn.getAttribute("data-rec-fx");
        state.editingFixtureId = null;
        renderAll();
      };
    });
    main.querySelector("#cancel-rec-fx")?.addEventListener("click", () => {
      state.recordingFixtureId = null;
      renderAll();
    });
    main.querySelector("#record-fixture-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!recFixture) return;
      const fd = new FormData(e.target);
      const abandoned = fd.get("abandoned") === "on";
      if (abandoned) {
        recFixture.status = "ABANDONED";
        recFixture.result = { abandoned: true };
      } else {
        const runsA = Number(fd.get("runsA")) || 0;
        const oversA = Number(fd.get("oversA")) || activeTourney.overs;
        const allOutA = fd.get("allOutA") === "on";
        const runsB = Number(fd.get("runsB")) || 0;
        const oversB = Number(fd.get("oversB")) || activeTourney.overs;
        const allOutB = fd.get("allOutB") === "on";
        const toBalls = (ov) => Math.floor(ov) * 6 + Math.round((ov % 1) * 10);
        recFixture.status = "COMPLETED";
        recFixture.result = {
          runsA,
          ballsA: toBalls(oversA),
          allOutA,
          runsB,
          ballsB: toBalls(oversB),
          allOutB,
          abandoned: false
        };
        if (recFixture.stage === "Final" && runsA !== runsB) {
          activeTourney.champion = runsA > runsB ? recFixture.teamA : recFixture.teamB;
        }
      }
      state.recordingFixtureId = null;
      activeTourney.updatedAt = Date.now();
      await putRecord("tournaments", activeTourney);
      showToast("Fixture result saved.");
      renderAll();
    });

    main.querySelectorAll("[data-edit-fx]").forEach((btn) => {
      btn.onclick = () => {
        state.editingFixtureId = btn.getAttribute("data-edit-fx");
        state.recordingFixtureId = null;
        renderAll();
      };
    });
    main.querySelector("#cancel-edit-fx")?.addEventListener("click", () => {
      state.editingFixtureId = null;
      renderAll();
    });
    main.querySelector("#edit-fixture-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!editFixture) return;
      const fd = new FormData(e.target);
      const tA = String(fd.get("teamA")).trim();
      const tB = String(fd.get("teamB")).trim();
      if (!tA || !tB || tA === tB) {
        showToast("Enter two distinct team names.");
        return;
      }
      editFixture.teamA = tA;
      editFixture.teamB = tB;
      state.editingFixtureId = null;
      activeTourney.updatedAt = Date.now();
      await putRecord("tournaments", activeTourney);
      showToast("Fixture updated.");
      renderAll();
    });

    main.querySelectorAll("[data-score-fx]").forEach((btn) => {
      btn.onclick = async () => {
        const fx = activeTourney.fixtures.find((f) => f.id === btn.getAttribute("data-score-fx"));
        if (!fx) return;
        const match = {
          id: uid("match"),
          teamA: fx.teamA,
          teamB: fx.teamB,
          format: activeTourney.overs <= 10 ? "T10" : activeTourney.overs === 50 ? "ODI" : activeTourney.overs === 20 ? "T20" : "CUSTOM",
          overs: activeTourney.overs,
          matchDate: new Date().toISOString().slice(0, 10),
          venue: activeTourney.location || "Tournament Ground",
          tournamentId: activeTourney.id,
          status: "LIVE",
          tossWinner: fx.teamA,
          tossDecision: "Bat",
          firstBattingTeam: fx.teamA,
          teamAXI: state.players.filter((p) => p.teamName === fx.teamA).slice(0, 11).map((p) => p.fullName),
          teamBXI: state.players.filter((p) => p.teamName === fx.teamB).slice(0, 11).map((p) => p.fullName),
          currentInnings: 0,
          currentDay: 1,
          followOnEnforced: false,
          declaredInnings: {},
          ballEvents: [],
          updatedAt: Date.now()
        };
        await putRecord("matches", match);
        fx.result = { ...(fx.result || {}), linkedMatchId: match.id };
        await putRecord("tournaments", activeTourney);
        await loadStateFromDb();
        state.selectedMatchId = match.id;
        state.matchTab = "live";
        navigate("matches");
      };
    });
    return;
  }

  const editingTourney = state.tournaments.find((tr) => tr.id === state.editingTournamentId) || null;

  main.innerHTML = `
    <div class="page-title-row">
      <h1>Tournament Management (20, 24, 32, 40, 50+ Teams)</h1>
    </div>

    <form id="create-tourney-form" class="card">
      <h2>${editingTourney ? `Edit Tournament: ${esc(editingTourney.name)}` : "Create Tournament"}</h2>
      <div class="grid-3">
        <label class="field">Tournament Name *<input name="name" required value="${esc(editingTourney?.name || "")}" placeholder="e.g. National Premier Cup" /></label>
        <label class="field">Format
          <select name="format" ${editingTourney ? "disabled" : ""}>
            ${["GROUPS", "ROUND_ROBIN", "LEAGUE", "KNOCKOUT", "HYBRID"]
              .map((fmt) => `<option value="${fmt}" ${editingTourney?.format === fmt ? "selected" : ""}>${fmt.replace("_", " ")}</option>`)
              .join("")}
          </select>
        </label>
        <label class="field">Team Count (20, 24, 32, 40, 50+ or custom)
          <input type="number" name="teamCount" value="${editingTourney ? (editingTourney.teams || []).length : 20}" min="4" max="128" ${editingTourney ? "disabled" : "required"} />
        </label>
        <label class="field">Overs per Match<input type="number" name="overs" value="${editingTourney?.overs || 20}" min="5" max="50" required /></label>
        <label class="field">Location<input name="location" value="${esc(editingTourney?.location || "")}" placeholder="e.g. Dhaka / National" /></label>
        <label class="field">Start Date<input type="date" name="startDate" value="${esc(editingTourney?.startDate || new Date().toISOString().slice(0, 10))}" /></label>
        <label class="field">End Date<input type="date" name="endDate" value="${esc(editingTourney?.endDate || "")}" /></label>
        <label class="field">Tournament Logo (Optional)<input type="file" name="logoFile" accept="image/*" /></label>
      </div>
      <div class="row-gap">
        <button type="submit" class="btn btn-primary">${editingTourney ? "Save Tournament Changes" : "Generate Tournament, Fixtures & Points Table"}</button>
        ${editingTourney ? `<button type="button" class="btn btn-outline" id="cancel-edit-tourney">Cancel</button>` : ""}
      </div>
    </form>

    <section class="grid-2">
      ${
        state.tournaments.length === 0
          ? `<div class="card"><strong>No tournaments created yet</strong><span class="muted">Create a 20–50+ team tournament above to auto-generate duplicate-free fixtures and track NRR.</span></div>`
          : state.tournaments
              .map(
                (tr) => `
            <article class="card">
              <div class="row-between">
                <div class="row-gap">
                  ${tr.logoDataUrl ? `<img src="${tr.logoDataUrl}" alt="${esc(tr.name)} logo" width="40" height="40" style="border-radius:10px;object-fit:cover;" />` : ""}
                  <strong>${esc(tr.name)}</strong>
                </div>
                <span class="badge">${(tr.teams || []).length} Teams • ${esc(tr.format)}</span>
              </div>
              <div class="muted">${(tr.fixtures || []).length} Fixtures • ${tr.overs} Overs ${tr.champion ? `• 🏆 ${esc(tr.champion)}` : ""}</div>
              <div class="row-gap">
                <button type="button" class="btn btn-primary btn-sm" data-open-tourney="${esc(tr.id)}">Open Fixtures &amp; Table</button>
                <button type="button" class="btn btn-outline btn-sm" data-edit-tourney="${esc(tr.id)}">Edit</button>
                <button type="button" class="btn btn-danger btn-sm" data-del-tourney="${esc(tr.id)}">Delete</button>
              </div>
            </article>`
              )
              .join("")
      }
    </section>
  `;

  main.querySelector("#cancel-edit-tourney")?.addEventListener("click", () => {
    state.editingTournamentId = null;
    renderAll();
  });

  main.querySelector("#create-tourney-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const logoFile = fd.get("logoFile");
    let logoDataUrl = editingTourney?.logoDataUrl || null;
    if (logoFile && logoFile.size > 0) {
      try {
        logoDataUrl = await readImageAsDataUrl(logoFile);
      } catch (err) {
        showToast(err.message);
        return;
      }
    }

    if (editingTourney) {
      await putRecord("tournaments", {
        ...editingTourney,
        name: String(fd.get("name")).trim(),
        overs: Math.max(5, Number(fd.get("overs")) || 20),
        location: String(fd.get("location")).trim(),
        startDate: String(fd.get("startDate")),
        endDate: String(fd.get("endDate") || ""),
        logoDataUrl,
        updatedAt: Date.now()
      });
      state.editingTournamentId = null;
      await loadStateFromDb();
      showToast("Tournament updated.");
      renderAll();
      return;
    }

    const count = Math.max(4, Number(fd.get("teamCount")) || 20);
    const format = String(fd.get("format"));
    const teams = Array.from({ length: count }, (_, idx) => state.teams[idx]?.name || `Team ${idx + 1}`);
    const { groups, fixtures } = generateTournamentFixtures(teams, format, 4);

    const tournament = {
      id: uid("tour"),
      name: String(fd.get("name")).trim(),
      format,
      overs: Math.max(5, Number(fd.get("overs")) || 20),
      location: String(fd.get("location")).trim(),
      startDate: String(fd.get("startDate")),
      endDate: String(fd.get("endDate") || ""),
      logoDataUrl,
      qualifyCount: Math.min(8, Math.max(2, Math.floor(count / 4))),
      teams,
      groups,
      fixtures,
      champion: null,
      updatedAt: Date.now()
    };
    await putRecord("tournaments", tournament);
    state.selectedTournamentId = tournament.id;
    await loadStateFromDb();
    showToast(`Created ${tournament.name} with ${fixtures.length} fixtures.`);
    renderAll();
  };

  main.querySelectorAll("[data-open-tourney]").forEach((b) => {
    b.onclick = () => {
      state.selectedTournamentId = b.getAttribute("data-open-tourney");
      state.selectedGroupFilter = "ALL";
      renderAll();
    };
  });
  main.querySelectorAll("[data-edit-tourney]").forEach((b) => {
    b.onclick = () => {
      state.editingTournamentId = b.getAttribute("data-edit-tourney");
      renderAll();
    };
  });
  main.querySelectorAll("[data-del-tourney]").forEach((b) => {
    b.onclick = async () => {
      if (!window.confirm("Delete this tournament?")) return;
      await deleteRecord("tournaments", b.getAttribute("data-del-tourney"));
      await loadStateFromDb();
      renderAll();
    };
  });
}

// ---------- PLAYER STATISTICS & LEADERBOARDS (888) ----------
function renderStatistics(main) {
  const analytics = computePlayerStatisticsAndLeaderboards(state.players, state.matches, state.statsFilter);
  const selectedPlayerStat = analytics.playerStats.find((s) => s.name === state.selectedPlayerName) || null;

  if (selectedPlayerStat) {
    main.innerHTML = `
      <div class="page-title-row">
        <h1>${esc(selectedPlayerStat.name)} — Career Statistics</h1>
        <button type="button" class="btn btn-outline btn-sm" id="back-to-stats">Back to Leaderboards</button>
      </div>

      <section class="card card-highlight">
        <strong>${esc(selectedPlayerStat.name)} (${esc(selectedPlayerStat.team)})</strong>
        <div class="muted">Computed directly from ${analytics.matchCount} saved match(es) — deduplicated by Match ID.</div>
      </section>

      <section class="card">
        <h2>Batting Career</h2>
        <div class="grid-4">
          <div class="stat-cell"><div class="label">Innings</div><div class="value">${selectedPlayerStat.innings}</div></div>
          <div class="stat-cell"><div class="label">Not Outs</div><div class="value">${selectedPlayerStat.notOuts}</div></div>
          <div class="stat-cell"><div class="label">Runs</div><div class="value">${selectedPlayerStat.runs}</div></div>
          <div class="stat-cell"><div class="label">Highest</div><div class="value">${selectedPlayerStat.highestScore}${selectedPlayerStat.highestNotOut ? "*" : ""}</div></div>
          <div class="stat-cell"><div class="label">Average</div><div class="value">${selectedPlayerStat.battingAverage !== null ? selectedPlayerStat.battingAverage.toFixed(2) : "—"}</div></div>
          <div class="stat-cell"><div class="label">Strike Rate</div><div class="value">${selectedPlayerStat.strikeRate !== null ? selectedPlayerStat.strikeRate.toFixed(2) : "—"}</div></div>
          <div class="stat-cell"><div class="label">100s / 50s</div><div class="value">${selectedPlayerStat.hundreds} / ${selectedPlayerStat.fifties}</div></div>
          <div class="stat-cell"><div class="label">4s / 6s</div><div class="value">${selectedPlayerStat.fours} / ${selectedPlayerStat.sixes}</div></div>
        </div>
      </section>

      <section class="card">
        <h2>Bowling Career</h2>
        <div class="grid-4">
          <div class="stat-cell"><div class="label">Overs</div><div class="value">${selectedPlayerStat.oversBowledText}</div></div>
          <div class="stat-cell"><div class="label">Maidens</div><div class="value">${selectedPlayerStat.maidens}</div></div>
          <div class="stat-cell"><div class="label">Runs Conceded</div><div class="value">${selectedPlayerStat.runsConceded}</div></div>
          <div class="stat-cell"><div class="label">Wickets</div><div class="value">${selectedPlayerStat.wickets}</div></div>
          <div class="stat-cell"><div class="label">Best Figures</div><div class="value">${esc(selectedPlayerStat.bestBowlingText)}</div></div>
          <div class="stat-cell"><div class="label">Bowling Avg</div><div class="value">${selectedPlayerStat.bowlingAverage !== null ? selectedPlayerStat.bowlingAverage.toFixed(2) : "—"}</div></div>
          <div class="stat-cell"><div class="label">Economy</div><div class="value">${selectedPlayerStat.economyRate !== null ? selectedPlayerStat.economyRate.toFixed(2) : "—"}</div></div>
          <div class="stat-cell"><div class="label">Bowling SR</div><div class="value">${selectedPlayerStat.bowlingStrikeRate !== null ? selectedPlayerStat.bowlingStrikeRate.toFixed(1) : "—"}</div></div>
        </div>
      </section>

      <section class="card">
        <h2>Match-by-Match Performance</h2>
        ${selectedPlayerStat.matchPerformances.map((mp) => `<div class="stat-cell row-between"><span><strong>${esc(mp.matchTitle)}</strong> (${esc(mp.format)} • ${esc(mp.date)})</span><span>${esc(mp.type)}: <strong>${esc(mp.summary)}</strong></span></div>`).join("")}
      </section>
    `;

    main.querySelector("#back-to-stats").onclick = () => {
      state.selectedPlayerName = null;
      renderAll();
    };
    return;
  }

  const lbTabs = [
    ["mostRuns", "Most Runs"],
    ["highestScore", "Highest Score"],
    ["bestBattingAverage", "Best Batting Avg"],
    ["bestStrikeRate", "Best Strike Rate"],
    ["mostWickets", "Most Wickets"],
    ["bestBowlingFigures", "Best Bowling"],
    ["bestEconomy", "Best Economy"],
    ["mostFours", "Most 4s"],
    ["mostSixes", "Most 6s"]
  ];
  const activeBoard = analytics.leaderboards[state.leaderboardKey] || [];

  main.innerHTML = `
    <div class="page-title-row">
      <h1>Player Statistics &amp; Leaderboards</h1>
    </div>

    <section class="card">
      <h2>Filters (Event-Derived from ${analytics.matchCount} Saved Match(es))</h2>
      <div class="grid-4">
        <label class="field">Format
          <select id="sf-format">
            <option value="ALL">All Formats</option>
            ${Object.values(CRICKET_FORMATS).map((f) => `<option value="${f.key}" ${state.statsFilter.format === f.key ? "selected" : ""}>${f.label}</option>`).join("")}
          </select>
        </label>
        <label class="field">Tournament
          <select id="sf-tourney">
            <option value="ALL">All Tournaments</option>
            ${state.tournaments.map((tr) => `<option value="${esc(tr.id)}" ${state.statsFilter.tournamentId === tr.id ? "selected" : ""}>${esc(tr.name)}</option>`).join("")}
          </select>
        </label>
        <label class="field">Team
          <select id="sf-team">
            <option value="ALL">All Teams</option>
            ${state.teams.map((tm) => `<option value="${esc(tm.name)}" ${state.statsFilter.teamName === tm.name ? "selected" : ""}>${esc(tm.name)}</option>`).join("")}
          </select>
        </label>
        <label class="field">From Date
          <input type="date" id="sf-date" value="${esc(state.statsFilter.dateFrom)}" />
        </label>
      </div>
    </section>

    <div class="chip-row">
      ${lbTabs.map(([k, lbl]) => `<button type="button" class="chip ${state.leaderboardKey === k ? "active" : ""}" data-lb="${k}">${lbl}</button>`).join("")}
    </div>

    <section class="card">
      <h2>${lbTabs.find(([k]) => k === state.leaderboardKey)?.[1] || "Leaderboard"}</h2>
      ${
        activeBoard.length === 0
          ? `<span class="muted">No match statistics recorded yet for this filter. Score balls in a match to populate real leaderboards.</span>`
          : `<div class="table-wrap">
              <table>
                <thead><tr><th>#</th><th>Player</th><th>Team</th><th>Inn</th><th>Runs</th><th>HS</th><th>Avg</th><th>SR</th><th>Wkts</th><th>Best</th><th>Econ</th><th>4s/6s</th></tr></thead>
                <tbody>
                  ${activeBoard
                    .map(
                      (p, idx) => `
                    <tr>
                      <td>${idx + 1}</td>
                      <td><button type="button" class="btn btn-outline btn-sm" data-stat-player="${esc(p.name)}">${esc(p.name)}</button></td>
                      <td>${esc(p.team)}</td>
                      <td>${p.innings}</td>
                      <td><strong>${p.runs}</strong></td>
                      <td>${p.highestScore}${p.highestNotOut ? "*" : ""}</td>
                      <td>${p.battingAverage !== null ? p.battingAverage.toFixed(1) : "—"}</td>
                      <td>${p.strikeRate !== null ? p.strikeRate.toFixed(1) : "—"}</td>
                      <td><strong>${p.wickets}</strong></td>
                      <td>${esc(p.bestBowlingText)}</td>
                      <td>${p.economyRate !== null ? p.economyRate.toFixed(2) : "—"}</td>
                      <td>${p.fours}/${p.sixes}</td>
                    </tr>`
                    )
                    .join("")}
                </tbody>
              </table>
            </div>`
      }
    </section>
  `;

  main.querySelector("#sf-format").onchange = (e) => {
    state.statsFilter.format = e.target.value;
    renderAll();
  };
  main.querySelector("#sf-tourney").onchange = (e) => {
    state.statsFilter.tournamentId = e.target.value;
    renderAll();
  };
  main.querySelector("#sf-team").onchange = (e) => {
    state.statsFilter.teamName = e.target.value;
    renderAll();
  };
  main.querySelector("#sf-date").onchange = (e) => {
    state.statsFilter.dateFrom = e.target.value;
    renderAll();
  };
  main.querySelectorAll("[data-lb]").forEach((btn) => {
    btn.onclick = () => {
      state.leaderboardKey = btn.getAttribute("data-lb");
      renderAll();
    };
  });
  main.querySelectorAll("[data-stat-player]").forEach((btn) => {
    btn.onclick = () => {
      state.selectedPlayerName = btn.getAttribute("data-stat-player");
      renderAll();
    };
  });
}

// ---------- PERSONAL ACCOUNT & CONTROL PANEL ----------
function renderAccountPanel(main) {
  if (!state.activeUser) {
    main.innerHTML = `
      <div class="page-title-row"><h1>Personal Profile &amp; Account</h1></div>
      <div class="chip-row">
        <button type="button" class="chip ${state.authTab === "login" ? "active" : ""}" data-authtab="login">Login</button>
        <button type="button" class="chip ${state.authTab === "signup" ? "active" : ""}" data-authtab="signup">Sign Up</button>
        <button type="button" class="chip ${state.authTab === "forgot" ? "active" : ""}" data-authtab="forgot">Forgot Password</button>
      </div>

      ${
        state.authTab === "login"
          ? `<form id="auth-login-form" class="card">
              <h2>Login</h2>
              <label class="field">Email or Username<input name="handle" required /></label>
              <label class="field">Password<input type="password" name="password" required /></label>
              <button type="submit" class="btn btn-primary">Login</button>
            </form>`
          : state.authTab === "signup"
          ? `<form id="auth-signup-form" class="card">
              <h2>Create Personal Account</h2>
              <label class="field">Full Name *<input name="fullName" required /></label>
              <label class="field">Email or Username * (min 3 chars)<input name="handle" required minlength="3" /></label>
              <label class="field">Password * (min 6 chars)<input type="password" name="password" required minlength="6" /></label>
              <label class="field">Recovery Code * (min 4 chars — offline reset)<input name="recoveryCode" required minlength="4" /></label>
              <label class="field">City / Phone<input name="cityOrPhone" /></label>
              <label class="field">Bio<textarea name="bio"></textarea></label>
              <button type="submit" class="btn btn-primary">Create Account</button>
            </form>`
          : `<form id="auth-forgot-form" class="card">
              <h2>Reset Password via Recovery Code</h2>
              <label class="field">Email or Username *<input name="handle" required /></label>
              <label class="field">Recovery Code *<input name="recoveryCode" required /></label>
              <label class="field">New Password *<input type="password" name="newPassword" required minlength="6" /></label>
              <button type="submit" class="btn btn-primary">Reset Password</button>
            </form>`
      }
    `;

    main.querySelectorAll("[data-authtab]").forEach((btn) => {
      btn.onclick = () => {
        state.authTab = btn.getAttribute("data-authtab");
        renderAll();
      };
    });

    main.querySelector("#auth-login-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const handle = String(fd.get("handle")).trim().toLowerCase();
      const pwd = String(fd.get("password"));
      const accounts = await getAll("user_accounts");
      const acc = accounts.find((a) => a.emailOrHandle === handle);
      if (!acc || !(await verifySecret(pwd, acc.passwordHash, acc.passwordSalt))) {
        showToast("Invalid credentials.");
        return;
      }
      await setMeta("active_user_id", acc.userId);
      await loadStateFromDb();
      showToast(`Welcome back, ${acc.fullName}`);
      renderAll();
    });

    main.querySelector("#auth-signup-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const handle = String(fd.get("handle")).trim().toLowerCase();
      const accounts = await getAll("user_accounts");
      if (accounts.some((a) => a.emailOrHandle === handle)) {
        showToast("Account already exists.");
        return;
      }
      const userId = `USR-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
      const pwdHash = await hashSecret(String(fd.get("password")));
      const recHash = await hashSecret(String(fd.get("recoveryCode")).trim());
      await putRecord("user_accounts", {
        userId,
        fullName: String(fd.get("fullName")).trim(),
        emailOrHandle: handle,
        cityOrPhone: String(fd.get("cityOrPhone")).trim(),
        bio: String(fd.get("bio")).trim(),
        passwordHash: pwdHash.hashBase64,
        passwordSalt: pwdHash.saltBase64,
        recoveryHash: recHash.hashBase64,
        recoverySalt: recHash.saltBase64,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
      await putRecord("user_settings", {
        userId,
        languageCode: "en",
        themeMode: "DARK",
        notificationsEnabled: false,
        matchStartAlerts: true,
        profilePrivate: true,
        updatedAt: Date.now()
      });
      await setMeta("active_user_id", userId);
      await loadStateFromDb();
      showToast(`Account created! User ID: ${userId}`);
      renderAll();
    });

    main.querySelector("#auth-forgot-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const handle = String(fd.get("handle")).trim().toLowerCase();
      const accounts = await getAll("user_accounts");
      const acc = accounts.find((a) => a.emailOrHandle === handle);
      if (!acc || !(await verifySecret(String(fd.get("recoveryCode")).trim(), acc.recoveryHash, acc.recoverySalt))) {
        showToast("Recovery code mismatch.");
        return;
      }
      const nextHash = await hashSecret(String(fd.get("newPassword")));
      await putRecord("user_accounts", { ...acc, passwordHash: nextHash.hashBase64, passwordSalt: nextHash.saltBase64, updatedAt: Date.now() });
      state.authTab = "login";
      showToast("Password reset! Please login.");
      renderAll();
    });
    return;
  }

  const acc = state.activeUser;
  const set = state.activeSettings;

  main.innerHTML = `
    <div class="page-title-row">
      <h1>${esc(t().personalPanel)}</h1>
      <button type="button" class="btn btn-outline btn-sm" id="logout-btn">Logout</button>
    </div>

    <section class="card card-highlight">
      <strong>${esc(acc.fullName)}</strong>
      <div class="muted">${esc(acc.emailOrHandle)} • User ID: <strong>${esc(acc.userId)}</strong></div>
    </section>

    <form id="edit-profile-form" class="card">
      <h2>My Profile</h2>
      <div class="grid-2">
        <label class="field">Full Name<input name="fullName" value="${esc(acc.fullName)}" required /></label>
        <label class="field">City / Phone<input name="cityOrPhone" value="${esc(acc.cityOrPhone || "")}" /></label>
      </div>
      <label class="field">Bio<textarea name="bio">${esc(acc.bio || "")}</textarea></label>
      <button type="submit" class="btn btn-primary btn-sm">Save Profile</button>
    </form>

    <section class="card">
      <h2>Language, Theme, Notifications &amp; Privacy</h2>
      <div class="row-gap">
        <button type="button" class="chip ${set.languageCode === "en" ? "active" : ""}" data-lang="en">English</button>
        <button type="button" class="chip ${set.languageCode === "bn" ? "active" : ""}" data-lang="bn">বাংলা</button>
        <button type="button" class="chip ${set.themeMode === "DARK" ? "active" : ""}" data-theme-set="DARK">Dark</button>
        <button type="button" class="chip ${set.themeMode === "LIGHT" ? "active" : ""}" data-theme-set="LIGHT">Light</button>
        <button type="button" class="chip ${set.notificationsEnabled ? "active" : ""}" id="toggle-notif">Alerts: ${set.notificationsEnabled ? "ON" : "OFF"}</button>
        <button type="button" class="chip ${set.profilePrivate ? "active" : ""}" id="toggle-privacy">Private: ${set.profilePrivate ? "ON" : "OFF"}</button>
      </div>
    </section>

    <section class="card">
      <h2>Favourites (${state.activeFavourites.length})</h2>
      <form id="add-fav-form" class="row-gap">
        <select name="itemType" style="max-width:130px;">
          <option value="TEAM">Team</option><option value="PLAYER">Player</option><option value="LEAGUE">League</option><option value="MATCH">Match</option>
        </select>
        <input name="displayName" required placeholder="Add Team, Player, League..." list="league-list" style="flex:1;" />
        <datalist id="league-list">${MAJOR_LEAGUES.map((l) => `<option value="${esc(l)}"></option>`).join("")}</datalist>
        <button type="submit" class="btn btn-primary btn-sm">Add</button>
      </form>
      <div class="grid-2">
        ${state.activeFavourites.map((f) => `<div class="stat-cell row-between"><span><strong>${esc(f.displayName)}</strong> (${esc(f.itemType)})</span><button type="button" class="btn btn-danger btn-sm" data-del-fav="${esc(f.id)}">Remove</button></div>`).join("") || `<span class="muted">No favourites added yet.</span>`}
      </div>
    </section>

    <section class="card">
      <h2>Personal Backup &amp; Account Security</h2>
      <div class="row-gap">
        <button type="button" class="btn btn-primary btn-sm" id="export-personal-btn">Download Personal Backup</button>
        <button type="button" class="btn btn-outline btn-sm" id="open-full-backup-btn">Full App Backup &amp; Restore</button>
        <button type="button" class="btn btn-danger btn-sm" id="delete-account-btn">Delete My Account</button>
      </div>
    </section>
  `;

  main.querySelector("#logout-btn").onclick = async () => {
    await setMeta("active_user_id", null);
    await loadStateFromDb();
    renderAll();
  };
  main.querySelector("#open-full-backup-btn").onclick = () => navigate("backup");
  main.querySelector("#edit-profile-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    await putRecord("user_accounts", { ...acc, fullName: String(fd.get("fullName")).trim(), cityOrPhone: String(fd.get("cityOrPhone")).trim(), bio: String(fd.get("bio")).trim(), updatedAt: Date.now() });
    await loadStateFromDb();
    showToast("Profile saved.");
    renderAll();
  };
  main.querySelectorAll("[data-lang]").forEach((b) => {
    b.onclick = async () => {
      await putRecord("user_settings", { ...set, languageCode: b.getAttribute("data-lang"), updatedAt: Date.now() });
      await loadStateFromDb();
      renderAll();
    };
  });
  main.querySelectorAll("[data-theme-set]").forEach((b) => {
    b.onclick = async () => {
      await putRecord("user_settings", { ...set, themeMode: b.getAttribute("data-theme-set"), updatedAt: Date.now() });
      await loadStateFromDb();
      renderAll();
    };
  });
  main.querySelector("#toggle-notif").onclick = async () => {
    await putRecord("user_settings", { ...set, notificationsEnabled: !set.notificationsEnabled, updatedAt: Date.now() });
    await loadStateFromDb();
    renderAll();
  };
  main.querySelector("#toggle-privacy").onclick = async () => {
    await putRecord("user_settings", { ...set, profilePrivate: !set.profilePrivate, updatedAt: Date.now() });
    await loadStateFromDb();
    renderAll();
  };
  main.querySelector("#add-fav-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const type = String(fd.get("itemType"));
    const name = String(fd.get("displayName")).trim();
    const key = name.toLowerCase().replace(/[^a-z0-9]+/g, "_");
    await putRecord("user_favourites", { id: `${acc.userId}::${type}::${key}`, userId: acc.userId, itemType: type, itemKey: key, displayName: name, matchAlertsEnabled: true });
    await loadStateFromDb();
    renderAll();
  };
  main.querySelectorAll("[data-del-fav]").forEach((b) => {
    b.onclick = async () => {
      await deleteRecord("user_favourites", b.getAttribute("data-del-fav"));
      await loadStateFromDb();
      renderAll();
    };
  });
  main.querySelector("#export-personal-btn").onclick = async () => {
    const json = await exportPersonalBackup(acc.userId);
    const blob = new Blob([json], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `cricket_arena_${acc.userId.toLowerCase()}_backup.json`;
    a.click();
    showToast("Personal backup downloaded.");
  };
  main.querySelector("#delete-account-btn").onclick = async () => {
    const pwd = window.prompt(`Enter password to permanently delete ${acc.userId}:`);
    if (!pwd) return;
    if (!(await verifySecret(pwd, acc.passwordHash, acc.passwordSalt))) {
      showToast("Incorrect password.");
      return;
    }
    for (const f of state.activeFavourites) await deleteRecord("user_favourites", f.id);
    await deleteRecord("user_settings", acc.userId);
    await deleteRecord("user_accounts", acc.userId);
    await setMeta("active_user_id", null);
    await loadStateFromDb();
    showToast("Account deleted.");
    renderAll();
  };
}

// ---------- OFFLINE BACKUP & RESTORE (999) ----------
function renderBackup(main) {
  main.innerHTML = `
    <div class="page-title-row"><h1>Offline Storage, Backup &amp; Restore</h1></div>

    <section class="card">
      <h2>Local IndexedDB Summary</h2>
      <div class="grid-4">
        <div class="stat-cell"><div class="label">Teams</div><div class="value">${state.teams.length}</div></div>
        <div class="stat-cell"><div class="label">Players</div><div class="value">${state.players.length}</div></div>
        <div class="stat-cell"><div class="label">Matches</div><div class="value">${state.matches.length}</div></div>
        <div class="stat-cell"><div class="label">Tournaments</div><div class="value">${state.tournaments.length}</div></div>
      </div>
      <div class="muted">All ball events, scorecards, squads, and tournaments are stored locally in IndexedDB and work offline without internet. Cloud sync is not enabled unless explicitly linked later.</div>
      <button type="button" class="btn btn-primary" id="export-full-btn">Export Versioned JSON Backup</button>
    </section>

    <section class="card">
      <h2>Restore Validated Backup</h2>
      <input type="file" id="restore-file-input" accept=".json,application/json" />
      <textarea id="restore-json-text" placeholder="Or paste Cricket Arena JSON backup here..."></textarea>
      <div class="row-gap">
        <button type="button" class="btn btn-primary" id="restore-merge-btn">Merge into Existing Data</button>
        <button type="button" class="btn btn-danger" id="restore-replace-btn">Replace All Data (Confirm)</button>
      </div>
    </section>
  `;

  main.querySelector("#export-full-btn").onclick = async () => {
    const json = await exportFullArenaBackup();
    const blob = new Blob([json], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `cricket_arena_full_backup_${Date.now()}.json`;
    a.click();
    showToast("Versioned full backup downloaded.");
  };

  main.querySelector("#restore-file-input").onchange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    main.querySelector("#restore-json-text").value = await file.text();
  };

  const runRestore = async (replaceExisting) => {
    const raw = main.querySelector("#restore-json-text").value.trim();
    if (!raw) {
      showToast("Load or paste a backup JSON first.");
      return;
    }
    try {
      const parsed = validateFullBackupJson(raw);
      const summary = `${parsed.teams.length} teams, ${parsed.players.length} players, ${parsed.matches.length} matches, ${parsed.tournaments.length} tournaments`;
      const actionMsg = replaceExisting
        ? `REPLACE all existing local data with backup (${summary})?`
        : `MERGE backup (${summary}) into existing local data?`;
      if (!window.confirm(actionMsg)) return;
      await restoreFullArenaBackup(raw, replaceExisting);
      await loadStateFromDb();
      showToast("Backup restored cleanly.");
      renderAll();
    } catch (err) {
      showToast(err.message || "Invalid backup file.");
    }
  };

  main.querySelector("#restore-merge-btn").onclick = () => runRestore(false);
  main.querySelector("#restore-replace-btn").onclick = () => runRestore(true);
}

function renderAll() {
  updateThemeAndMetadata();
  renderNavigation();
  updateOfflineIndicator();

  const main = document.getElementById("main-content");
  if (!main) return;

  switch (state.route) {
    case "matches":
      renderMatches(main);
      break;
    case "teams":
      renderTeams(main);
      break;
    case "tournaments":
      renderTournaments(main);
      break;
    case "stats":
      renderStatistics(main);
      break;
    case "account":
      renderAccountPanel(main);
      break;
    case "backup":
      renderBackup(main);
      break;
    default:
      renderHome(main);
  }
}

function setupInstallExperience() {
  const headerInstall = document.getElementById("header-install-btn");
  const railInstall = document.getElementById("rail-install-btn");
  const banner = document.getElementById("install-banner");
  const bannerAction = document.getElementById("banner-install-action");
  const bannerDismiss = document.getElementById("banner-install-dismiss");

  const triggerInstall = async () => {
    if (state.deferredInstallPrompt) {
      state.deferredInstallPrompt.prompt();
      const choice = await state.deferredInstallPrompt.userChoice;
      state.deferredInstallPrompt = null;
      if (choice.outcome === "accepted") {
        showToast("Cricket Arena installed!");
        banner?.classList.add("hidden");
        headerInstall?.classList.add("hidden");
        railInstall?.classList.add("hidden");
      }
    } else {
      showToast("Open browser menu (⋮) and tap 'Install app' or 'Add to Home screen'.");
    }
  };

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    state.deferredInstallPrompt = event;
    headerInstall?.classList.remove("hidden");
    railInstall?.classList.remove("hidden");
    banner?.classList.remove("hidden");
  });

  window.addEventListener("appinstalled", () => {
    state.deferredInstallPrompt = null;
    banner?.classList.add("hidden");
    headerInstall?.classList.add("hidden");
    railInstall?.classList.add("hidden");
    showToast("Cricket Arena installed on your device.");
  });

  if (headerInstall) headerInstall.onclick = triggerInstall;
  if (railInstall) railInstall.onclick = triggerInstall;
  if (bannerAction) bannerAction.onclick = triggerInstall;
  if (bannerDismiss) bannerDismiss.onclick = () => banner?.classList.add("hidden");
}

async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.register("./sw.js", { scope: "./" });
    if (reg.active) {
      state.swReady = true;
      updateOfflineIndicator();
    }
    navigator.serviceWorker.ready.then(() => {
      state.swReady = true;
      updateOfflineIndicator();
    });
    navigator.serviceWorker.addEventListener("message", (ev) => {
      if (ev.data?.type === "CA_CACHE_READY") {
        state.swReady = true;
        updateOfflineIndicator();
      }
    });
  } catch (err) {
    console.warn("Service worker registration skipped:", err);
  }
}

async function bootstrap() {
  const initialHash = window.location.hash.replace("#", "");
  if (["home", "matches", "teams", "tournaments", "stats", "account", "backup"].includes(initialHash)) {
    state.route = initialHash;
  }

  document.getElementById("header-account-btn").onclick = () => navigate("account");

  window.addEventListener("online", () => {
    state.online = true;
    updateOfflineIndicator();
  });
  window.addEventListener("offline", () => {
    state.online = false;
    updateOfflineIndicator();
  });

  setupInstallExperience();
  await registerServiceWorker();
  await loadStateFromDb();
  renderAll();

  const splash = document.getElementById("splash-screen");
  if (splash) {
    setTimeout(() => splash.classList.add("fade-out"), 200);
  }
}

bootstrap();
