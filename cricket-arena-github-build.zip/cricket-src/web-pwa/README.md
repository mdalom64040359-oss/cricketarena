# Cricket Arena — Web & Installable PWA Edition (`/web-pwa`)

Zero-build-dependency, offline-first Progressive Web App companion alongside the Native Android Kotlin/Compose app.

## Included PWA Files
- `index.html` — Accessible semantic HTML5 shell, Open Graph & PWA metadata, dynamic page titles, branded splash screen, mobile bottom nav, and tablet/desktop navigation rail.
- `styles.css` — Responsive Dark Green / Black / White (+ Light mode) design system for mobile, tablet, and desktop.
- `app.js` — Full SPA logic: Home Dashboard, Ball-by-Ball Live Scoring (`T10`, `T20`, `ODI`, `Test`, `Custom Overs`), Team & Player Profiles (`Not Available` accuracy), 20–50+ Team Tournaments & NRR, Personal Control Panel (`বাংলা` / `English`), and `beforeinstallprompt` install UX.
- `engine.js` — Pure event-sourced cricket rules & calculation engine (`recalculateMatch`, `generateTournamentFixtures`, `calculateTournamentStandings` with All-Out NRR quota, `generateNextKnockoutRound`, `computePlayerStatisticsAndLeaderboards`).
- `db.js` — Browser `IndexedDB` (`cricket_arena_web_v1` v2) storage, Web Crypto PBKDF2-SHA256 salted hashing, and validated JSON Backup/Restore.
- `manifest.webmanifest` — Installable W3C Web App Manifest with `192x192`, `512x512`, and `maskable` PNG icons + splash colors (`#060A08` / `#0A2F1D`).
- `sw.js` & `offline.html` — Pre-caches all shell assets (`cricket-arena-pwa-v2`) for instant offline startup after initial visit.
- `tests/qa.test.mjs` — Automated Node test suite (`node --test tests/qa.test.mjs`).

## Local Preview & QA Tests (No Paid Services)
Run any local static HTTP server inside `web-pwa/`:
```bash
python3 -m http.server 8080
```
Then open `http://localhost:8080` in Chrome. (Service workers work on `localhost` or `https://`.)

Run automated QA tests from project root:
```bash
node --test web-pwa/tests/qa.test.mjs
```
