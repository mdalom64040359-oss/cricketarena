import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  CRICKET_FORMATS,
  ballsToOversText,
  calculateTournamentStandings,
  computePlayerStatisticsAndLeaderboards,
  generateMatchShareSummary,
  generateNextKnockoutRound,
  generateTournamentFixtures,
  getFormatConfig,
  recalculateMatch
} from "../engine.js";
import {
  buildFullBackupJson,
  validateFullBackupJson
} from "../db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEB_PWA_DIR = path.resolve(__dirname, "..");

function makeBall(overrides = {}) {
  return {
    id: `b-${Math.random().toString(36).slice(2, 8)}`,
    inningsIndex: 0,
    strikerName: "Batter 1",
    nonStrikerName: "Batter 2",
    bowlerName: "Bowler 1",
    runsBat: 0,
    extraType: "NONE",
    extraRuns: 0,
    wicket: null,
    ...overrides
  };
}

test("Over & delivery arithmetic never reaches .6 or .7", () => {
  assert.equal(ballsToOversText(0), "0.0");
  assert.equal(ballsToOversText(5), "0.5");
  assert.equal(ballsToOversText(6), "1.0");
  assert.equal(ballsToOversText(7), "1.1");
  assert.equal(ballsToOversText(120), "20.0");
});

test("Ball-by-ball scoring: runs 0-6, extras, Free Hit enforcement, maiden overs, strike rotation, and undo", () => {
  const match = {
    id: "m-t20-1",
    teamA: "Dhaka",
    teamB: "Chattogram",
    format: "T20",
    overs: 20,
    firstBattingTeam: "Dhaka",
    currentInnings: 0,
    status: "LIVE",
    ballEvents: []
  };

  // Maiden over by Bowler 1 (6 dots)
  for (let i = 0; i < 6; i += 1) {
    match.ballEvents.push(makeBall({ runsBat: 0 }));
  }
  let calc = recalculateMatch(match);
  assert.equal(calc.innings[0].oversText, "1.0");
  assert.equal(calc.innings[0].overJustCompleted, true);
  assert.equal(calc.innings[0].bowlers["Bowler 1"].maidens, 1);
  // Strike swaps at end of over -> Batter 2 becomes striker
  assert.equal(calc.innings[0].strikerName, "Batter 2");
  assert.equal(calc.innings[0].nonStrikerName, "Batter 1");

  // Bowler 2 bowls Wide (+1 extra), then No-Ball + 4 off bat, then Free Hit CAUGHT (must be ignored!)
  match.ballEvents.push(makeBall({ strikerName: "Batter 2", nonStrikerName: "Batter 1", bowlerName: "Bowler 2", extraType: "WIDE", extraRuns: 1 }));
  match.ballEvents.push(makeBall({ strikerName: "Batter 2", nonStrikerName: "Batter 1", bowlerName: "Bowler 2", extraType: "NO_BALL", runsBat: 4 }));
  calc = recalculateMatch(match);
  assert.equal(calc.innings[0].nextBallFreeHit, true);
  assert.equal(calc.innings[0].legalBalls, 6); // wide & nb don't increment legal balls
  assert.equal(calc.innings[0].runs, 7); // 2 wide + 1 nb + 4 bat

  // Free hit delivery where fielder tries CAUGHT -> ignored!
  match.ballEvents.push(makeBall({
    strikerName: "Batter 2",
    nonStrikerName: "Batter 1",
    bowlerName: "Bowler 2",
    runsBat: 1,
    wicket: { kind: "CAUGHT", dismissedBatterName: "Batter 2", fielderName: "Keeper" }
  }));
  calc = recalculateMatch(match);
  assert.equal(calc.innings[0].wickets, 0, "Non-runout dismissal must be blocked on Free Hit");
  assert.equal(calc.innings[0].nextBallFreeHit, false);

  // Add Bye (2), Leg-Bye (3), Penalty (+5)
  match.ballEvents.push(makeBall({ strikerName: "Batter 1", nonStrikerName: "Batter 2", bowlerName: "Bowler 2", extraType: "BYE", extraRuns: 2 }));
  match.ballEvents.push(makeBall({ strikerName: "Batter 1", nonStrikerName: "Batter 2", bowlerName: "Bowler 2", extraType: "LEG_BYE", extraRuns: 3 }));
  match.ballEvents.push(makeBall({ strikerName: "Batter 2", nonStrikerName: "Batter 1", bowlerName: "Bowler 2", extraType: "PENALTY", extraRuns: 5 }));

  // Clean wicket (BOWLED)
  match.ballEvents.push(makeBall({
    strikerName: "Batter 2",
    nonStrikerName: "Batter 1",
    bowlerName: "Bowler 2",
    wicket: { kind: "BOWLED", dismissedBatterName: "Batter 2" }
  }));

  calc = recalculateMatch(match);
  assert.equal(calc.innings[0].runs, 7 + 1 + 2 + 3 + 5); // 18
  assert.equal(calc.innings[0].wickets, 1);
  assert.equal(calc.innings[0].legalBalls, 10);
  assert.equal(calc.innings[0].oversText, "1.4");
  assert.equal(calc.innings[0].fallOfWickets.length, 1);
  assert.equal(calc.innings[0].extras.penalty, 5);

  // Undo last delivery restores prior state identically
  match.ballEvents.pop();
  calc = recalculateMatch(match);
  assert.equal(calc.innings[0].wickets, 0);
  assert.equal(calc.innings[0].legalBalls, 9);
});

test("Limited-overs formats (T10, T20, ODI, Custom Overs): target, RRR, chase win, tie", () => {
  assert.equal(getFormatConfig("T10").maxOvers, 10);
  assert.equal(getFormatConfig("T20").maxOvers, 20);
  assert.equal(getFormatConfig("ODI").maxOvers, 50);
  assert.equal(getFormatConfig("CUSTOM", 8).maxOvers, 8);

  // 2-over Custom match chase
  const events = [];
  for (let i = 0; i < 12; i += 1) {
    events.push(makeBall({ inningsIndex: 0, runsBat: i === 0 ? 6 : 1 })); // 17 runs total
  }
  // Innings 2: scores 6 + 6 + 6 = 18 in 3 balls -> wins by 10 wickets
  events.push(makeBall({ inningsIndex: 1, runsBat: 6, strikerName: "Opp 1", nonStrikerName: "Opp 2", bowlerName: "D1" }));
  events.push(makeBall({ inningsIndex: 1, runsBat: 6, strikerName: "Opp 1", nonStrikerName: "Opp 2", bowlerName: "D1" }));
  events.push(makeBall({ inningsIndex: 1, runsBat: 6, strikerName: "Opp 1", nonStrikerName: "Opp 2", bowlerName: "D1" }));

  const calc = recalculateMatch({
    id: "m-cust",
    teamA: "Alpha",
    teamB: "Beta",
    format: "CUSTOM",
    overs: 2,
    firstBattingTeam: "Alpha",
    currentInnings: 1,
    ballEvents: events
  });

  assert.equal(calc.target, 18);
  assert.equal(calc.winnerTeam, "Beta");
  assert.match(calc.resultSummary, /Beta won by 10 wicket/);

  // Tie scenario in 1-over Custom match
  const tieEvents = [
    ...Array.from({ length: 6 }, () => makeBall({ inningsIndex: 0, runsBat: 1 })),
    ...Array.from({ length: 6 }, () => makeBall({ inningsIndex: 1, runsBat: 1 }))
  ];
  const tieCalc = recalculateMatch({
    id: "m-tie",
    teamA: "Alpha",
    teamB: "Beta",
    format: "CUSTOM",
    overs: 1,
    firstBattingTeam: "Alpha",
    currentInnings: 1,
    ballEvents: tieEvents
  });
  assert.equal(tieCalc.isTie, true);
  assert.equal(tieCalc.resultSummary, "Match Tied");
});

test("Test Cricket rules: declaration, follow-on >= 200 lead, innings victory, and 5-day draw", () => {
  // Team A declares on 420/4 (represented via events), Team B all out for 150 -> lead 270 >= 200 -> follow-on available
  const teamAXI = ["A1", "A2", "A3"]; // maxWickets = 2 for compact test
  const teamBXI = ["B1", "B2", "B3"];
  const events = [
    makeBall({ inningsIndex: 0, runsBat: 250, strikerName: "A1", nonStrikerName: "A2", bowlerName: "B1" }),
    // Wait: runsBat clamps 0..7 as a real ball, so accumulate realistic 6s!
  ];
  events.length = 0;
  for (let i = 0; i < 42; i += 1) {
    events.push(makeBall({ inningsIndex: 0, runsBat: 6, strikerName: "A1", nonStrikerName: "A2", bowlerName: "B1" }));
  } // 252 runs in inn 0
  // Innings 1: Team B all out for 12 (2 wickets with 3-player XI) -> deficit 240 >= 200
  events.push(makeBall({ inningsIndex: 1, runsBat: 6, strikerName: "B1", nonStrikerName: "B2", bowlerName: "A1" }));
  events.push(makeBall({ inningsIndex: 1, runsBat: 6, strikerName: "B1", nonStrikerName: "B2", bowlerName: "A1" }));
  events.push(makeBall({ inningsIndex: 1, runsBat: 0, strikerName: "B1", nonStrikerName: "B2", bowlerName: "A1", wicket: { kind: "BOWLED", dismissedBatterName: "B1" } }));
  events.push(makeBall({ inningsIndex: 1, runsBat: 0, strikerName: "B3", nonStrikerName: "B2", bowlerName: "A1", wicket: { kind: "BOWLED", dismissedBatterName: "B3" } }));

  const preFollowOn = recalculateMatch({
    id: "m-test-1",
    teamA: "Tigers",
    teamB: "Lions",
    format: "TEST",
    firstBattingTeam: "Tigers",
    teamAXI,
    teamBXI,
    declaredInnings: { 0: true },
    followOnEnforced: false,
    currentInnings: 1,
    ballEvents: events
  });
  assert.equal(preFollowOn.canEnforceFollowOn, true, "Lead >= 200 must unlock follow-on");

  // Enforce follow-on -> Lions bat innings 2 (their 2nd innings) and get all out for 40 -> Tigers win by an innings and 200 runs
  events.push(makeBall({ inningsIndex: 2, runsBat: 6, strikerName: "B1", nonStrikerName: "B2", bowlerName: "A1" }));
  events.push(makeBall({ inningsIndex: 2, runsBat: 0, strikerName: "B1", nonStrikerName: "B2", bowlerName: "A1", wicket: { kind: "LBW", dismissedBatterName: "B1" } }));
  events.push(makeBall({ inningsIndex: 2, runsBat: 0, strikerName: "B3", nonStrikerName: "B2", bowlerName: "A1", wicket: { kind: "BOWLED", dismissedBatterName: "B3" } }));

  const postFollowOn = recalculateMatch({
    id: "m-test-1",
    teamA: "Tigers",
    teamB: "Lions",
    format: "TEST",
    firstBattingTeam: "Tigers",
    teamAXI,
    teamBXI,
    declaredInnings: { 0: true },
    followOnEnforced: true,
    currentInnings: 2,
    ballEvents: events
  });
  assert.equal(postFollowOn.winnerTeam, "Tigers");
  assert.match(postFollowOn.resultSummary, /Tigers won by an innings and 234 run/);

  // 5-day draw when status completed with no winner
  const drawMatch = recalculateMatch({
    id: "m-test-draw",
    teamA: "Tigers",
    teamB: "Lions",
    format: "TEST",
    firstBattingTeam: "Tigers",
    status: "COMPLETED",
    currentDay: 5,
    currentInnings: 1,
    ballEvents: [makeBall({ inningsIndex: 0, runsBat: 4 })]
  });
  assert.equal(drawMatch.isDraw, true);
  assert.match(drawMatch.resultSummary, /Drawn/);
});

test("Tournament management: 20, 24, 32, 40, 50 teams duplicate-free fixtures + Official All-Out NRR + Knockouts", () => {
  for (const count of [20, 24, 32, 40, 50]) {
    const teams = Array.from({ length: count }, (_, i) => `Club ${i + 1}`);
    const { groups, fixtures } = generateTournamentFixtures(teams, "GROUPS", 4);
    assert.equal(groups.length, Math.ceil(count / 4));
    assert.ok(fixtures.length > 0);
    // Verify zero self-matches and zero duplicate unordered pairs per group
    const seen = new Set();
    for (const fx of fixtures) {
      assert.notEqual(fx.teamA, fx.teamB);
      const key = [fx.teamA, fx.teamB].sort().join("::");
      assert.equal(seen.has(key), false, `Duplicate fixture found in ${count}-team tournament: ${key}`);
      seen.add(key);
    }
  }

  // Test 50-team Round Robin math: C(50,2) = 1225 fixtures, 0 duplicates
  const teams50 = Array.from({ length: 50 }, (_, i) => `T${i + 1}`);
  const rr50 = generateTournamentFixtures(teams50, "ROUND_ROBIN");
  assert.equal(rr50.fixtures.length, (50 * 49) / 2);

  // Official All-Out NRR Rule:
  // In a 20-over match: Team A scores 160 in 20 overs (not all out);
  // Team B is ALL OUT for 100 in 10 overs -> NRR must divide 100 by FULL 20 overs (5.00), NOT 10 overs (10.00)!
  const fxList = [
    {
      id: "fix-1",
      stage: "Group Stage",
      teamA: "Team A",
      teamB: "Team B",
      status: "COMPLETED",
      result: { runsA: 160, ballsA: 120, allOutA: false, runsB: 100, ballsB: 60, allOutB: true, abandoned: false }
    },
    {
      id: "fix-2",
      stage: "Group Stage",
      teamA: "Team C",
      teamB: "Team D",
      status: "ABANDONED",
      result: { abandoned: true }
    }
  ];

  const standings = calculateTournamentStandings(["Team A", "Team B", "Team C", "Team D"], fxList, [], 20, 2);
  const rowA = standings.find((r) => r.team === "Team A");
  const rowB = standings.find((r) => r.team === "Team B");
  const rowC = standings.find((r) => r.team === "Team C");

  assert.equal(rowA.points, 2);
  assert.ok(Math.abs(rowA.nrr - (8.0 - 5.0)) < 1e-6, `Expected +3.000 NRR when Team B is all out, got ${rowA.nrr}`);
  assert.ok(Math.abs(rowB.nrr - (5.0 - 8.0)) < 1e-6, `Expected -3.000 NRR when Team B is all out, got ${rowB.nrr}`);
  assert.equal(rowC.points, 1, "Abandoned match gives 1 point");
  assert.equal(rowC.nrr, 0, "Abandoned match does not distort NRR");

  // Knockout Progression QF -> SF -> Final
  const eightTeams = Array.from({ length: 8 }, (_, i) => `K${i + 1}`);
  const st8 = calculateTournamentStandings(eightTeams, [], [], 20, 4);
  const qf = generateNextKnockoutRound([], st8, [], "Quarter-Final");
  assert.equal(qf.fixtures.length, 4);
  qf.fixtures.forEach((f, idx) => {
    f.status = "COMPLETED";
    f.result = { runsA: 150 + idx, ballsA: 120, allOutA: false, runsB: 120, ballsB: 120, allOutB: false };
  });
  const sf = generateNextKnockoutRound(qf.fixtures, st8, [], "Semi-Final");
  assert.equal(sf.fixtures.length, 2);
  sf.fixtures.forEach((f) => {
    f.status = "COMPLETED";
    f.result = { runsA: 170, ballsA: 120, allOutA: false, runsB: 160, ballsB: 120, allOutB: false };
  });
  const finalStage = generateNextKnockoutRound([...qf.fixtures, ...sf.fixtures], st8, [], "Final");
  assert.equal(finalStage.fixtures.length, 1);
  assert.equal(finalStage.fixtures[0].stage, "Final");
});

test("Player stats & 9 leaderboards derive cleanly from events, deduplicate match IDs, and support filters", () => {
  const players = [
    { id: "p1", fullName: "Shakib Al Hasan", teamName: "Dhaka", role: "All-rounder" },
    { id: "p2", fullName: "Taskin Ahmed", teamName: "Sylhet", role: "Bowler" }
  ];
  const m1 = {
    id: "m-stat-1",
    teamA: "Dhaka",
    teamB: "Sylhet",
    format: "T20",
    overs: 20,
    tournamentId: "t1",
    matchDate: "2026-11-10",
    firstBattingTeam: "Dhaka",
    ballEvents: [
      makeBall({ strikerName: "Shakib Al Hasan", nonStrikerName: "Litton Das", bowlerName: "Taskin Ahmed", runsBat: 4 }),
      makeBall({ strikerName: "Shakib Al Hasan", nonStrikerName: "Litton Das", bowlerName: "Taskin Ahmed", runsBat: 6 }),
      makeBall({ strikerName: "Shakib Al Hasan", nonStrikerName: "Litton Das", bowlerName: "Taskin Ahmed", runsBat: 0, wicket: { kind: "BOWLED", dismissedBatterName: "Shakib Al Hasan" } })
    ]
  };
  const m2 = {
    id: "m-stat-2",
    teamA: "Dhaka",
    teamB: "Sylhet",
    format: "ODI",
    overs: 50,
    tournamentId: "t2",
    matchDate: "2026-11-12",
    firstBattingTeam: "Dhaka",
    ballEvents: [
      makeBall({ strikerName: "Shakib Al Hasan", nonStrikerName: "Litton Das", bowlerName: "Taskin Ahmed", runsBat: 6 })
    ]
  };

  // Deliberately pass m1 twice to assert deduplication!
  const all = computePlayerStatisticsAndLeaderboards(players, [m1, m1, m2]);
  assert.equal(all.matchCount, 2, "Duplicate match IDs must be deduplicated");
  const shakib = all.playerStats.find((s) => s.name === "Shakib Al Hasan");
  assert.equal(shakib.runs, 16);
  assert.equal(shakib.fours, 1);
  assert.equal(shakib.sixes, 2);
  assert.equal(shakib.highestScore, 10);

  assert.equal(all.leaderboards.mostRuns[0].name, "Shakib Al Hasan");
  assert.equal(all.leaderboards.mostWickets[0].name, "Taskin Ahmed");
  assert.equal(all.leaderboards.mostSixes[0].sixes, 2);
  assert.equal(Object.keys(all.leaderboards).length, 9);

  // Format filter
  const onlyT20 = computePlayerStatisticsAndLeaderboards(players, [m1, m2], { format: "T20" });
  assert.equal(onlyT20.matchCount, 1);
  assert.equal(onlyT20.playerStats.find((s) => s.name === "Shakib Al Hasan").runs, 10);
});

test("PWA Manifest, Service Worker assets, and JSON Backup structure audit", () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(WEB_PWA_DIR, "manifest.webmanifest"), "utf8"));
  assert.equal(manifest.name, "Cricket Arena");
  assert.equal(manifest.display, "standalone");
  assert.ok(manifest.icons.length >= 3);
  for (const icon of manifest.icons) {
    const cleanRel = icon.src.replace(/^\.\//, "");
    assert.ok(fs.existsSync(path.join(WEB_PWA_DIR, cleanRel)), `Missing manifest icon: ${cleanRel}`);
  }

  const swText = fs.readFileSync(path.join(WEB_PWA_DIR, "sw.js"), "utf8");
  for (const requiredFile of ["./index.html", "./styles.css", "./app.js", "./db.js", "./engine.js", "./offline.html"]) {
    assert.ok(swText.includes(requiredFile), `Service worker missing pre-cache asset: ${requiredFile}`);
    const clean = requiredFile.replace(/^\.\//, "");
    assert.ok(fs.existsSync(path.join(WEB_PWA_DIR, clean)), `Missing SW file on disk: ${clean}`);
  }
});

test("Versioned JSON Backup build & validation rejects malformed or incomplete backups", () => {
  const validJson = buildFullBackupJson({
    teams: [{ id: "t1", name: "Dhaka" }, { id: "t2", name: "Sylhet" }],
    players: [{ id: "p1", fullName: "Litton Das" }],
    matches: [{ id: "m1", teamA: "Dhaka", teamB: "Sylhet" }],
    tournaments: [{ id: "tr1", name: "Cup 2026" }]
  });
  const parsed = validateFullBackupJson(validJson);
  assert.equal(parsed.schema, "cricket_arena_full_backup_v2");
  assert.equal(parsed.counts.teams, 2);

  assert.throws(() => validateFullBackupJson(""), /empty/i);
  assert.throws(() => validateFullBackupJson("{bad json"), /not valid JSON/i);
  assert.throws(() => validateFullBackupJson(JSON.stringify({ schema: "wrong", teams: [], players: [], matches: [], tournaments: [] })), /schema/i);
  assert.throws(() => validateFullBackupJson(JSON.stringify({ schema: "cricket_arena_full_backup_v2", teams: [] })), /Incomplete backup/i);
  assert.throws(() => validateFullBackupJson(JSON.stringify({ schema: "cricket_arena_full_backup_v2", teams: [{}], players: [], matches: [], tournaments: [] })), /invalid team/i);
});

test("Social sharing text generator formats live chase, completed result, upcoming, and Test match summaries", () => {
  const upcomingText = generateMatchShareSummary({
    id: "m-up",
    teamA: "Dhaka",
    teamB: "Sylhet",
    format: "T20",
    overs: 20,
    venue: "Mirpur",
    matchDate: "2026-11-20",
    tossWinner: "Dhaka",
    tossDecision: "Bat",
    status: "UPCOMING",
    ballEvents: []
  });
  assert.match(upcomingText, /Dhaka vs Sylhet/);
  assert.match(upcomingText, /Mirpur • 2026-11-20/);
  assert.match(upcomingText, /Match yet to begin/);
  assert.match(upcomingText, /Scored on Cricket Arena/);

  // Live 2nd innings chase
  const liveMatch = {
    id: "m-live-share",
    teamA: "Dhaka",
    teamB: "Sylhet",
    format: "CUSTOM",
    overs: 2,
    firstBattingTeam: "Dhaka",
    currentInnings: 1,
    status: "LIVE",
    ballEvents: [
      ...Array.from({ length: 12 }, () => makeBall({ inningsIndex: 0, runsBat: 2, strikerName: "Litton", nonStrikerName: "Tamim", bowlerName: "Taskin" })), // 24 runs
      makeBall({ inningsIndex: 1, runsBat: 6, strikerName: "Shanto", nonStrikerName: "Zakir", bowlerName: "Mustafiz" })
    ]
  };
  const liveText = generateMatchShareSummary(liveMatch);
  assert.match(liveText, /Dhaka: 24\/0 \(2\.0 ov\)/);
  assert.match(liveText, /Sylhet: 6\/0 \(0\.1 ov\)/);
  assert.match(liveText, /Sylhet need 19 run\(s\) from target 25/);
  assert.match(liveText, /Top Performers:/);
});
