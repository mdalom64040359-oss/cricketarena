export const CRICKET_FORMATS = {
  T10: { key: "T10", label: "T10", defaultOvers: 10, maxInnings: 2, freeHitOnNoBall: true, followOnLead: null, maxDays: 1 },
  T20: { key: "T20", label: "T20", defaultOvers: 20, maxInnings: 2, freeHitOnNoBall: true, followOnLead: null, maxDays: 1 },
  ODI: { key: "ODI", label: "ODI", defaultOvers: 50, maxInnings: 2, freeHitOnNoBall: true, followOnLead: null, maxDays: 1 },
  TEST: { key: "TEST", label: "Test", defaultOvers: null, maxInnings: 4, freeHitOnNoBall: false, followOnLead: 200, maxDays: 5 },
  CUSTOM: { key: "CUSTOM", label: "Custom Overs", defaultOvers: 15, maxInnings: 2, freeHitOnNoBall: true, followOnLead: null, maxDays: 1 }
};

export function getFormatConfig(formatKey, customOvers = 15) {
  const base = CRICKET_FORMATS[formatKey] || CRICKET_FORMATS.T20;
  if (base.key === "TEST") {
    return { ...base, maxOvers: null };
  }
  const overs = base.key === "CUSTOM"
    ? Math.max(1, Math.min(450, Number(customOvers) || 15))
    : base.defaultOvers;
  return { ...base, maxOvers: overs };
}

export function ballsToOversText(legalBalls) {
  const b = Math.max(0, Math.floor(Number(legalBalls) || 0));
  return `${Math.floor(b / 6)}.${b % 6}`;
}

export function formatRunRate(runs, legalBalls) {
  if (!legalBalls || legalBalls <= 0) return "0.00";
  return ((runs / legalBalls) * 6).toFixed(2);
}

export function isLegalDelivery(extraType) {
  return extraType !== "WIDE" && extraType !== "NO_BALL" && extraType !== "PENALTY";
}

export function isWicketAllowedOnFreeHit(kind) {
  return kind === "RUN_OUT" || kind === "OBSTRUCTING" || kind === "HIT_BALL_TWICE";
}

function createEmptyInningsState(battingTeam, bowlingTeam, maxWickets = 10) {
  return {
    battingTeam,
    bowlingTeam,
    maxWickets,
    runs: 0,
    wickets: 0,
    legalBalls: 0,
    totalDeliveries: 0,
    oversText: "0.0",
    extras: { wide: 0, noBall: 0, bye: 0, legBye: 0, penalty: 0, total: 0 },
    batters: {}, // key -> { id, name, runs, balls, fours, sixes, out, dismissalText, order }
    bowlers: {}, // key -> { id, name, balls, maidens, runsConceded, wickets, wides, noBalls, oversText, economy }
    fallOfWickets: [],
    partnerships: [],
    currentPartnership: { runs: 0, balls: 0 },
    strikerName: "",
    nonStrikerName: "",
    currentBowlerName: "",
    nextBallFreeHit: false,
    overJustCompleted: false,
    lastOverBowlerName: "",
    declared: false,
    completed: false,
    allOut: false,
    commentary: []
  };
}

export function recalculateMatch(match) {
  const config = getFormatConfig(match.format, match.overs);
  const events = Array.isArray(match.ballEvents) ? match.ballEvents : [];
  const teamAXI = Array.isArray(match.teamAXI) ? match.teamAXI : [];
  const teamBXI = Array.isArray(match.teamBXI) ? match.teamBXI : [];

  const firstBatTeam = match.firstBattingTeam || match.teamA;
  const firstBowlTeam = firstBatTeam === match.teamA ? match.teamB : match.teamA;

  // Determine batting order across innings (supports Test follow-on!)
  const followOn = config.key === "TEST" && Boolean(match.followOnEnforced);
  const inningsTeams = config.key === "TEST"
    ? followOn
      ? [
          [firstBatTeam, firstBowlTeam],
          [firstBowlTeam, firstBatTeam],
          [firstBowlTeam, firstBatTeam],
          [firstBatTeam, firstBowlTeam]
        ]
      : [
          [firstBatTeam, firstBowlTeam],
          [firstBowlTeam, firstBatTeam],
          [firstBatTeam, firstBowlTeam],
          [firstBowlTeam, firstBatTeam]
        ]
    : [
        [firstBatTeam, firstBowlTeam],
        [firstBowlTeam, firstBatTeam]
      ];

  const getMaxWicketsForTeam = (teamName) => {
    const xi = teamName === match.teamA ? teamAXI : teamBXI;
    if (xi.length >= 2) return Math.min(10, xi.length - 1);
    return 10;
  };

  const innings = inningsTeams.map(([batT, bowlT]) =>
    createEmptyInningsState(batT, bowlT, getMaxWicketsForTeam(batT))
  );

  const declaredMap = match.declaredInnings || {};
  const batterOrderCounters = [0, 0, 0, 0];

  // Track runs conceded per 6-ball over for maidens
  const currentOverRuns = [0, 0, 0, 0];

  for (let idx = 0; idx < events.length; idx += 1) {
    const ev = events[idx];
    const innIdx = Math.max(0, Math.min(innings.length - 1, Number(ev.inningsIndex) || 0));
    const inn = innings[innIdx];

    const striker = (ev.strikerName || "Batter 1").trim();
    const nonStriker = (ev.nonStrikerName || "Batter 2").trim();
    const bowler = (ev.bowlerName || "Bowler 1").trim();

    if (!inn.batters[striker]) {
      batterOrderCounters[innIdx] += 1;
      inn.batters[striker] = {
        id: ev.strikerId || striker,
        name: striker,
        runs: 0,
        balls: 0,
        fours: 0,
        sixes: 0,
        out: false,
        dismissalText: "not out",
        order: batterOrderCounters[innIdx]
      };
    }
    if (!inn.batters[nonStriker]) {
      batterOrderCounters[innIdx] += 1;
      inn.batters[nonStriker] = {
        id: ev.nonStrikerId || nonStriker,
        name: nonStriker,
        runs: 0,
        balls: 0,
        fours: 0,
        sixes: 0,
        out: false,
        dismissalText: "not out",
        order: batterOrderCounters[innIdx]
      };
    }
    if (!inn.bowlers[bowler]) {
      inn.bowlers[bowler] = {
        id: ev.bowlerId || bowler,
        name: bowler,
        balls: 0,
        maidens: 0,
        runsConceded: 0,
        wickets: 0,
        wides: 0,
        noBalls: 0,
        oversText: "0.0",
        economy: "0.00"
      };
    }

    const extraType = ev.extraType || "NONE";
    const runsBat = Math.max(0, Math.min(7, Number(ev.runsBat) || 0));
    const extraRuns = Math.max(0, Math.min(10, Number(ev.extraRuns) || 0));
    const legal = isLegalDelivery(extraType);
    const wasFreeHit = inn.nextBallFreeHit && config.freeHitOnNoBall;

    let ballRuns = runsBat;
    let bowlerChargedRuns = 0;

    if (extraType === "WIDE") {
      const totalWide = 1 + extraRuns;
      ballRuns = totalWide;
      bowlerChargedRuns = totalWide;
      inn.extras.wide += totalWide;
      inn.extras.total += totalWide;
      inn.bowlers[bowler].wides += 1;
      inn.bowlers[bowler].runsConceded += totalWide;
      inn.totalDeliveries += 1;
      inn.nextBallFreeHit = false;
    } else if (extraType === "NO_BALL") {
      const totalNb = 1 + extraRuns + runsBat;
      ballRuns = totalNb;
      bowlerChargedRuns = 1 + runsBat;
      inn.extras.noBall += 1;
      inn.extras.bye += extraRuns;
      inn.extras.total += 1 + extraRuns;
      inn.batters[striker].runs += runsBat;
      inn.batters[striker].balls += 1;
      if (runsBat === 4) inn.batters[striker].fours += 1;
      if (runsBat === 6) inn.batters[striker].sixes += 1;
      inn.bowlers[bowler].noBalls += 1;
      inn.bowlers[bowler].runsConceded += bowlerChargedRuns;
      inn.totalDeliveries += 1;
      inn.nextBallFreeHit = config.freeHitOnNoBall;
    } else if (extraType === "BYE") {
      const totalBye = extraRuns || runsBat;
      ballRuns = totalBye;
      inn.extras.bye += totalBye;
      inn.extras.total += totalBye;
      inn.batters[striker].balls += 1;
      inn.legalBalls += 1;
      inn.totalDeliveries += 1;
      inn.bowlers[bowler].balls += 1;
      inn.nextBallFreeHit = false;
    } else if (extraType === "LEG_BYE") {
      const totalLb = extraRuns || runsBat;
      ballRuns = totalLb;
      inn.extras.legBye += totalLb;
      inn.extras.total += totalLb;
      inn.batters[striker].balls += 1;
      inn.legalBalls += 1;
      inn.totalDeliveries += 1;
      inn.bowlers[bowler].balls += 1;
      inn.nextBallFreeHit = false;
    } else if (extraType === "PENALTY") {
      const pen = extraRuns || 5;
      ballRuns = pen;
      inn.extras.penalty += pen;
      inn.extras.total += pen;
      inn.nextBallFreeHit = false;
    } else {
      // Standard legal ball
      ballRuns = runsBat;
      bowlerChargedRuns = runsBat;
      inn.batters[striker].runs += runsBat;
      inn.batters[striker].balls += 1;
      if (runsBat === 4) inn.batters[striker].fours += 1;
      if (runsBat === 6) inn.batters[striker].sixes += 1;
      inn.legalBalls += 1;
      inn.totalDeliveries += 1;
      inn.bowlers[bowler].balls += 1;
      inn.bowlers[bowler].runsConceded += runsBat;
      inn.nextBallFreeHit = false;
    }

    inn.runs += ballRuns;
    currentOverRuns[innIdx] += bowlerChargedRuns;
    inn.currentPartnership.runs += ballRuns;
    if (legal) inn.currentPartnership.balls += 1;

    // Wicket handling with Free Hit rule enforcement
    let wicketRecorded = false;
    if (ev.wicket && ev.wicket.kind) {
      const kind = ev.wicket.kind;
      if (!wasFreeHit || isWicketAllowedOnFreeHit(kind)) {
        wicketRecorded = true;
        inn.wickets += 1;
        const outBatterName = (ev.wicket.dismissedBatterName || striker).trim();
        if (inn.batters[outBatterName]) {
          inn.batters[outBatterName].out = true;
          inn.batters[outBatterName].dismissalText = ev.wicket.fielderName
            ? `${kind.toLowerCase().replace("_", " ")} (${ev.wicket.fielderName}) b ${bowler}`
            : `${kind.toLowerCase().replace("_", " ")} b ${bowler}`;
        }
        if (kind !== "RUN_OUT" && kind !== "RETIRED") {
          inn.bowlers[bowler].wickets += 1;
        }
        inn.fallOfWickets.push({
          wicketNumber: inn.wickets,
          scoreAtFall: `${inn.runs}/${inn.wickets}`,
          overText: ballsToOversText(inn.legalBalls),
          batterName: outBatterName,
          kind
        });
        inn.partnerships.push({ ...inn.currentPartnership, wicket: inn.wickets });
        inn.currentPartnership = { runs: 0, balls: 0 };
      }
    }

    // Strike rotation logic (after ball runs, before over-end swap)
    let nextStriker = striker;
    let nextNonStriker = nonStriker;
    const runsForStrikeRotation =
      extraType === "NONE" ? runsBat :
      extraType === "NO_BALL" ? runsBat + extraRuns :
      extraType === "PENALTY" ? 0 :
      extraRuns || runsBat;

    if (runsForStrikeRotation % 2 === 1) {
      [nextStriker, nextNonStriker] = [nextNonStriker, nextStriker];
    }

    // Check over completion (exactly 6 legal balls)
    inn.overJustCompleted = false;
    if (legal && inn.legalBalls > 0 && inn.legalBalls % 6 === 0) {
      if (currentOverRuns[innIdx] === 0) {
        inn.bowlers[bowler].maidens += 1;
      }
      currentOverRuns[innIdx] = 0;
      [nextStriker, nextNonStriker] = [nextNonStriker, nextStriker];
      inn.overJustCompleted = true;
      inn.lastOverBowlerName = bowler;
    }

    // If a batter got out and a replacement was provided on the event or UI
    if (wicketRecorded && ev.wicket.dismissedBatterName) {
      const outName = ev.wicket.dismissedBatterName.trim();
      if (outName === nextStriker) nextStriker = "";
      if (outName === nextNonStriker) nextNonStriker = "";
    }

    inn.strikerName = nextStriker;
    inn.nonStrikerName = nextNonStriker;
    inn.currentBowlerName = inn.overJustCompleted ? "" : bowler;
    inn.oversText = ballsToOversText(inn.legalBalls);

    // Update bowler computed displays
    const bw = inn.bowlers[bowler];
    bw.oversText = ballsToOversText(bw.balls);
    bw.economy = bw.balls > 0 ? ((bw.runsConceded / bw.balls) * 6).toFixed(2) : "0.00";

    const overStamp = ballsToOversText(inn.legalBalls);
    const commText = ev.commentary ||
      `${overStamp} — ${bowler} to ${striker}: ${wicketRecorded ? "WICKET! " : ""}${ballRuns} run(s)${extraType !== "NONE" ? ` (${extraType})` : ""}${wasFreeHit ? " [FREE HIT]" : ""}`;
    inn.commentary.unshift({ id: ev.id || `${idx}`, overText: overStamp, text: commText });
  }

  // Finalize innings completion flags
  for (let i = 0; i < innings.length; i += 1) {
    const inn = innings[i];
    inn.declared = Boolean(declaredMap[i]);
    inn.allOut = inn.wickets >= inn.maxWickets;
    const hitOversCap = config.maxOvers !== null && inn.legalBalls >= config.maxOvers * 6;
    inn.completed = inn.allOut || hitOversCap || inn.declared;
  }

  // Format-specific Match Summary, Target, Lead/Deficit, Result
  let target = null;
  let runsRemaining = null;
  let requiredRunRate = null;
  let leadDeficitText = "";
  let canEnforceFollowOn = false;
  let resultSummary = "";
  let winnerTeam = null;
  let isDraw = false;
  let isTie = false;

  if (match.status === "ABANDONED") {
    resultSummary = "Match Abandoned / No Result";
  } else if (config.key !== "TEST") {
    const first = innings[0];
    const second = innings[1];
    if (first.completed || (match.currentInnings || 0) >= 1) {
      target = first.runs + 1;
      if (second.runs >= target) {
        second.completed = true;
        winnerTeam = second.battingTeam;
        const wicketsLeft = second.maxWickets - second.wickets;
        resultSummary = `${second.battingTeam} won by ${wicketsLeft} wicket(s)`;
      } else if (second.completed) {
        if (second.runs === first.runs) {
          isTie = true;
          resultSummary = "Match Tied";
        } else {
          winnerTeam = first.battingTeam;
          resultSummary = `${first.battingTeam} won by ${first.runs - second.runs} run(s)`;
        }
      } else {
        runsRemaining = Math.max(0, target - second.runs);
        const ballsLeft = Math.max(0, (config.maxOvers || 20) * 6 - second.legalBalls);
        requiredRunRate = ballsLeft > 0 ? ((runsRemaining / ballsLeft) * 6).toFixed(2) : null;
      }
    }
  } else {
    // Test Cricket rules (4 innings, lead/deficit, follow-on >= 200, innings win, 5-day draw)
    const totals = { [match.teamA]: 0, [match.teamB]: 0 };
    innings.forEach((inn) => {
      totals[inn.battingTeam] = (totals[inn.battingTeam] || 0) + inn.runs;
    });

    const curIdx = Math.max(0, Math.min(3, Number(match.currentInnings) || 0));
    const curInn = innings[curIdx];
    const oppTeam = curInn.bowlingTeam;
    const diff = totals[curInn.battingTeam] - totals[oppTeam];

    if (innings[0].completed && innings[1].completed && innings[2].totalDeliveries === 0 && !followOn) {
      if (innings[0].runs - innings[1].runs >= (config.followOnLead || 200)) {
        canEnforceFollowOn = true;
      }
    }

    // Check Innings & Runs victory (either follow-on OR batting team outscored opponent's 2 completed innings in 1)
    if (innings[0].completed && innings[1].completed && innings[2].completed) {
      const team0 = innings[0].battingTeam;
      const team1 = innings[0].bowlingTeam;
      const t0InningsDone = [innings[0], innings[1], innings[2]].filter((inn) => inn.battingTeam === team0).length;
      const t1InningsDone = [innings[0], innings[1], innings[2]].filter((inn) => inn.battingTeam === team1).length;

      if (t0InningsDone === 1 && t1InningsDone === 2 && totals[team0] > totals[team1]) {
        winnerTeam = team0;
        resultSummary = `${team0} won by an innings and ${totals[team0] - totals[team1]} run(s)`;
      } else if (t1InningsDone === 1 && t0InningsDone === 2 && totals[team1] > totals[team0]) {
        winnerTeam = team1;
        resultSummary = `${team1} won by an innings and ${totals[team1] - totals[team0]} run(s)`;
      }
    }

    if (!resultSummary && curIdx === 3) {
      const fourthTeam = innings[3].battingTeam;
      const otherTeam = innings[3].bowlingTeam;
      const needed = totals[otherTeam] + 1 - (totals[fourthTeam] - innings[3].runs);
      target = Math.max(1, needed);
      if (totals[fourthTeam] > totals[otherTeam]) {
        innings[3].completed = true;
        winnerTeam = fourthTeam;
        resultSummary = `${fourthTeam} won by ${innings[3].maxWickets - innings[3].wickets} wicket(s)`;
      } else if (innings[3].completed) {
        if (totals[fourthTeam] === totals[otherTeam]) {
          isTie = true;
          resultSummary = "Test Match Tied";
        } else {
          winnerTeam = otherTeam;
          resultSummary = `${otherTeam} won by ${totals[otherTeam] - totals[fourthTeam]} run(s)`;
        }
      } else {
        runsRemaining = Math.max(0, totals[otherTeam] + 1 - totals[fourthTeam]);
      }
    }

    if (!resultSummary && match.status === "COMPLETED") {
      isDraw = true;
      resultSummary = `Match Drawn (Day ${match.currentDay || 5} of 5)`;
    }

    if (!resultSummary) {
      if (diff > 0) leadDeficitText = `${curInn.battingTeam} lead by ${diff} run(s)`;
      else if (diff < 0) leadDeficitText = `${curInn.battingTeam} trail by ${Math.abs(diff)} run(s)`;
      else leadDeficitText = "Scores level";
    }
  }

  return {
    config,
    innings,
    target,
    runsRemaining,
    requiredRunRate,
    leadDeficitText,
    canEnforceFollowOn,
    resultSummary,
    winnerTeam,
    isTie,
    isDraw
  };
}

export function getFixtureWinner(fx, linkedMatches = []) {
  if (!fx || fx.status !== "COMPLETED") return null;
  if (fx.result?.linkedMatchId) {
    const m = linkedMatches.find((item) => item.id === fx.result.linkedMatchId);
    if (m) {
      const calc = recalculateMatch(m);
      if (calc.winnerTeam) return calc.winnerTeam;
    }
  }
  const rA = Number(fx.result?.runsA);
  const rB = Number(fx.result?.runsB);
  if (!Number.isFinite(rA) || !Number.isFinite(rB) || rA === rB) return null;
  return rA > rB ? fx.teamA : fx.teamB;
}

export function generateNextKnockoutRound(existingFixtures = [], standings = [], linkedMatches = [], targetStage = "AUTO") {
  const existing = existingFixtures || [];
  const nextId = (idx) => `fix-${existing.length + idx + 1}`;
  const stagesPresent = new Set(existing.map((f) => f.stage));

  let chosenStage = targetStage;
  if (chosenStage === "AUTO") {
    if (!stagesPresent.has("Quarter-Final") && standings.length >= 8) chosenStage = "Quarter-Final";
    else if (!stagesPresent.has("Semi-Final")) chosenStage = "Semi-Final";
    else if (!stagesPresent.has("Final")) chosenStage = "Final";
    else return { stage: null, fixtures: [] };
  }

  if (chosenStage === "Quarter-Final") {
    const top8 = standings.slice(0, 8).map((s) => s.team);
    if (top8.length < 2) return { stage: null, fixtures: [] };
    const pairings = [];
    for (let i = 0; i < Math.floor(top8.length / 2); i += 1) {
      pairings.push([top8[i], top8[top8.length - 1 - i]]);
    }
    return {
      stage: "Quarter-Final",
      fixtures: pairings.map(([teamA, teamB], idx) => ({
        id: nextId(idx),
        stage: "Quarter-Final",
        round: 1,
        group: null,
        teamA,
        teamB,
        status: "UPCOMING",
        result: null
      }))
    };
  }

  if (chosenStage === "Semi-Final") {
    const qfs = existing.filter((f) => f.stage === "Quarter-Final");
    const qfWinners = qfs.map((f) => getFixtureWinner(f, linkedMatches)).filter(Boolean);
    const pool = qfWinners.length >= 4 ? qfWinners.slice(0, 4) : standings.slice(0, 4).map((s) => s.team);
    if (pool.length < 4) return { stage: null, fixtures: [] };
    return {
      stage: "Semi-Final",
      fixtures: [
        { id: nextId(0), stage: "Semi-Final", round: 1, group: null, teamA: pool[0], teamB: pool[3], status: "UPCOMING", result: null },
        { id: nextId(1), stage: "Semi-Final", round: 1, group: null, teamA: pool[1], teamB: pool[2], status: "UPCOMING", result: null }
      ]
    };
  }

  if (chosenStage === "Final") {
    const sfs = existing.filter((f) => f.stage === "Semi-Final");
    const sfWinners = sfs.map((f) => getFixtureWinner(f, linkedMatches)).filter(Boolean);
    const pool = sfWinners.length >= 2 ? sfWinners.slice(0, 2) : standings.slice(0, 2).map((s) => s.team);
    if (pool.length < 2) return { stage: null, fixtures: [] };
    return {
      stage: "Final",
      fixtures: [
        { id: nextId(0), stage: "Final", round: 1, group: null, teamA: pool[0], teamB: pool[1], status: "UPCOMING", result: null }
      ]
    };
  }

  return { stage: null, fixtures: [] };
}

/**
 * Generates duplicate-free fixtures for 20, 24, 32, 40, 50+ teams.
 * Formats: ROUND_ROBIN, GROUPS, LEAGUE, KNOCKOUT, HYBRID.
 */
export function generateTournamentFixtures(teams, format = "GROUPS", groupSize = 4) {
  const cleanTeams = [...new Set(teams.map((t) => String(t).trim()).filter(Boolean))];
  if (cleanTeams.length < 2) return { groups: [], fixtures: [] };

  const fixtures = [];
  let fixtureSeq = 1;
  const seenPairs = new Set();

  const addFixture = (stage, round, teamA, teamB, group = null) => {
    if (!teamA || !teamB || teamA === teamB) return;
    const pairKey = `${stage}::${group || ""}::${[teamA, teamB].sort().join("::")}`;
    if (seenPairs.has(pairKey)) return;
    seenPairs.add(pairKey);
    fixtures.push({
      id: `fix-${fixtureSeq++}`,
      stage,
      round,
      group,
      teamA,
      teamB,
      status: "UPCOMING",
      result: null
    });
  };

  if (format === "KNOCKOUT") {
    const roundLabel = cleanTeams.length <= 2 ? "Final" : cleanTeams.length <= 4 ? "Semi-Final" : cleanTeams.length <= 8 ? "Quarter-Final" : `Round of ${cleanTeams.length}`;
    for (let i = 0; i + 1 < cleanTeams.length; i += 2) {
      addFixture(roundLabel, 1, cleanTeams[i], cleanTeams[i + 1], null);
    }
    return { groups: [], fixtures };
  }

  if (format === "GROUPS" || format === "HYBRID") {
    const safeGroupSize = Math.max(3, Number(groupSize) || 4);
    const numGroups = Math.max(1, Math.ceil(cleanTeams.length / safeGroupSize));
    const groups = Array.from({ length: numGroups }, (_, idx) => ({
      name: `Group ${String.fromCharCode(65 + (idx % 26))}${idx >= 26 ? Math.floor(idx / 26) : ""}`,
      teams: []
    }));

    // Snake seeding distributes teams evenly across groups
    cleanTeams.forEach((team, idx) => {
      groups[idx % numGroups].teams.push(team);
    });

    groups.forEach((grp) => {
      const n = grp.teams.length;
      for (let i = 0; i < n; i += 1) {
        for (let j = i + 1; j < n; j += 1) {
          addFixture("Group Stage", 1, grp.teams[i], grp.teams[j], grp.name);
        }
      }
    });

    return { groups, fixtures };
  }

  // ROUND_ROBIN or LEAGUE (Circle algorithm)
  const list = [...cleanTeams];
  if (list.length % 2 === 1) list.push(null); // bye
  const totalRounds = list.length - 1;
  const half = list.length / 2;

  for (let round = 0; round < totalRounds; round += 1) {
    for (let i = 0; i < half; i += 1) {
      const tA = list[i];
      const tB = list[list.length - 1 - i];
      if (tA && tB) addFixture(format === "LEAGUE" ? "League" : "Round Robin", round + 1, tA, tB, null);
    }
    const last = list.pop();
    list.splice(1, 0, last);
  }

  return { groups: [], fixtures };
}

/**
 * Official Cricket Net Run Rate & Points Table calculator:
 * - All-out innings use full overs quota in NRR denominator!
 * - Abandoned/No Result gives 1 point and does NOT distort NRR.
 * - Ties give 1 point each and include both innings in NRR.
 */
export function calculateTournamentStandings(teams, fixtures, linkedMatches = [], oversQuota = 20, qualifyCount = 4) {
  const table = new Map();
  teams.forEach((team) => {
    table.set(team, {
      team,
      played: 0,
      won: 0,
      lost: 0,
      tied: 0,
      noResult: 0,
      points: 0,
      runsFor: 0,
      ballsForNrr: 0,
      runsAgainst: 0,
      ballsAgainstNrr: 0,
      nrr: 0,
      qualified: false
    });
  });

  const quotaBalls = Math.max(6, (Number(oversQuota) || 20) * 6);

  const applyCompletedResult = ({
    teamA,
    teamB,
    runsA,
    ballsA,
    allOutA,
    runsB,
    ballsB,
    allOutB,
    abandoned = false,
    matchOversQuota = quotaBalls
  }) => {
    const rowA = table.get(teamA);
    const rowB = table.get(teamB);
    if (!rowA || !rowB) return;

    rowA.played += 1;
    rowB.played += 1;

    if (abandoned) {
      rowA.noResult += 1;
      rowB.noResult += 1;
      rowA.points += 1;
      rowB.points += 1;
      return;
    }

    const effBallsA = allOutA ? matchOversQuota : Math.max(1, ballsA);
    const effBallsB = allOutB ? matchOversQuota : Math.max(1, ballsB);

    rowA.runsFor += runsA;
    rowA.ballsForNrr += effBallsA;
    rowA.runsAgainst += runsB;
    rowA.ballsAgainstNrr += effBallsB;

    rowB.runsFor += runsB;
    rowB.ballsForNrr += effBallsB;
    rowB.runsAgainst += runsA;
    rowB.ballsAgainstNrr += effBallsA;

    if (runsA > runsB) {
      rowA.won += 1;
      rowA.points += 2;
      rowB.lost += 1;
    } else if (runsB > runsA) {
      rowB.won += 1;
      rowB.points += 2;
      rowA.lost += 1;
    } else {
      rowA.tied += 1;
      rowB.tied += 1;
      rowA.points += 1;
      rowB.points += 1;
    }
  };

  const processedMatchIds = new Set();

  // First apply real linked Match records (source of truth)
  for (const m of linkedMatches) {
    if (!m || processedMatchIds.has(m.id)) continue;
    if (m.status !== "COMPLETED" && m.status !== "ABANDONED") continue;
    processedMatchIds.add(m.id);

    const calc = recalculateMatch(m);
    const inn0 = calc.innings[0];
    const inn1 = calc.innings[1];
    const mQuota = (calc.config.maxOvers || oversQuota || 20) * 6;
    applyCompletedResult({
      teamA: inn0.battingTeam,
      teamB: inn1.battingTeam,
      runsA: inn0.runs,
      ballsA: inn0.legalBalls,
      allOutA: inn0.allOut,
      runsB: inn1.runs,
      ballsB: inn1.legalBalls,
      allOutB: inn1.allOut,
      abandoned: m.status === "ABANDONED",
      matchOversQuota: mQuota
    });
  }

  // Also apply fixture-recorded results not tied to a separate match object
  for (const fx of fixtures || []) {
    if (!fx.result || fx.result.linkedMatchId && processedMatchIds.has(fx.result.linkedMatchId)) continue;
    if (fx.status !== "COMPLETED" && fx.status !== "ABANDONED") continue;
    applyCompletedResult({
      teamA: fx.teamA,
      teamB: fx.teamB,
      runsA: Number(fx.result.runsA) || 0,
      ballsA: Number(fx.result.ballsA) || quotaBalls,
      allOutA: Boolean(fx.result.allOutA),
      runsB: Number(fx.result.runsB) || 0,
      ballsB: Number(fx.result.ballsB) || quotaBalls,
      allOutB: Boolean(fx.result.allOutB),
      abandoned: fx.status === "ABANDONED" || Boolean(fx.result.abandoned),
      matchOversQuota: quotaBalls
    });
  }

  const rows = Array.from(table.values()).map((row) => {
    const rf = row.ballsForNrr > 0 ? row.runsFor / (row.ballsForNrr / 6) : 0;
    const ra = row.ballsAgainstNrr > 0 ? row.runsAgainst / (row.ballsAgainstNrr / 6) : 0;
    return {
      ...row,
      oversFacedText: ballsToOversText(row.ballsForNrr),
      oversBowledText: ballsToOversText(row.ballsAgainstNrr),
      nrr: rf - ra
    };
  });

  rows.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.won !== a.won) return b.won - a.won;
    if (Math.abs(b.nrr - a.nrr) > 1e-6) return b.nrr - a.nrr;
    return a.team.localeCompare(b.team);
  });

  rows.forEach((r, idx) => {
    r.qualified = idx < qualifyCount && r.played > 0;
  });

  return rows;
}

/**
 * Computes Batting, Bowling, Match-by-Match, and 9 Leaderboards
 * directly from actual saved Match ball events (deduplicated by match.id).
 */
export function computePlayerStatisticsAndLeaderboards(players, matches, filters = {}) {
  const { format = "ALL", tournamentId = "ALL", teamName = "ALL", dateFrom = "", dateTo = "" } = filters;

  const filteredMatches = [];
  const seenMatchIds = new Set();

  for (const m of matches || []) {
    if (!m || !m.id || seenMatchIds.has(m.id)) continue;
    seenMatchIds.add(m.id);
    if (format !== "ALL" && m.format !== format) continue;
    if (tournamentId !== "ALL" && m.tournamentId !== tournamentId) continue;
    if (teamName !== "ALL" && m.teamA !== teamName && m.teamB !== teamName) continue;
    if (dateFrom && m.matchDate && m.matchDate < dateFrom) continue;
    if (dateTo && m.matchDate && m.matchDate > dateTo) continue;
    filteredMatches.push(m);
  }

  const statsMap = new Map();

  const ensurePlayerStat = (name, team = "") => {
    const key = name.trim();
    if (!statsMap.has(key)) {
      const known = (players || []).find((p) => p.fullName.toLowerCase() === key.toLowerCase());
      statsMap.set(key, {
        name: known ? known.fullName : key,
        playerId: known ? known.id : null,
        team: known?.teamName || team || "Unassigned",
        role: known?.role || "Player",
        innings: 0,
        notOuts: 0,
        runs: 0,
        ballsFaced: 0,
        highestScore: 0,
        highestNotOut: false,
        fours: 0,
        sixes: 0,
        hundreds: 0,
        fifties: 0,
        bowlingInnings: 0,
        ballsBowled: 0,
        maidens: 0,
        runsConceded: 0,
        wickets: 0,
        bestWickets: 0,
        bestRuns: 0,
        matchPerformances: []
      });
    }
    return statsMap.get(key);
  };

  for (const m of filteredMatches) {
    const calc = recalculateMatch(m);
    for (let i = 0; i < calc.innings.length; i += 1) {
      const inn = calc.innings[i];
      for (const b of Object.values(inn.batters)) {
        const st = ensurePlayerStat(b.name, inn.battingTeam);
        st.innings += 1;
        if (!b.out) st.notOuts += 1;
        st.runs += b.runs;
        st.ballsFaced += b.balls;
        st.fours += b.fours;
        st.sixes += b.sixes;
        if (b.runs >= 100) st.hundreds += 1;
        else if (b.runs >= 50) st.fifties += 1;
        if (b.runs > st.highestScore || (b.runs === st.highestScore && !b.out && st.highestNotOut === false)) {
          st.highestScore = b.runs;
          st.highestNotOut = !b.out;
        }
        st.matchPerformances.push({
          matchId: m.id,
          matchTitle: `${m.teamA} vs ${m.teamB}`,
          date: m.matchDate || "",
          format: m.format,
          type: "BAT",
          summary: `${b.runs}${b.out ? "" : "*"} (${b.balls}b, ${b.fours}x4, ${b.sixes}x6)`
        });
      }

      for (const bw of Object.values(inn.bowlers)) {
        const st = ensurePlayerStat(bw.name, inn.bowlingTeam);
        st.bowlingInnings += 1;
        st.ballsBowled += bw.balls;
        st.maidens += bw.maidens;
        st.runsConceded += bw.runsConceded;
        st.wickets += bw.wickets;
        if (
          bw.wickets > st.bestWickets ||
          (bw.wickets === st.bestWickets && bw.wickets > 0 && bw.runsConceded < st.bestRuns)
        ) {
          st.bestWickets = bw.wickets;
          st.bestRuns = bw.runsConceded;
        }
        st.matchPerformances.push({
          matchId: m.id,
          matchTitle: `${m.teamA} vs ${m.teamB}`,
          date: m.matchDate || "",
          format: m.format,
          type: "BOWL",
          summary: `${bw.oversText}-${bw.maidens}-${bw.runsConceded}-${bw.wickets}`
        });
      }
    }
  }

  const allPlayerStats = Array.from(statsMap.values()).map((st) => {
    const dismissals = st.innings - st.notOuts;
    const battingAverage = dismissals > 0 ? st.runs / dismissals : null;
    const strikeRate = st.ballsFaced > 0 ? (st.runs / st.ballsFaced) * 100 : null;
    const bowlingAverage = st.wickets > 0 ? st.runsConceded / st.wickets : null;
    const economyRate = st.ballsBowled > 0 ? (st.runsConceded / st.ballsBowled) * 6 : null;
    const bowlingStrikeRate = st.wickets > 0 ? st.ballsBowled / st.wickets : null;
    const bestBowlingText = st.bestWickets > 0 ? `${st.bestWickets}/${st.bestRuns}` : "—";

    return {
      ...st,
      oversBowledText: ballsToOversText(st.ballsBowled),
      battingAverage,
      strikeRate,
      bowlingAverage,
      economyRate,
      bowlingStrikeRate,
      bestBowlingText
    };
  });

  const leaderboards = {
    mostRuns: [...allPlayerStats].filter((p) => p.runs > 0).sort((a, b) => b.runs - a.runs),
    highestScore: [...allPlayerStats].filter((p) => p.innings > 0).sort((a, b) => b.highestScore - a.highestScore),
    bestBattingAverage: [...allPlayerStats].filter((p) => p.battingAverage !== null).sort((a, b) => b.battingAverage - a.battingAverage),
    bestStrikeRate: [...allPlayerStats].filter((p) => p.strikeRate !== null).sort((a, b) => b.strikeRate - a.strikeRate),
    mostWickets: [...allPlayerStats].filter((p) => p.wickets > 0).sort((a, b) => b.wickets - a.wickets),
    bestBowlingFigures: [...allPlayerStats].filter((p) => p.bestWickets > 0).sort((a, b) =>
      b.bestWickets !== a.bestWickets ? b.bestWickets - a.bestWickets : a.bestRuns - b.bestRuns
    ),
    bestEconomy: [...allPlayerStats].filter((p) => p.economyRate !== null && p.ballsBowled >= 6).sort((a, b) => a.economyRate - b.economyRate),
    mostFours: [...allPlayerStats].filter((p) => p.fours > 0).sort((a, b) => b.fours - a.fours),
    mostSixes: [...allPlayerStats].filter((p) => p.sixes > 0).sort((a, b) => b.sixes - a.sixes)
  };

  return {
    playerStats: allPlayerStats,
    leaderboards,
    matchCount: filteredMatches.length
  };
}

/**
 * Generates a concise, share-ready text summary of the match result or current live/upcoming status.
 */
export function generateMatchShareSummary(match, precomputedCalc = null) {
  if (!match) return "";
  const calc = precomputedCalc || recalculateMatch(match);
  const formatLine = calc.config.maxOvers
    ? `${calc.config.label} (${calc.config.maxOvers} Overs)`
    : `${calc.config.label} Cricket • Day ${match.currentDay || 1} of 5`;

  const lines = [
    `🏏 ${match.teamA} vs ${match.teamB}`,
    `Format: ${formatLine} | Status: ${match.status || "LIVE"}`
  ];

  if (match.venue || match.matchDate) {
    lines.push(`Venue & Date: ${[match.venue, match.matchDate].filter(Boolean).join(" • ")}`);
  }
  if (match.tossWinner) {
    lines.push(`Toss: ${match.tossWinner} elected to ${match.tossDecision || "Bat"}`);
  }

  const activeInnings = calc.innings
    .map((inn, idx) => ({ inn, idx }))
    .filter(({ inn, idx }) => inn.totalDeliveries > 0 || (idx === (Number(match.currentInnings) || 0) && match.status === "LIVE"));

  if (activeInnings.length > 0) {
    lines.push("");
    for (const { inn, idx } of activeInnings) {
      const label = calc.config.key === "TEST" ? ` (Inn ${idx + 1})` : "";
      lines.push(`${inn.battingTeam}${label}: ${inn.runs}/${inn.wickets} (${inn.oversText} ov)`);
    }
  }

  lines.push("");
  if (calc.resultSummary) {
    lines.push(`🏆 Result: ${calc.resultSummary}`);
  } else if (match.status === "UPCOMING" && activeInnings.length === 0) {
    lines.push("⏳ Match yet to begin");
  } else if (calc.runsRemaining !== null && calc.target !== null) {
    const chasingTeam = calc.innings[1]?.battingTeam || match.teamB;
    const rrrPart = calc.requiredRunRate ? ` (RRR: ${calc.requiredRunRate})` : "";
    lines.push(`⚡ Status: ${chasingTeam} need ${calc.runsRemaining} run(s) from target ${calc.target}${rrrPart}`);
  } else if (calc.leadDeficitText) {
    lines.push(`⚡ Status: ${calc.leadDeficitText}`);
  } else {
    lines.push(`⚡ Status: Match ${match.status || "LIVE"}`);
  }

  // Include top batter and top bowler highlights when events exist
  const allBatters = calc.innings.flatMap((i) => Object.values(i.batters || {}));
  const allBowlers = calc.innings.flatMap((i) => Object.values(i.bowlers || {}));
  const topBat = allBatters.sort((a, b) => b.runs - a.runs || a.balls - b.balls)[0];
  const topBowl = allBowlers.sort((a, b) => b.wickets - a.wickets || a.runsConceded - b.runsConceded)[0];

  if ((topBat && topBat.runs > 0) || (topBowl && topBowl.wickets > 0)) {
    const highlights = [];
    if (topBat && topBat.runs > 0) {
      highlights.push(`${topBat.name} ${topBat.runs}${topBat.out ? "" : "*"}(${topBat.balls})`);
    }
    if (topBowl && topBowl.wickets > 0) {
      highlights.push(`${topBowl.name} ${topBowl.wickets}/${topBowl.runsConceded}`);
    }
    lines.push(`Top Performers: ${highlights.join(" • ")}`);
  }

  lines.push("— Scored on Cricket Arena");
  return lines.join("\n");
}

