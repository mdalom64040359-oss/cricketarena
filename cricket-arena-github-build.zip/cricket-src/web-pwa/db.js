const DB_NAME = "cricket_arena_web_v1";
const DB_VERSION = 2;
const STORES = [
  "teams",
  "players",
  "matches",
  "tournaments",
  "user_accounts",
  "user_settings",
  "user_favourites",
  "meta"
];

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const name of STORES) {
        if (!db.objectStoreNames.contains(name)) {
          const keyPath = name === "user_accounts" || name === "user_settings" ? "userId" : "id";
          db.createObjectStore(name, { keyPath });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function withStore(storeName, mode, fn) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    const result = fn(store);
    tx.oncomplete = () => resolve(result?._value !== undefined ? result._value : result);
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAll(storeName) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function getById(storeName, id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const req = tx.objectStore(storeName).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

export async function putRecord(storeName, record) {
  return withStore(storeName, "readwrite", (store) => {
    store.put(record);
  });
}

export async function deleteRecord(storeName, id) {
  return withStore(storeName, "readwrite", (store) => {
    store.delete(id);
  });
}

export async function clearStore(storeName) {
  return withStore(storeName, "readwrite", (store) => {
    store.clear();
  });
}

export async function getMeta(key) {
  const rec = await getById("meta", key);
  return rec ? rec.value : null;
}

export async function setMeta(key, value) {
  if (value === null || value === undefined) {
    return deleteRecord("meta", key);
  }
  return putRecord("meta", { id: key, value });
}

// Web Crypto PBKDF2-SHA256 salted hashing (zero plaintext passwords)
function toBase64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 1) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin);
}

function fromBase64(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) {
    bytes[i] = bin.charCodeAt(i);
  }
  return bytes;
}

export async function hashSecret(secret, existingSaltB64 = null) {
  const salt = existingSaltB64
    ? fromBase64(existingSaltB64)
    : crypto.getRandomValues(new Uint8Array(16));
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    "PBKDF2",
    false,
    ["deriveBits"]
  );
  const derivedBits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 120000, hash: "SHA-256" },
    keyMaterial,
    256
  );
  return {
    hashBase64: toBase64(new Uint8Array(derivedBits)),
    saltBase64: toBase64(salt)
  };
}

export async function verifySecret(secret, expectedHash, saltB64) {
  if (!secret || !expectedHash || !saltB64) return false;
  const computed = await hashSecret(secret, saltB64);
  if (computed.hashBase64.length !== expectedHash.length) return false;
  let diff = 0;
  for (let i = 0; i < expectedHash.length; i += 1) {
    diff |= computed.hashBase64.charCodeAt(i) ^ expectedHash.charCodeAt(i);
  }
  return diff === 0;
}

export const FULL_BACKUP_SCHEMAS = [
  "cricket_arena_full_backup_v2",
  "cricket_arena_full_backup_v1"
];

export function buildFullBackupJson({ teams = [], players = [], matches = [], tournaments = [] }) {
  return JSON.stringify(
    {
      schema: "cricket_arena_full_backup_v2",
      appVersion: "0.4.0",
      exportedAt: new Date().toISOString(),
      counts: {
        teams: teams.length,
        players: players.length,
        matches: matches.length,
        tournaments: tournaments.length
      },
      teams,
      players,
      matches,
      tournaments
    },
    null,
    2
  );
}

export function validateFullBackupJson(rawJson) {
  if (typeof rawJson !== "string" || !rawJson.trim()) {
    throw new Error("Backup content is empty.");
  }
  let parsed;
  try {
    parsed = JSON.parse(rawJson);
  } catch {
    throw new Error("Backup file is not valid JSON.");
  }
  if (!parsed || typeof parsed !== "object" || !FULL_BACKUP_SCHEMAS.includes(parsed.schema)) {
    throw new Error("Unsupported or invalid Cricket Arena backup schema.");
  }
  if (!Array.isArray(parsed.teams) || !Array.isArray(parsed.players) || !Array.isArray(parsed.matches) || !Array.isArray(parsed.tournaments)) {
    throw new Error("Incomplete backup file: missing teams, players, matches, or tournaments arrays.");
  }
  for (const t of parsed.teams) {
    if (!t || !t.id || !t.name) throw new Error("Backup contains an invalid team record.");
  }
  for (const p of parsed.players) {
    if (!p || !p.id || !p.fullName) throw new Error("Backup contains an invalid player record.");
  }
  for (const m of parsed.matches) {
    if (!m || !m.id || !m.teamA || !m.teamB) throw new Error("Backup contains an invalid match record.");
  }
  for (const tr of parsed.tournaments) {
    if (!tr || !tr.id || !tr.name) throw new Error("Backup contains an invalid tournament record.");
  }
  return parsed;
}

export async function exportFullArenaBackup() {
  const [teams, players, matches, tournaments] = await Promise.all([
    getAll("teams"),
    getAll("players"),
    getAll("matches"),
    getAll("tournaments")
  ]);
  return buildFullBackupJson({ teams, players, matches, tournaments });
}

export async function restoreFullArenaBackup(rawJson, replaceExisting = false) {
  const data = validateFullBackupJson(rawJson);
  if (replaceExisting) {
    await Promise.all([
      clearStore("teams"),
      clearStore("players"),
      clearStore("matches"),
      clearStore("tournaments")
    ]);
  }
  for (const t of data.teams) await putRecord("teams", t);
  for (const p of data.players) await putRecord("players", p);
  for (const m of data.matches) await putRecord("matches", m);
  for (const tour of data.tournaments) await putRecord("tournaments", tour);
  return {
    teams: data.teams.length,
    players: data.players.length,
    matches: data.matches.length,
    tournaments: data.tournaments.length
  };
}

export async function exportPersonalBackup(userId) {
  const account = await getById("user_accounts", userId);
  if (!account) throw new Error("Account not found.");
  const settings = (await getById("user_settings", userId)) || { userId };
  const allFavs = await getAll("user_favourites");
  const favourites = allFavs.filter((f) => f.userId === userId);
  return JSON.stringify(
    {
      schema: "cricket_arena_personal_backup_v1",
      exportedAt: new Date().toISOString(),
      userId,
      profile: {
        fullName: account.fullName,
        emailOrHandle: account.emailOrHandle,
        bio: account.bio || "",
        cityOrPhone: account.cityOrPhone || ""
      },
      settings,
      favourites
    },
    null,
    2
  );
}

export async function restorePersonalBackup(userId, rawJson) {
  const data = JSON.parse(rawJson);
  if (!data || data.schema !== "cricket_arena_personal_backup_v1") {
    throw new Error("Invalid personal backup format.");
  }
  const account = await getById("user_accounts", userId);
  if (!account) throw new Error("Account not found.");
  await putRecord("user_accounts", {
    ...account,
    fullName: data.profile?.fullName || account.fullName,
    bio: data.profile?.bio ?? account.bio,
    cityOrPhone: data.profile?.cityOrPhone ?? account.cityOrPhone,
    updatedAt: Date.now()
  });
  await putRecord("user_settings", {
    ...(data.settings || {}),
    userId,
    updatedAt: Date.now()
  });
  const existingFavs = await getAll("user_favourites");
  for (const f of existingFavs) {
    if (f.userId === userId) await deleteRecord("user_favourites", f.id);
  }
  for (const f of data.favourites || []) {
    await putRecord("user_favourites", {
      ...f,
      id: `${userId}::${f.itemType}::${f.itemKey}`,
      userId
    });
  }
}
