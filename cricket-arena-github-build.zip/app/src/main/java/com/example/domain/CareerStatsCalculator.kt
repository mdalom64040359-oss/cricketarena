package com.example.domain

import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.CareerScopeType
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

const val NOT_AVAILABLE = "Not Available"

data class ComputedBattingStats(
    val matchesText: String,
    val inningsText: String,
    val runsText: String,
    val ballsFacedText: String,
    val highestScoreText: String,
    val averageText: String,
    val strikeRateText: String,
    val foursText: String,
    val sixesText: String,
    val hundredsText: String,
    val fiftiesText: String,
    val doubleHundredsText: String,
    val notOutsText: String,
    val ducksText: String,
    val averageValue: Double?,
    val strikeRateValue: Double?
)

data class ComputedBowlingStats(
    val matchesText: String,
    val inningsText: String,
    val oversAndBallsText: String,
    val wicketsText: String,
    val runsConcededText: String,
    val averageText: String,
    val economyText: String,
    val strikeRateText: String,
    val bestBowlingText: String,
    val fourWicketsText: String,
    val fiveWicketsText: String,
    val tenWicketsText: String,
    val averageValue: Double?,
    val economyValue: Double?,
    val strikeRateValue: Double?
)

data class ComputedFieldingStats(
    val catchesText: String,
    val runOutsText: String,
    val stumpingsText: String,
    val totalDismissalsText: String,
    val totalDismissalsValue: Int?
)

data class RecordHolder(
    val playerId: String,
    val playerName: String,
    val country: String,
    val valueText: String,
    val sourceLabel: String
)

data class CareerRecordsSummary(
    val highestRuns: RecordHolder? = null,
    val mostSixes: RecordHolder? = null,
    val mostFours: RecordHolder? = null,
    val mostCenturies: RecordHolder? = null,
    val mostWickets: RecordHolder? = null,
    val bestBowling: RecordHolder? = null,
    val highestStrikeRate: RecordHolder? = null,
    val highestPartnership: RecordHolder? = null,
    val mostPlayerOfMatch: RecordHolder? = null
)

object CareerStatsCalculator {

    fun formatIntOrNa(value: Int?): String = value?.toString() ?: NOT_AVAILABLE

    fun formatDoubleOrNa(value: Double?, decimals: Int = 2): String {
        if (value == null || value.isNaN() || value.isInfinite()) return NOT_AVAILABLE
        return String.format(Locale.US, "%.${decimals}f", value)
    }

    fun formatOversAndBalls(ballsBowled: Int?): String {
        if (ballsBowled == null) return NOT_AVAILABLE
        val overs = ballsBowled / 6
        val remBalls = ballsBowled % 6
        return "$overs.$remBalls ov ($ballsBowled balls)"
    }

    fun formatTimestamp(epochMillis: Long?): String {
        if (epochMillis == null || epochMillis <= 0L) return NOT_AVAILABLE
        val formatter = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return formatter.format(Date(epochMillis))
    }

    /**
     * Parses overs notation like "12.4" (12 overs, 4 balls -> 76 balls)
     * or integer balls if [isOversNotation] is false. Returns null if blank/invalid.
     */
    fun parseOversToBalls(raw: String): Int? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        return if (trimmed.contains(".")) {
            val parts = trimmed.split(".")
            if (parts.size != 2) return null
            val overs = parts[0].toIntOrNull() ?: return null
            val balls = parts[1].toIntOrNull() ?: return null
            if (overs < 0 || balls !in 0..5) return null
            overs * 6 + balls
        } else {
            val overs = trimmed.toIntOrNull() ?: return null
            if (overs < 0) null else overs * 6
        }
    }

    fun computeBatting(stat: PlayerCareerStatEntity?): ComputedBattingStats {
        if (stat == null) {
            return ComputedBattingStats(
                matchesText = NOT_AVAILABLE,
                inningsText = NOT_AVAILABLE,
                runsText = NOT_AVAILABLE,
                ballsFacedText = NOT_AVAILABLE,
                highestScoreText = NOT_AVAILABLE,
                averageText = NOT_AVAILABLE,
                strikeRateText = NOT_AVAILABLE,
                foursText = NOT_AVAILABLE,
                sixesText = NOT_AVAILABLE,
                hundredsText = NOT_AVAILABLE,
                fiftiesText = NOT_AVAILABLE,
                doubleHundredsText = NOT_AVAILABLE,
                notOutsText = NOT_AVAILABLE,
                ducksText = NOT_AVAILABLE,
                averageValue = null,
                strikeRateValue = null
            )
        }

        val computedAvg = stat.explicitBattingAverage ?: run {
            val runs = stat.runsScored
            val inn = stat.battingInnings
            val no = stat.notOuts
            if (runs != null && inn != null && no != null && (inn - no) > 0) {
                runs.toDouble() / (inn - no)
            } else null
        }

        val computedSr = stat.explicitStrikeRate ?: run {
            val runs = stat.runsScored
            val balls = stat.ballsFaced
            if (runs != null && balls != null && balls > 0) {
                (runs.toDouble() * 100.0) / balls
            } else null
        }

        val hsText = stat.highestScore?.let { hs ->
            if (stat.highestScoreNotOut) "${hs}*" else "$hs"
        } ?: NOT_AVAILABLE

        return ComputedBattingStats(
            matchesText = formatIntOrNa(stat.battingMatches),
            inningsText = formatIntOrNa(stat.battingInnings),
            runsText = formatIntOrNa(stat.runsScored),
            ballsFacedText = formatIntOrNa(stat.ballsFaced),
            highestScoreText = hsText,
            averageText = formatDoubleOrNa(computedAvg),
            strikeRateText = formatDoubleOrNa(computedSr),
            foursText = formatIntOrNa(stat.fours),
            sixesText = formatIntOrNa(stat.sixes),
            hundredsText = formatIntOrNa(stat.hundreds),
            fiftiesText = formatIntOrNa(stat.fifties),
            doubleHundredsText = formatIntOrNa(stat.doubleHundreds),
            notOutsText = formatIntOrNa(stat.notOuts),
            ducksText = formatIntOrNa(stat.ducks),
            averageValue = computedAvg,
            strikeRateValue = computedSr
        )
    }

    fun computeBowling(stat: PlayerCareerStatEntity?): ComputedBowlingStats {
        if (stat == null) {
            return ComputedBowlingStats(
                matchesText = NOT_AVAILABLE,
                inningsText = NOT_AVAILABLE,
                oversAndBallsText = NOT_AVAILABLE,
                wicketsText = NOT_AVAILABLE,
                runsConcededText = NOT_AVAILABLE,
                averageText = NOT_AVAILABLE,
                economyText = NOT_AVAILABLE,
                strikeRateText = NOT_AVAILABLE,
                bestBowlingText = NOT_AVAILABLE,
                fourWicketsText = NOT_AVAILABLE,
                fiveWicketsText = NOT_AVAILABLE,
                tenWicketsText = NOT_AVAILABLE,
                averageValue = null,
                economyValue = null,
                strikeRateValue = null
            )
        }

        val avg = stat.explicitBowlingAverage ?: run {
            val rc = stat.runsConceded
            val wk = stat.wicketsTaken
            if (rc != null && wk != null && wk > 0) rc.toDouble() / wk else null
        }

        val econ = stat.explicitEconomyRate ?: run {
            val rc = stat.runsConceded
            val balls = stat.ballsBowled
            if (rc != null && balls != null && balls > 0) {
                rc.toDouble() / (balls.toDouble() / 6.0)
            } else null
        }

        val sr = stat.explicitBowlingStrikeRate ?: run {
            val balls = stat.ballsBowled
            val wk = stat.wicketsTaken
            if (balls != null && wk != null && wk > 0) balls.toDouble() / wk else null
        }

        val bbiText = if (stat.bestBowlingWickets != null && stat.bestBowlingRuns != null) {
            "${stat.bestBowlingWickets}/${stat.bestBowlingRuns}"
        } else NOT_AVAILABLE

        return ComputedBowlingStats(
            matchesText = formatIntOrNa(stat.bowlingMatches),
            inningsText = formatIntOrNa(stat.bowlingInnings),
            oversAndBallsText = formatOversAndBalls(stat.ballsBowled),
            wicketsText = formatIntOrNa(stat.wicketsTaken),
            runsConcededText = formatIntOrNa(stat.runsConceded),
            averageText = formatDoubleOrNa(avg),
            economyText = formatDoubleOrNa(econ),
            strikeRateText = formatDoubleOrNa(sr),
            bestBowlingText = bbiText,
            fourWicketsText = formatIntOrNa(stat.fourWicketHauls),
            fiveWicketsText = formatIntOrNa(stat.fiveWicketHauls),
            tenWicketsText = formatIntOrNa(stat.tenWicketMatches),
            averageValue = avg,
            economyValue = econ,
            strikeRateValue = sr
        )
    }

    fun computeFielding(stat: PlayerCareerStatEntity?): ComputedFieldingStats {
        if (stat == null) {
            return ComputedFieldingStats(
                catchesText = NOT_AVAILABLE,
                runOutsText = NOT_AVAILABLE,
                stumpingsText = NOT_AVAILABLE,
                totalDismissalsText = NOT_AVAILABLE,
                totalDismissalsValue = null
            )
        }
        val anyPresent = stat.catches != null || stat.runOuts != null || stat.stumpings != null
        val total = if (anyPresent) {
            (stat.catches ?: 0) + (stat.runOuts ?: 0) + (stat.stumpings ?: 0)
        } else null

        return ComputedFieldingStats(
            catchesText = formatIntOrNa(stat.catches),
            runOutsText = formatIntOrNa(stat.runOuts),
            stumpingsText = formatIntOrNa(stat.stumpings),
            totalDismissalsText = formatIntOrNa(total),
            totalDismissalsValue = total
        )
    }

    fun countAvailableMetrics(stat: PlayerCareerStatEntity?): Pair<Int, Int> {
        val totalMetrics = 26
        if (stat == null) return 0 to totalMetrics
        val batting = computeBatting(stat)
        val bowling = computeBowling(stat)
        val fielding = computeFielding(stat)

        val checks = listOf(
            stat.battingMatches,
            stat.battingInnings,
            stat.runsScored,
            stat.ballsFaced,
            stat.highestScore,
            batting.averageValue,
            batting.strikeRateValue,
            stat.fours,
            stat.sixes,
            stat.hundreds,
            stat.fifties,
            stat.doubleHundreds,
            stat.notOuts,
            stat.ducks,
            stat.bowlingMatches,
            stat.bowlingInnings,
            stat.ballsBowled,
            stat.wicketsTaken,
            stat.runsConceded,
            bowling.averageValue,
            bowling.economyValue,
            bowling.strikeRateValue,
            stat.bestBowlingWickets,
            fielding.totalDismissalsValue,
            stat.highestPartnership,
            stat.playerOfMatchAwards
        )
        return checks.count { it != null } to totalMetrics
    }

    fun isBetterBowling(w1: Int, r1: Int, w2: Int, r2: Int): Boolean {
        return w1 > w2 || (w1 == w2 && r1 < r2)
    }

    /**
     * Resolves All-Format Career stats: uses explicit ALL_FORMAT entry if present,
     * otherwise aggregates across available individual formats (Test, ODI, T20I, T20 League, Domestic)
     * without inventing zeroes for missing metrics.
     */
    fun resolveFormatStat(
        playerStats: List<PlayerCareerStatEntity>,
        format: CareerFormatScope
    ): PlayerCareerStatEntity? {
        val formatStats = playerStats.filter { it.scopeType == CareerScopeType.FORMAT.name }
        val direct = formatStats.find { it.scopeKey == format.key }
        if (format != CareerFormatScope.ALL_FORMAT || direct != null) {
            return direct
        }

        val components = formatStats.filter {
            it.scopeKey != CareerFormatScope.ALL_FORMAT.key
        }
        if (components.isEmpty()) return null

        fun sumNullable(selector: (PlayerCareerStatEntity) -> Int?): Int? {
            val present = components.mapNotNull(selector)
            return if (present.isEmpty()) null else present.sum()
        }

        fun maxNullable(selector: (PlayerCareerStatEntity) -> Int?): Int? {
            return components.mapNotNull(selector).maxOrNull()
        }

        var bestHs: Int? = null
        var bestHsNotOut = false
        components.forEach { item ->
            val hs = item.highestScore
            if (hs != null) {
                val currentBest = bestHs
                if (currentBest == null || hs > currentBest || (hs == currentBest && item.highestScoreNotOut && !bestHsNotOut)) {
                    bestHs = hs
                    bestHsNotOut = item.highestScoreNotOut
                }
            }
        }

        var bestBw: Int? = null
        var bestBr: Int? = null
        components.forEach { item ->
            val w = item.bestBowlingWickets
            val r = item.bestBowlingRuns
            if (w != null && r != null) {
                val curW = bestBw
                val curR = bestBr
                if (curW == null || curR == null || isBetterBowling(w, r, curW, curR)) {
                    bestBw = w
                    bestBr = r
                }
            }
        }

        val latestUpdate = components.maxOf { it.lastUpdatedAt }
        val sources = components.map { it.sourceLabel }.distinct().joinToString(" + ")

        return PlayerCareerStatEntity(
            id = "computed_all_format",
            playerId = components.first().playerId,
            scopeType = CareerScopeType.FORMAT.name,
            scopeKey = CareerFormatScope.ALL_FORMAT.key,
            scopeDisplayName = CareerFormatScope.ALL_FORMAT.displayName,
            battingMatches = sumNullable { it.battingMatches },
            battingInnings = sumNullable { it.battingInnings },
            runsScored = sumNullable { it.runsScored },
            ballsFaced = sumNullable { it.ballsFaced },
            highestScore = bestHs,
            highestScoreNotOut = bestHsNotOut,
            notOuts = sumNullable { it.notOuts },
            fours = sumNullable { it.fours },
            sixes = sumNullable { it.sixes },
            hundreds = sumNullable { it.hundreds },
            fifties = sumNullable { it.fifties },
            doubleHundreds = sumNullable { it.doubleHundreds },
            ducks = sumNullable { it.ducks },
            bowlingMatches = sumNullable { it.bowlingMatches },
            bowlingInnings = sumNullable { it.bowlingInnings },
            ballsBowled = sumNullable { it.ballsBowled },
            wicketsTaken = sumNullable { it.wicketsTaken },
            runsConceded = sumNullable { it.runsConceded },
            bestBowlingWickets = bestBw,
            bestBowlingRuns = bestBr,
            fourWicketHauls = sumNullable { it.fourWicketHauls },
            fiveWicketHauls = sumNullable { it.fiveWicketHauls },
            tenWicketMatches = sumNullable { it.tenWicketMatches },
            catches = sumNullable { it.catches },
            runOuts = sumNullable { it.runOuts },
            stumpings = sumNullable { it.stumpings },
            highestPartnership = maxNullable { it.highestPartnership },
            playerOfMatchAwards = sumNullable { it.playerOfMatchAwards },
            sourceLabel = if (sources.isNotBlank()) "Aggregated ($sources)" else "Aggregated",
            lastUpdatedAt = latestUpdate
        )
    }

    fun computeRecordsSummary(
        players: List<PlayerEntity>,
        allStats: List<PlayerCareerStatEntity>,
        selectedFormat: CareerFormatScope
    ): CareerRecordsSummary {
        if (players.isEmpty()) return CareerRecordsSummary()

        val playerMap = players.associateBy { it.id }
        val resolvedByPlayer = players.mapNotNull { player ->
            val pStats = allStats.filter { it.playerId == player.id }
            val resolved = resolveFormatStat(pStats, selectedFormat)
            if (resolved != null) player to resolved else null
        }
        if (resolvedByPlayer.isEmpty()) return CareerRecordsSummary()

        fun topIntRecord(
            valueSelector: (PlayerCareerStatEntity) -> Int?,
            formatter: (PlayerCareerStatEntity, Int) -> String = { _, v -> v.toString() }
        ): RecordHolder? {
            var bestPair: Pair<PlayerEntity, PlayerCareerStatEntity>? = null
            var bestVal = Int.MIN_VALUE
            resolvedByPlayer.forEach { pair ->
                val v = valueSelector(pair.second)
                if (v != null && v > bestVal) {
                    bestVal = v
                    bestPair = pair
                }
            }
            val winner = bestPair ?: return null
            return RecordHolder(
                playerId = winner.first.id,
                playerName = winner.first.fullName,
                country = winner.first.country.ifBlank { NOT_AVAILABLE },
                valueText = formatter(winner.second, bestVal),
                sourceLabel = winner.second.sourceLabel
            )
        }

        // Best Bowling
        var bestBwlPair: Pair<PlayerEntity, PlayerCareerStatEntity>? = null
        var bwBest = -1
        var brBest = Int.MAX_VALUE
        resolvedByPlayer.forEach { pair ->
            val w = pair.second.bestBowlingWickets
            val r = pair.second.bestBowlingRuns
            if (w != null && r != null && isBetterBowling(w, r, bwBest, brBest)) {
                bwBest = w
                brBest = r
                bestBwlPair = pair
            }
        }
        val bestBowlingHolder = bestBwlPair?.let {
            RecordHolder(
                playerId = it.first.id,
                playerName = it.first.fullName,
                country = it.first.country.ifBlank { NOT_AVAILABLE },
                valueText = "$bwBest/$brBest",
                sourceLabel = it.second.sourceLabel
            )
        }

        // Highest Strike Rate
        var bestSrPair: Pair<PlayerEntity, PlayerCareerStatEntity>? = null
        var bestSrVal = -1.0
        resolvedByPlayer.forEach { pair ->
            val sr = computeBatting(pair.second).strikeRateValue
            if (sr != null && sr > bestSrVal) {
                bestSrVal = sr
                bestSrPair = pair
            }
        }
        val highestSrHolder = bestSrPair?.let {
            RecordHolder(
                playerId = it.first.id,
                playerName = it.first.fullName,
                country = it.first.country.ifBlank { NOT_AVAILABLE },
                valueText = formatDoubleOrNa(bestSrVal),
                sourceLabel = it.second.sourceLabel
            )
        }

        // Ensure playerMap is referenced if needed for future expansions
        @Suppress("UNUSED_VARIABLE")
        val count = playerMap.size

        return CareerRecordsSummary(
            highestRuns = topIntRecord({ it.runsScored }),
            mostSixes = topIntRecord({ it.sixes }),
            mostFours = topIntRecord({ it.fours }),
            mostCenturies = topIntRecord({ it.hundreds }),
            mostWickets = topIntRecord({ it.wicketsTaken }),
            bestBowling = bestBowlingHolder,
            highestStrikeRate = highestSrHolder,
            highestPartnership = topIntRecord({ it.highestPartnership }),
            mostPlayerOfMatch = topIntRecord({ it.playerOfMatchAwards })
        )
    }
}

data class ImportedPlayerBundle(
    val player: PlayerEntity,
    val stats: List<PlayerCareerStatEntity>
)

object PlayerJsonCodec {

    fun exportPlayerJson(player: PlayerEntity, stats: List<PlayerCareerStatEntity>): String {
        val root = JSONObject()
        root.put("fullName", player.fullName)
        root.put("country", player.country)
        root.put("dateOfBirth", player.dateOfBirth)
        root.put("role", player.role)
        root.put("battingHand", player.battingHand)
        root.put("bowlingStyle", player.bowlingStyle)
        root.put("currentTeamName", player.currentTeamName)
        root.put("previousTeams", player.previousTeams)
        root.put("internationalCareerNote", player.internationalCareerNote)
        root.put("domesticCareerNote", player.domesticCareerNote)
        root.put("biography", player.biography)
        if (player.jerseyNumber != null) root.put("jerseyNumber", player.jerseyNumber)
        root.put("dataSource", player.dataSource)

        val statsArr = JSONArray()
        stats.forEach { st ->
            val obj = JSONObject()
            obj.put("scopeType", st.scopeType)
            obj.put("scopeKey", st.scopeKey)
            obj.put("scopeDisplayName", st.scopeDisplayName)
            obj.put("sourceLabel", st.sourceLabel)
            st.battingMatches?.let { obj.put("battingMatches", it) }
            st.battingInnings?.let { obj.put("battingInnings", it) }
            st.runsScored?.let { obj.put("runsScored", it) }
            st.ballsFaced?.let { obj.put("ballsFaced", it) }
            st.highestScore?.let { obj.put("highestScore", it) }
            obj.put("highestScoreNotOut", st.highestScoreNotOut)
            st.notOuts?.let { obj.put("notOuts", it) }
            st.fours?.let { obj.put("fours", it) }
            st.sixes?.let { obj.put("sixes", it) }
            st.hundreds?.let { obj.put("hundreds", it) }
            st.fifties?.let { obj.put("fifties", it) }
            st.doubleHundreds?.let { obj.put("doubleHundreds", it) }
            st.ducks?.let { obj.put("ducks", it) }
            st.bowlingMatches?.let { obj.put("bowlingMatches", it) }
            st.bowlingInnings?.let { obj.put("bowlingInnings", it) }
            st.ballsBowled?.let { obj.put("ballsBowled", it) }
            st.wicketsTaken?.let { obj.put("wicketsTaken", it) }
            st.runsConceded?.let { obj.put("runsConceded", it) }
            st.bestBowlingWickets?.let { obj.put("bestBowlingWickets", it) }
            st.bestBowlingRuns?.let { obj.put("bestBowlingRuns", it) }
            st.fourWicketHauls?.let { obj.put("fourWicketHauls", it) }
            st.fiveWicketHauls?.let { obj.put("fiveWicketHauls", it) }
            st.tenWicketMatches?.let { obj.put("tenWicketMatches", it) }
            st.catches?.let { obj.put("catches", it) }
            st.runOuts?.let { obj.put("runOuts", it) }
            st.stumpings?.let { obj.put("stumpings", it) }
            st.highestPartnership?.let { obj.put("highestPartnership", it) }
            st.playerOfMatchAwards?.let { obj.put("playerOfMatchAwards", it) }
            statsArr.put(obj)
        }
        root.put("careerStats", statsArr)
        return root.toString(2)
    }

    fun parsePlayerImportJson(rawJson: String): Result<ImportedPlayerBundle> {
        return runCatching {
            val root = JSONObject(rawJson.trim())
            val fullName = root.optString("fullName", "").trim()
            require(fullName.isNotEmpty()) { "JSON must contain a non-empty 'fullName' field." }

            val now = System.currentTimeMillis()
            val playerId = root.optString("id", "").trim().ifEmpty { UUID.randomUUID().toString() }
            val source = root.optString("dataSource", "").trim().ifEmpty { "JSON Import" }

            fun JSONObject.optNullableInt(key: String): Int? =
                if (has(key) && !isNull(key)) optInt(key) else null

            fun JSONObject.optNullableDouble(key: String): Double? =
                if (has(key) && !isNull(key)) optDouble(key) else null

            val player = PlayerEntity(
                id = playerId,
                fullName = fullName,
                role = root.optString("role", "All-Rounder").ifBlank { "All-Rounder" },
                battingHand = root.optString("battingHand", "Right-hand bat").ifBlank { "Right-hand bat" },
                bowlingStyle = root.optString("bowlingStyle", "Right-arm medium").ifBlank { "Right-arm medium" },
                country = root.optString("country", ""),
                dateOfBirth = root.optString("dateOfBirth", ""),
                currentTeamName = root.optString("currentTeamName", ""),
                previousTeams = root.optString("previousTeams", ""),
                internationalCareerNote = root.optString("internationalCareerNote", ""),
                domesticCareerNote = root.optString("domesticCareerNote", ""),
                biography = root.optString("biography", ""),
                jerseyNumber = root.optNullableInt("jerseyNumber"),
                dataSource = source,
                createdAt = now,
                updatedAt = now
            )

            val statsList = mutableListOf<PlayerCareerStatEntity>()
            val statsArray = root.optJSONArray("careerStats") ?: JSONArray()
            for (i in 0 until statsArray.length()) {
                val obj = statsArray.getJSONObject(i)
                val scopeTypeRaw = obj.optString("scopeType", CareerScopeType.FORMAT.name).uppercase()
                val scopeType = if (scopeTypeRaw == CareerScopeType.LEAGUE.name) {
                    CareerScopeType.LEAGUE.name
                } else {
                    CareerScopeType.FORMAT.name
                }
                val scopeKey = obj.optString("scopeKey", "").trim().uppercase()
                require(scopeKey.isNotEmpty()) { "Each careerStats item requires 'scopeKey'." }
                val displayName = obj.optString("scopeDisplayName", "").trim().ifEmpty {
                    CareerFormatScope.fromKey(scopeKey)?.displayName ?: scopeKey
                }

                statsList.add(
                    PlayerCareerStatEntity(
                        id = "${playerId}_${scopeType}_${scopeKey}",
                        playerId = playerId,
                        scopeType = scopeType,
                        scopeKey = scopeKey,
                        scopeDisplayName = displayName,
                        battingMatches = obj.optNullableInt("battingMatches"),
                        battingInnings = obj.optNullableInt("battingInnings"),
                        runsScored = obj.optNullableInt("runsScored"),
                        ballsFaced = obj.optNullableInt("ballsFaced"),
                        highestScore = obj.optNullableInt("highestScore"),
                        highestScoreNotOut = obj.optBoolean("highestScoreNotOut", false),
                        notOuts = obj.optNullableInt("notOuts"),
                        fours = obj.optNullableInt("fours"),
                        sixes = obj.optNullableInt("sixes"),
                        hundreds = obj.optNullableInt("hundreds"),
                        fifties = obj.optNullableInt("fifties"),
                        doubleHundreds = obj.optNullableInt("doubleHundreds"),
                        ducks = obj.optNullableInt("ducks"),
                        explicitBattingAverage = obj.optNullableDouble("explicitBattingAverage"),
                        explicitStrikeRate = obj.optNullableDouble("explicitStrikeRate"),
                        bowlingMatches = obj.optNullableInt("bowlingMatches"),
                        bowlingInnings = obj.optNullableInt("bowlingInnings"),
                        ballsBowled = obj.optNullableInt("ballsBowled"),
                        wicketsTaken = obj.optNullableInt("wicketsTaken"),
                        runsConceded = obj.optNullableInt("runsConceded"),
                        bestBowlingWickets = obj.optNullableInt("bestBowlingWickets"),
                        bestBowlingRuns = obj.optNullableInt("bestBowlingRuns"),
                        fourWicketHauls = obj.optNullableInt("fourWicketHauls"),
                        fiveWicketHauls = obj.optNullableInt("fiveWicketHauls"),
                        tenWicketMatches = obj.optNullableInt("tenWicketMatches"),
                        explicitBowlingAverage = obj.optNullableDouble("explicitBowlingAverage"),
                        explicitEconomyRate = obj.optNullableDouble("explicitEconomyRate"),
                        explicitBowlingStrikeRate = obj.optNullableDouble("explicitBowlingStrikeRate"),
                        catches = obj.optNullableInt("catches"),
                        runOuts = obj.optNullableInt("runOuts"),
                        stumpings = obj.optNullableInt("stumpings"),
                        highestPartnership = obj.optNullableInt("highestPartnership"),
                        playerOfMatchAwards = obj.optNullableInt("playerOfMatchAwards"),
                        sourceLabel = obj.optString("sourceLabel", source).ifBlank { source },
                        lastUpdatedAt = now
                    )
                )
            }

            ImportedPlayerBundle(player = player, stats = statsList)
        }
    }
}
