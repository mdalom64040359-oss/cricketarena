package com.example.domain

import com.example.data.local.entity.FavouriteType
import com.example.data.local.entity.UserAccountEntity
import com.example.data.local.entity.UserFavouriteEntity
import com.example.data.local.entity.UserPersonalSettingsEntity
import com.example.data.sync.SyncStatus
import org.json.JSONArray
import org.json.JSONObject

data class RestoredPersonalBackup(
    val fullName: String,
    val bio: String,
    val cityOrPhone: String,
    val settings: UserPersonalSettingsEntity,
    val favourites: List<UserFavouriteEntity>,
    val exportedAt: Long
)

/**
 * Exports and validates per-user Personal Control Panel JSON backups.
 * Password hashes, salts, and other users' records are NEVER included.
 */
object PersonalBackupCodec {

    private const val BACKUP_SCHEMA = "cricket_arena_personal_backup_v1"

    fun exportBackupJson(
        account: UserAccountEntity,
        settings: UserPersonalSettingsEntity,
        favourites: List<UserFavouriteEntity>
    ): String {
        val root = JSONObject()
        root.put("schema", BACKUP_SCHEMA)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("userId", account.userId)

        val profileObj = JSONObject().apply {
            put("fullName", account.fullName)
            put("emailOrHandle", account.emailOrHandle)
            put("bio", account.bio)
            put("cityOrPhone", account.cityOrPhone)
        }
        root.put("profile", profileObj)

        val settingsObj = JSONObject().apply {
            put("languageCode", settings.languageCode)
            put("themeMode", settings.themeMode)
            put("notificationsEnabled", settings.notificationsEnabled)
            put("matchStartAlerts", settings.matchStartAlerts)
            put("wicketAlerts", settings.wicketAlerts)
            put("milestoneAlerts", settings.milestoneAlerts)
            put("profilePrivate", settings.profilePrivate)
            put("analyticsOptIn", settings.analyticsOptIn)
            put("autoSyncWhenOnline", settings.autoSyncWhenOnline)
        }
        root.put("settings", settingsObj)

        val favArray = JSONArray()
        favourites.forEach { fav ->
            favArray.put(
                JSONObject().apply {
                    put("itemType", fav.itemType)
                    put("itemKey", fav.itemKey)
                    put("displayName", fav.displayName)
                    put("subtitle", fav.subtitle)
                    put("matchAlertsEnabled", fav.matchAlertsEnabled)
                }
            )
        }
        root.put("favourites", favArray)
        return root.toString(2)
    }

    fun parseAndValidateBackup(
        rawJson: String,
        targetUserId: String
    ): Result<RestoredPersonalBackup> {
        return runCatching {
            val root = JSONObject(rawJson.trim())
            val schema = root.optString("schema", "")
            require(schema == BACKUP_SCHEMA) {
                "Invalid backup schema. Expected $BACKUP_SCHEMA."
            }

            val profileObj = root.getJSONObject("profile")
            val fullName = profileObj.optString("fullName", "").trim()
            require(fullName.isNotEmpty()) { "Backup profile must contain a valid name." }

            val settingsObj = root.optJSONObject("settings") ?: JSONObject()
            val now = System.currentTimeMillis()
            val lang = settingsObj.optString("languageCode", "en").let {
                if (it == "bn") "bn" else "en"
            }
            val theme = settingsObj.optString("themeMode", "SYSTEM").let {
                if (it in setOf("SYSTEM", "DARK", "LIGHT")) it else "SYSTEM"
            }

            val restoredSettings = UserPersonalSettingsEntity(
                userId = targetUserId,
                languageCode = lang,
                themeMode = theme,
                notificationsEnabled = settingsObj.optBoolean("notificationsEnabled", false),
                matchStartAlerts = settingsObj.optBoolean("matchStartAlerts", true),
                wicketAlerts = settingsObj.optBoolean("wicketAlerts", false),
                milestoneAlerts = settingsObj.optBoolean("milestoneAlerts", false),
                profilePrivate = settingsObj.optBoolean("profilePrivate", true),
                analyticsOptIn = settingsObj.optBoolean("analyticsOptIn", false),
                autoSyncWhenOnline = settingsObj.optBoolean("autoSyncWhenOnline", true),
                updatedAt = now,
                syncStatus = SyncStatus.PENDING_SYNC.name
            )

            val favArray = root.optJSONArray("favourites") ?: JSONArray()
            val favs = mutableListOf<UserFavouriteEntity>()
            for (i in 0 until favArray.length()) {
                val obj = favArray.getJSONObject(i)
                val rawType = obj.optString("itemType", FavouriteType.TEAM.name).uppercase()
                val type = FavouriteType.entries.find { it.name == rawType } ?: FavouriteType.TEAM
                val key = obj.optString("itemKey", "").trim()
                val name = obj.optString("displayName", "").trim()
                if (key.isNotEmpty() && name.isNotEmpty()) {
                    favs.add(
                        UserFavouriteEntity(
                            id = "${targetUserId}::${type.name}::${key}",
                            userId = targetUserId,
                            itemType = type.name,
                            itemKey = key,
                            displayName = name,
                            subtitle = obj.optString("subtitle", ""),
                            matchAlertsEnabled = obj.optBoolean("matchAlertsEnabled", true),
                            createdAt = now,
                            syncStatus = SyncStatus.PENDING_SYNC.name
                        )
                    )
                }
            }

            RestoredPersonalBackup(
                fullName = fullName,
                bio = profileObj.optString("bio", ""),
                cityOrPhone = profileObj.optString("cityOrPhone", ""),
                settings = restoredSettings,
                favourites = favs,
                exportedAt = root.optLong("exportedAt", now)
            )
        }
    }
}
