package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.CricketArenaDatabase
import com.example.data.local.UserSessionStore
import com.example.data.repository.OfflineFirstArenaRepository
import com.example.data.repository.OfflineFirstUserAccountRepository
import com.example.data.repository.OfflinePlayerCareerRepository
import com.example.ui.CricketArenaApp
import com.example.ui.i18n.LocalArenaStrings
import com.example.ui.i18n.stringsForLanguage
import com.example.ui.theme.CricketArenaTheme
import com.example.ui.viewmodel.DashboardViewModel
import com.example.ui.viewmodel.PlayerCareerViewModel
import com.example.ui.viewmodel.UserAccountViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = CricketArenaDatabase.getInstance(applicationContext)
        val arenaRepository = OfflineFirstArenaRepository(database.arenaDao())
        val playerCareerRepository = OfflinePlayerCareerRepository(database)
        val userSessionStore = UserSessionStore(applicationContext)
        val userAccountRepository = OfflineFirstUserAccountRepository(database, userSessionStore)

        setContent {
            val dashboardViewModel: DashboardViewModel = viewModel(
                factory = DashboardViewModel.Factory(arenaRepository)
            )
            val playerCareerViewModel: PlayerCareerViewModel = viewModel(
                factory = PlayerCareerViewModel.Factory(playerCareerRepository)
            )
            val userAccountViewModel: UserAccountViewModel = viewModel(
                factory = UserAccountViewModel.Factory(userAccountRepository, applicationContext)
            )

            val userSessionState by userAccountViewModel.uiState.collectAsStateWithLifecycle()
            val darkTheme = when (userSessionState.settings?.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }
            val localizedStrings = stringsForLanguage(
                userSessionState.settings?.languageCode ?: "en"
            )

            CompositionLocalProvider(LocalArenaStrings provides localizedStrings) {
                CricketArenaTheme(darkTheme = darkTheme) {
                    CricketArenaApp(
                        viewModel = dashboardViewModel,
                        playerCareerViewModel = playerCareerViewModel,
                        userAccountViewModel = userAccountViewModel
                    )
                }
            }
        }
    }
}
