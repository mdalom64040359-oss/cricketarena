package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.FavouriteType
import com.example.data.local.entity.MajorLeagueCatalog
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.TeamEntity
import com.example.data.local.entity.UserAccountEntity
import com.example.ui.i18n.LocalArenaStrings
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import java.io.BufferedReader
import java.io.InputStreamReader

@Composable
fun EditPersonalProfileDialog(
    account: UserAccountEntity,
    onDismiss: () -> Unit,
    onSave: (fullName: String, bio: String, cityOrPhone: String, photoUri: String?) -> Unit
) {
    val strings = LocalArenaStrings.current
    var fullName by remember { mutableStateOf(account.fullName) }
    var cityOrPhone by remember { mutableStateOf(account.cityOrPhone) }
    var bio by remember { mutableStateOf(account.bio) }
    var photoUri by remember { mutableStateOf(account.photoUri) }
    var nameError by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(strings.editProfile, style = MaterialTheme.typography.titleLarge)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 430.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "User ID: ${account.userId}  •  ${account.emailOrHandle}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PlayerAvatar(
                        fullName = fullName.ifBlank { account.fullName },
                        photoUri = photoUri,
                        size = 56.dp
                    )
                    OutlinedButton(
                        onClick = {
                            photoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AddAPhoto,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Change Photo")
                    }
                    if (photoUri != null) {
                        TextButton(onClick = { photoUri = null }) {
                            Text("Remove")
                        }
                    }
                }

                OutlinedTextField(
                    value = fullName,
                    onValueChange = {
                        fullName = it
                        nameError = false
                    },
                    isError = nameError,
                    label = { Text("Full Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_profile_name_input")
                )

                OutlinedTextField(
                    value = cityOrPhone,
                    onValueChange = { cityOrPhone = it },
                    label = { Text("City / Phone") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("Bio / About Me") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fullName.isBlank()) {
                        nameError = true
                    } else {
                        onSave(fullName, bio, cityOrPhone, photoUri)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("edit_profile_save_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ChangePasswordDialog(
    onDismiss: () -> Unit,
    onSubmit: (currentPassword: String, newPassword: String) -> Unit
) {
    val strings = LocalArenaStrings.current
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.changePassword, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMsg != null) {
                    Text(
                        text = errorMsg ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                OutlinedTextField(
                    value = currentPassword,
                    onValueChange = {
                        currentPassword = it
                        errorMsg = null
                    },
                    label = { Text("Current Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("change_pwd_current_input")
                )

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = {
                        newPassword = it
                        errorMsg = null
                    },
                    label = { Text("New Password (min 6 chars)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("change_pwd_new_input")
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = {
                        confirmPassword = it
                        errorMsg = null
                    },
                    label = { Text("Confirm New Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("change_pwd_confirm_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when {
                        currentPassword.isEmpty() -> errorMsg = "Enter your current password."
                        newPassword.length < 6 -> errorMsg = "New password must be at least 6 characters."
                        newPassword != confirmPassword -> errorMsg = "Passwords do not match."
                        else -> onSubmit(currentPassword, newPassword)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("change_pwd_submit_button")
            ) {
                Text("Update Password")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddFavouriteDialog(
    initialType: FavouriteType,
    teams: List<TeamEntity>,
    players: List<PlayerEntity>,
    matches: List<MatchEntity>,
    onDismiss: () -> Unit,
    onAddFavourite: (type: FavouriteType, key: String, displayName: String, subtitle: String) -> Unit
) {
    var selectedType by remember { mutableStateOf(initialType) }
    var customName by remember { mutableStateOf("") }
    var customSubtitle by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to Personal Favourites", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FavouriteType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = {
                                Text(
                                    when (type) {
                                        FavouriteType.TEAM -> "Team"
                                        FavouriteType.PLAYER -> "Player"
                                        FavouriteType.LEAGUE -> "League"
                                        FavouriteType.MATCH -> "Match"
                                    }
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ArenaDeepGreen,
                                selectedLabelColor = ArenaPureWhite
                            )
                        )
                    }
                }

                // Quick-pick suggestions from local database or MajorLeagueCatalog
                val quickSuggestions: List<Triple<String, String, String>> = when (selectedType) {
                    FavouriteType.LEAGUE -> MajorLeagueCatalog.leagues.map {
                        Triple(it.key, it.displayName, it.region)
                    }
                    FavouriteType.PLAYER -> players.map {
                        Triple(it.id, it.fullName, "${it.country.ifBlank { "Cricket" }} • ${it.role}")
                    }
                    FavouriteType.TEAM -> teams.map {
                        Triple(it.id, it.name, it.shortCode)
                    }
                    FavouriteType.MATCH -> matches.map {
                        Triple(it.id, it.title, "${it.format} • ${it.oversPerInnings}ov")
                    }
                }

                if (quickSuggestions.isNotEmpty()) {
                    Text(
                        text = "Tap to Quick-Add:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        quickSuggestions.take(12).forEach { (key, title, sub) ->
                            Surface(
                                onClick = {
                                    onAddFavourite(selectedType, key, title, sub)
                                    onDismiss()
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Text(
                                    text = "+ $title",
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "Or add custom ${selectedType.name.lowercase()}:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = customName,
                    onValueChange = {
                        customName = it
                        nameError = false
                    },
                    isError = nameError,
                    label = { Text("Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_fav_name_input")
                )

                OutlinedTextField(
                    value = customSubtitle,
                    onValueChange = { customSubtitle = it },
                    label = { Text("Note / League / Country (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val clean = customName.trim()
                    if (clean.isEmpty()) {
                        nameError = true
                    } else {
                        val key = clean.lowercase().replace(Regex("[^a-z0-9]+"), "_")
                        onAddFavourite(selectedType, key, clean, customSubtitle)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("add_fav_confirm_button")
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun PersonalBackupDialog(
    userId: String,
    onExportJson: ((String) -> Unit) -> Unit,
    onRestoreJson: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalArenaStrings.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var exportedJson by remember { mutableStateOf("") }
    var restoreInput by remember { mutableStateOf("") }
    var statusBanner by remember { mutableStateOf<String?>(null) }
    var pendingConfirmRestore by remember { mutableStateOf(false) }

    LaunchedEffect(userId) {
        onExportJson { json ->
            exportedJson = json
        }
    }

    val createBackupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null && exportedJson.isNotEmpty()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(exportedJson.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                statusBanner = "Personal backup file saved safely."
            }.onFailure { err ->
                statusBanner = "Save failed: ${err.message}"
            }
        }
    }

    val openBackupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                } ?: ""
            }.onSuccess { loaded ->
                restoreInput = loaded
                statusBanner = "Backup file loaded. Review and tap Restore to apply."
            }.onFailure { err ->
                statusBanner = "Could not read file: ${err.message}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.backupRestore, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Export or restore only YOUR personal profile, settings, and favourites ($userId). Password hashes are never exported.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (statusBanner != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = ArenaDeepGreen.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, ArenaDeepGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusBanner ?: "",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Text(
                    text = "Export Backup",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (exportedJson.isNotEmpty()) {
                                clipboard.setText(AnnotatedString(exportedJson))
                                statusBanner = "Personal backup JSON copied to clipboard."
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("backup_copy_button")
                    ) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy JSON", maxLines = 1)
                    }

                    Button(
                        onClick = {
                            createBackupDocLauncher.launch("cricket_arena_${userId.lowercase()}_backup.json")
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ArenaDeepGreen,
                            contentColor = ArenaPureWhite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save File", maxLines = 1)
                    }
                }

                Text(
                    text = "Restore Backup",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                OutlinedButton(
                    onClick = {
                        openBackupDocLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Load .json Backup File")
                }

                OutlinedTextField(
                    value = restoreInput,
                    onValueChange = { restoreInput = it },
                    label = { Text("Or Paste Backup JSON") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("backup_restore_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (restoreInput.isBlank()) {
                        statusBanner = "Paste or load a backup JSON first."
                    } else {
                        pendingConfirmRestore = true
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("backup_restore_apply_button")
            ) {
                Text("Restore Data")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )

    if (pendingConfirmRestore) {
        AlertDialog(
            onDismissRequest = { pendingConfirmRestore = false },
            title = { Text("Confirm Personal Restore?") },
            text = {
                Text("Restoring this backup will replace your current personal settings and favourites for $userId.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRestoreJson(restoreInput)
                        pendingConfirmRestore = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ArenaDeepGreen,
                        contentColor = ArenaPureWhite
                    )
                ) {
                    Text("Confirm Restore")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirmRestore = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun DeleteMyAccountDialog(
    userId: String,
    onDismiss: () -> Unit,
    onConfirmDelete: (password: String) -> Unit
) {
    val strings = LocalArenaStrings.current
    var password by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Rounded.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error
            )
        },
        title = { Text(strings.deleteMyAccount, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "This will permanently delete your account ($userId), personal settings, and favourites. Match & team records in Cricket Arena stay safe.",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (errorMsg != null) {
                    Text(
                        text = errorMsg ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        errorMsg = null
                    },
                    label = { Text("Enter Your Password to Confirm") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("delete_account_password_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (password.isEmpty()) {
                        errorMsg = "Password is required to delete your account."
                    } else {
                        onConfirmDelete(password)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("delete_account_confirm_button")
            ) {
                Text("Delete Permanently")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
