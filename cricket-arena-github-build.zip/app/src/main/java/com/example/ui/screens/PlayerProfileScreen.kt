package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.CareerScopeType
import com.example.data.local.entity.MajorLeagueCatalog
import com.example.domain.PlayerJsonCodec
import com.example.ui.components.CareerStatEditorDialog
import com.example.ui.components.PlayerProfile
import com.example.ui.components.PlayerProfileEditorDialog
import com.example.ui.components.RecordMatchContributionDialog
import com.example.ui.viewmodel.PlayerCareerViewModel
import com.example.ui.viewmodel.PlayerProfileUiState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerProfileScreen(
    playerId: String,
    profileState: PlayerProfileUiState,
    viewModel: PlayerCareerViewModel,
    onNavigateBack: () -> Unit,
    onComparePlayer: (String) -> Unit,
    isFavourite: Boolean = false,
    onToggleFavourite: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    LaunchedEffect(playerId) {
        viewModel.selectPlayer(playerId)
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        viewModel.events.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    var selectedFormat by remember { mutableStateOf(CareerFormatScope.ALL_FORMAT) }
    var selectedLeagueKey by remember { mutableStateOf<String?>(null) }

    var showEditProfile by remember { mutableStateOf(false) }
    var showEditStats by remember { mutableStateOf(false) }
    var showLogMatch by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val player = profileState.player

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = player?.fullName ?: "Player Profile",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("profile_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                actions = {
                    if (player != null) {
                        if (onToggleFavourite != null) {
                            IconButton(
                                onClick = onToggleFavourite,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("player_profile_favourite_button")
                            ) {
                                Icon(
                                    imageVector = if (isFavourite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    contentDescription = if (isFavourite) "Remove from Favourite Players" else "Add to Favourite Players"
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                val exported = PlayerJsonCodec.exportPlayerJson(player, profileState.stats)
                                clipboard.setText(AnnotatedString(exported))
                                scope.launch {
                                    snackbarHostState.showSnackbar("Copied player career JSON to clipboard.")
                                }
                            },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Export Player JSON")
                        }
                        IconButton(
                            onClick = { showDeleteConfirm = true },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete Player")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { innerPadding ->
        if (player == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Player profile not found.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            PlayerProfile(
                player = player,
                stats = profileState.stats,
                matchLedger = profileState.matchLedger,
                selectedFormat = selectedFormat,
                selectedLeagueKey = selectedLeagueKey,
                onSelectFormat = { selectedFormat = it },
                onSelectLeague = { selectedLeagueKey = it },
                onEditProfile = { showEditProfile = true },
                onEditStats = { showEditStats = true },
                onLogMatch = { showLogMatch = true },
                onCompare = { onComparePlayer(player.id) },
                modifier = Modifier.padding(innerPadding)
            )
        }
    }

    if (showEditProfile && player != null) {
        PlayerProfileEditorDialog(
            existingPlayer = player,
            onDismiss = { showEditProfile = false },
            onSave = { updated ->
                viewModel.savePlayer(updated)
                showEditProfile = false
            }
        )
    }

    if (showEditStats && player != null) {
        val editingScopeType = if (selectedLeagueKey != null) CareerScopeType.LEAGUE else CareerScopeType.FORMAT
        val editingScopeKey = selectedLeagueKey ?: selectedFormat.key
        val editingScopeName = selectedLeagueKey?.let { key ->
            MajorLeagueCatalog.leagues.find { it.key == key }?.displayName ?: key
        } ?: selectedFormat.displayName
        val existingScopeStat = profileState.stats.find {
            it.scopeType == editingScopeType.name && it.scopeKey == editingScopeKey
        }

        CareerStatEditorDialog(
            playerId = player.id,
            initialScopeType = editingScopeType,
            initialScopeKey = editingScopeKey,
            initialScopeName = editingScopeName,
            existingStat = existingScopeStat,
            onDismiss = { showEditStats = false },
            onSave = { updatedStat ->
                viewModel.saveScopeStat(updatedStat)
                showEditStats = false
            }
        )
    }

    if (showLogMatch && player != null) {
        RecordMatchContributionDialog(
            onDismiss = { showLogMatch = false },
            onSubmit = { delta ->
                viewModel.recordMatchContribution(player.id, delta)
                showLogMatch = false
            }
        )
    }

    if (showDeleteConfirm && player != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Player Profile?") },
            text = { Text("This will remove ${player.fullName} and all locally saved career statistics.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePlayer(player.id) {
                            showDeleteConfirm = false
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}
