package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Cricket Arena Brand Colors: Dark Green, Black & White
val ArenaDeepGreen = Color(0xFF0A2F1D)
val ArenaForestGreen = Color(0xFF114B2F)
val ArenaPitchGreen = Color(0xFF176942)
val ArenaTurfAccent = Color(0xFF20B566)
val ArenaMintHighlight = Color(0xFF4ADE80)

val ArenaPitchBlack = Color(0xFF060A08)
val ArenaCarbonBlack = Color(0xFF0D1410)
val ArenaElevatedBlack = Color(0xFF141F1A)
val ArenaCardDark = Color(0xFF192720)

val ArenaPureWhite = Color(0xFFFFFFFF)
val ArenaChalkWhite = Color(0xFFF5F8F6)
val ArenaSoftSurface = Color(0xFFE9F0EC)
val ArenaLightBorder = Color(0xFFD2DFD8)
val ArenaDarkBorder = Color(0xFF24382D)

val ArenaMutedTextLight = Color(0xFF495951)
val ArenaMutedTextDark = Color(0xFFA7B8AF)

val ArenaLiveRed = Color(0xFFEF4444)
val ArenaAlertAmber = Color(0xFFF59E0B)
