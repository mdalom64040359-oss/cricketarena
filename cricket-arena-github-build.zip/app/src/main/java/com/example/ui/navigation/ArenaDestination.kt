package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.SportsCricket
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.SportsCricket
import androidx.compose.ui.graphics.vector.ImageVector

sealed class ArenaDestination(val route: String, val title: String) {
    data object Home : ArenaDestination("home", "Cricket Arena")
    data object Matches : ArenaDestination("matches", "Matches")
    data object Teams : ArenaDestination("teams", "Teams")
    data object Tournaments : ArenaDestination("tournaments", "Tournaments")
    data object Statistics : ArenaDestination("statistics", "Statistics")

    // Secondary routes accessible from Dashboard & section headers
    data object CreateMatch : ArenaDestination("create_match", "Create Match")
    data object CreateTournament : ArenaDestination("create_tournament", "Create Tournament")
    data object Players : ArenaDestination("players", "Players")
    data object StorageBackup : ArenaDestination("storage_backup", "Offline Storage & Sync")

    // Player Career Statistics & Records routes
    data object PlayerProfile : ArenaDestination("player_profile/{playerId}", "Player Profile") {
        fun createRoute(playerId: String): String = "player_profile/$playerId"
    }
    data object PlayerComparison : ArenaDestination("player_comparison", "Compare Players")
    data object CareerRecords : ArenaDestination("career_records", "Career Records")

    // Personal User Account & Control Panel
    data object PersonalPanel : ArenaDestination("personal_panel", "Personal Control Panel")
}

data class BottomNavItem(
    val destination: ArenaDestination,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

val ArenaBottomNavItems = listOf(
    BottomNavItem(
        destination = ArenaDestination.Home,
        label = "Home",
        selectedIcon = Icons.Rounded.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "bottom_nav_home"
    ),
    BottomNavItem(
        destination = ArenaDestination.Matches,
        label = "Matches",
        selectedIcon = Icons.Rounded.SportsCricket,
        unselectedIcon = Icons.Outlined.SportsCricket,
        testTag = "bottom_nav_matches"
    ),
    BottomNavItem(
        destination = ArenaDestination.Teams,
        label = "Teams",
        selectedIcon = Icons.Rounded.Groups,
        unselectedIcon = Icons.Outlined.Groups,
        testTag = "bottom_nav_teams"
    ),
    BottomNavItem(
        destination = ArenaDestination.Tournaments,
        label = "Tourneys",
        selectedIcon = Icons.Rounded.EmojiEvents,
        unselectedIcon = Icons.Outlined.EmojiEvents,
        testTag = "bottom_nav_tournaments"
    ),
    BottomNavItem(
        destination = ArenaDestination.Statistics,
        label = "Stats",
        selectedIcon = Icons.Rounded.BarChart,
        unselectedIcon = Icons.Outlined.BarChart,
        testTag = "bottom_nav_statistics"
    )
)
