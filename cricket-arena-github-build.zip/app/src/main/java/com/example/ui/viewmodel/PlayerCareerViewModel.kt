package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.PlayerMatchContributionEntity
import com.example.data.repository.MatchContributionResult
import com.example.data.repository.MatchStatDelta
import com.example.data.repository.PlayerCareerRepository
import com.example.domain.CareerRecordsSummary
import com.example.domain.CareerStatsCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlayerDirectoryUiState(
    val players: List<PlayerEntity> = emptyList(),
    val allStats: List<PlayerCareerStatEntity> = emptyList(),
    val searchQuery: String = "",
    val selectedRoleFilter: String = "All",
    val selectedRecordsFormat: CareerFormatScope = CareerFormatScope.ALL_FORMAT
) {
    val filteredPlayers: List<PlayerEntity>
        get() = players.filter { player ->
            val matchesQuery = searchQuery.isBlank() ||
                player.fullName.contains(searchQuery, ignoreCase = true) ||
                player.country.contains(searchQuery, ignoreCase = true) ||
                player.currentTeamName.contains(searchQuery, ignoreCase = true)
            val matchesRole = selectedRoleFilter == "All" ||
                player.role.equals(selectedRoleFilter, ignoreCase = true)
            matchesQuery && matchesRole
        }

    val recordsSummary: CareerRecordsSummary
        get() = CareerStatsCalculator.computeRecordsSummary(players, allStats, selectedRecordsFormat)
}

data class PlayerProfileUiState(
    val player: PlayerEntity? = null,
    val stats: List<PlayerCareerStatEntity> = emptyList(),
    val matchLedger: List<PlayerMatchContributionEntity> = emptyList()
)

class PlayerCareerViewModel(
    private val repository: PlayerCareerRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _roleFilter = MutableStateFlow("All")
    private val _recordsFormat = MutableStateFlow(CareerFormatScope.ALL_FORMAT)
    private val _selectedPlayerId = MutableStateFlow<String?>(null)

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    val directoryState: StateFlow<PlayerDirectoryUiState> = combine(
        repository.observeAllPlayers(),
        repository.observeAllCareerStats(),
        _searchQuery,
        _roleFilter,
        _recordsFormat
    ) { players, stats, query, role, format ->
        PlayerDirectoryUiState(
            players = players,
            allStats = stats,
            searchQuery = query,
            selectedRoleFilter = role,
            selectedRecordsFormat = format
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PlayerDirectoryUiState()
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedProfileState: StateFlow<PlayerProfileUiState> = _selectedPlayerId
        .flatMapLatest { id ->
            if (id == null) {
                flowOf(PlayerProfileUiState())
            } else {
                combine(
                    repository.observePlayerById(id),
                    repository.observeStatsForPlayer(id),
                    repository.observeMatchLedgerForPlayer(id)
                ) { player, stats, ledger ->
                    PlayerProfileUiState(
                        player = player,
                        stats = stats,
                        matchLedger = ledger
                    )
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = PlayerProfileUiState()
        )

    fun observeStatsFor(playerId: String): Flow<List<PlayerCareerStatEntity>> =
        repository.observeStatsForPlayer(playerId)

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setRoleFilter(role: String) {
        _roleFilter.value = role
    }

    fun setRecordsFormat(format: CareerFormatScope) {
        _recordsFormat.value = format
    }

    fun selectPlayer(playerId: String) {
        _selectedPlayerId.value = playerId
    }

    fun savePlayer(player: PlayerEntity, onSaved: (String) -> Unit = {}) {
        viewModelScope.launch {
            repository.savePlayer(player)
            _events.emit("Saved profile for ${player.fullName}.")
            onSaved(player.id)
        }
    }

    fun deletePlayer(playerId: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePlayer(playerId)
            _events.emit("Player profile removed.")
            onDeleted()
        }
    }

    fun saveScopeStat(stat: PlayerCareerStatEntity) {
        viewModelScope.launch {
            repository.upsertCareerStat(stat)
            _events.emit("Updated ${stat.scopeDisplayName} statistics.")
        }
    }

    fun recordMatchContribution(playerId: String, delta: MatchStatDelta) {
        viewModelScope.launch {
            when (val result = repository.applyMatchContribution(playerId, delta)) {
                is MatchContributionResult.Applied -> {
                    _events.emit("Added match '${delta.matchTitle.ifBlank { delta.matchId }}' to ${delta.scopeDisplayName}.")
                }
                is MatchContributionResult.DuplicateBlocked -> {
                    _events.emit("Duplicate blocked: Match '${result.matchId}' was already recorded for this scope.")
                }
                is MatchContributionResult.Error -> {
                    _events.emit(result.message)
                }
            }
        }
    }

    fun importPlayerJson(rawJson: String, onSuccess: (PlayerEntity) -> Unit = {}) {
        viewModelScope.launch {
            repository.importPlayerJson(rawJson)
                .onSuccess { imported ->
                    _events.emit("Imported ${imported.fullName} successfully.")
                    onSuccess(imported)
                }
                .onFailure { err ->
                    _events.emit("Import failed: ${err.message ?: "Invalid JSON format"}")
                }
        }
    }

    class Factory(private val repository: PlayerCareerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(PlayerCareerViewModel::class.java)) {
                return PlayerCareerViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
