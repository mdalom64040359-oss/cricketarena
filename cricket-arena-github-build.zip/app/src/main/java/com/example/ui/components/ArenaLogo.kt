package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent

@Composable
fun CricketArenaBrandHeader(
    isOfflineReady: Boolean,
    onStorageBadgeClick: () -> Unit,
    accountName: String? = null,
    accountPhotoUri: String? = null,
    onAccountClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(ArenaDeepGreen)
                    .border(
                        width = 1.5.dp,
                        color = ArenaTurfAccent.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(13.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_arena_emblem),
                    contentDescription = "Cricket Arena Logo",
                    modifier = Modifier.size(40.dp),
                    contentScale = ContentScale.Crop
                )
            }

            Column {
                Text(
                    text = "CRICKET ARENA",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Match & Tournament Control",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(start = 6.dp)
        ) {
            Surface(
                onClick = onStorageBadgeClick,
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.border(
                    width = 1.dp,
                    color = ArenaTurfAccent.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(50)
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isOfflineReady) ArenaTurfAccent else MaterialTheme.colorScheme.error)
                    )
                    Text(
                        text = "Offline",
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
            }

            if (onAccountClick != null) {
                Surface(
                    onClick = onAccountClick,
                    shape = RoundedCornerShape(50),
                    color = if (accountName != null) ArenaDeepGreen else MaterialTheme.colorScheme.surface,
                    contentColor = if (accountName != null) ArenaPureWhite else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .border(
                            width = 1.dp,
                            color = ArenaTurfAccent.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(50)
                        )
                        .testTag("header_account_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        if (accountName != null) {
                            PlayerAvatar(
                                fullName = accountName,
                                photoUri = accountPhotoUri,
                                size = 26.dp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = accountName.substringBefore(" ").take(8),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.AccountCircle,
                                contentDescription = "Sign In or Sign Up",
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Account",
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
