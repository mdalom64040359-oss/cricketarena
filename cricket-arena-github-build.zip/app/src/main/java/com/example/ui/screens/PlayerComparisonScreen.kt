package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.PlayerEntity
import com.example.domain.CareerStatsCalculator
import com.example.domain.NOT_AVAILABLE
import com.example.ui.components.PlayerAvatar
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent
import com.example.ui.viewmodel.PlayerDirectoryUiState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PlayerComparisonScreen(
    directoryState: PlayerDirectoryUiState,
    initialPlayerAId: String? = null,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val players = directoryState.players
    var playerAId by remember(players, initialPlayerAId) {
        mutableStateOf(
            initialPlayerAId?.takeIf { id -> players.any { it.id == id } }
                ?: players.firstOrNull()?.id
        )
    }
    var playerBId by remember(players) {
        mutableStateOf(
            players.firstOrNull { it.id != playerAId }?.id ?: players.firstOrNull()?.id
        )
    }
    var selectedFormat by remember { mutableStateOf(CareerFormatScope.ALL_FORMAT) }

    val playerA = players.find { it.id == playerAId }
    val playerB = players.find { it.id == playerBId }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text("Compare Players", style = MaterialTheme.typography.titleLarge)
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("comparison_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (players.size < 2) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .padding(16.dp)
                        .widthIn(max = 640.dp)
                        .fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Add at least 2 players to compare",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Currently ${players.size} player profile(s) saved. Create or import players in the Players Hub to compare career stats side-by-side.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                val statsA = playerA?.let { p ->
                    CareerStatsCalculator.resolveFormatStat(
                        directoryState.allStats.filter { it.playerId == p.id },
                        selectedFormat
                    )
                }
                val statsB = playerB?.let { p ->
                    CareerStatsCalculator.resolveFormatStat(
                        directoryState.allStats.filter { it.playerId == p.id },
                        selectedFormat
                    )
                }

                val batA = CareerStatsCalculator.computeBatting(statsA)
                val batB = CareerStatsCalculator.computeBatting(statsB)
                val bowlA = CareerStatsCalculator.computeBowling(statsA)
                val bowlB = CareerStatsCalculator.computeBowling(statsB)
                val fieldA = CareerStatsCalculator.computeFielding(statsA)
                val fieldB = CareerStatsCalculator.computeFielding(statsB)

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 900.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Format selector
                    item {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CareerFormatScope.entries.forEach { fmt ->
                                FilterChip(
                                    selected = selectedFormat == fmt,
                                    onClick = { selectedFormat = fmt },
                                    label = { Text(fmt.shortLabel) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ArenaDeepGreen,
                                        selectedLabelColor = ArenaPureWhite
                                    )
                                )
                            }
                        }
                    }

                    // Player A & B Pickers
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PlayerSelectorCard(
                                label = "Player 1",
                                selected = playerA,
                                players = players,
                                onSelect = { playerAId = it.id },
                                modifier = Modifier.weight(1f)
                            )
                            PlayerSelectorCard(
                                label = "Player 2",
                                selected = playerB,
                                players = players,
                                onSelect = { playerBId = it.id },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Comparison Table: Batting
                    item {
                        ComparisonSectionCard(
                            sectionTitle = "Batting Comparison (${selectedFormat.displayName})",
                            rows = listOf(
                                CompareRow("Matches", batA.matchesText, batB.matchesText, statsA?.battingMatches?.toDouble(), statsB?.battingMatches?.toDouble()),
                                CompareRow("Innings", batA.inningsText, batB.inningsText, statsA?.battingInnings?.toDouble(), statsB?.battingInnings?.toDouble()),
                                CompareRow("Runs", batA.runsText, batB.runsText, statsA?.runsScored?.toDouble(), statsB?.runsScored?.toDouble()),
                                CompareRow("Highest", batA.highestScoreText, batB.highestScoreText, statsA?.highestScore?.toDouble(), statsB?.highestScore?.toDouble()),
                                CompareRow("Average", batA.averageText, batB.averageText, batA.averageValue, batB.averageValue),
                                CompareRow("Strike Rate", batA.strikeRateText, batB.strikeRateText, batA.strikeRateValue, batB.strikeRateValue),
                                CompareRow("100s / 50s", "${batA.hundredsText} / ${batA.fiftiesText}", "${batB.hundredsText} / ${batB.fiftiesText}"),
                                CompareRow("4s / 6s", "${batA.foursText} / ${batA.sixesText}", "${batB.foursText} / ${batB.sixesText}")
                            )
                        )
                    }

                    // Comparison Table: Bowling
                    item {
                        ComparisonSectionCard(
                            sectionTitle = "Bowling Comparison",
                            rows = listOf(
                                CompareRow("Wickets", bowlA.wicketsText, bowlB.wicketsText, statsA?.wicketsTaken?.toDouble(), statsB?.wicketsTaken?.toDouble()),
                                CompareRow("Overs", bowlA.oversAndBallsText, bowlB.oversAndBallsText, statsA?.ballsBowled?.toDouble(), statsB?.ballsBowled?.toDouble()),
                                CompareRow("Bowling Avg", bowlA.averageText, bowlB.averageText, bowlA.averageValue, bowlB.averageValue, lowerIsBetter = true),
                                CompareRow("Economy", bowlA.economyText, bowlB.economyText, bowlA.economyValue, bowlB.economyValue, lowerIsBetter = true),
                                CompareRow("Bowling SR", bowlA.strikeRateText, bowlB.strikeRateText, bowlA.strikeRateValue, bowlB.strikeRateValue, lowerIsBetter = true),
                                CompareRow("Best Bowling", bowlA.bestBowlingText, bowlB.bestBowlingText),
                                CompareRow("4W / 5W", "${bowlA.fourWicketsText} / ${bowlA.fiveWicketsText}", "${bowlB.fourWicketsText} / ${bowlB.fiveWicketsText}")
                            )
                        )
                    }

                    // Comparison Table: Fielding & Records
                    item {
                        ComparisonSectionCard(
                            sectionTitle = "Fielding & Personal Records",
                            rows = listOf(
                                CompareRow("Catches", fieldA.catchesText, fieldB.catchesText, statsA?.catches?.toDouble(), statsB?.catches?.toDouble()),
                                CompareRow("Dismissals", fieldA.totalDismissalsText, fieldB.totalDismissalsText, fieldA.totalDismissalsValue?.toDouble(), fieldB.totalDismissalsValue?.toDouble()),
                                CompareRow("Best Partnership", CareerStatsCalculator.formatIntOrNa(statsA?.highestPartnership), CareerStatsCalculator.formatIntOrNa(statsB?.highestPartnership), statsA?.highestPartnership?.toDouble(), statsB?.highestPartnership?.toDouble()),
                                CompareRow("POTM Awards", CareerStatsCalculator.formatIntOrNa(statsA?.playerOfMatchAwards), CareerStatsCalculator.formatIntOrNa(statsB?.playerOfMatchAwards), statsA?.playerOfMatchAwards?.toDouble(), statsB?.playerOfMatchAwards?.toDouble())
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerSelectorCard(
    label: String,
    selected: PlayerEntity?,
    players: List<PlayerEntity>,
    onSelect: (PlayerEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (selected != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PlayerAvatar(fullName = selected.fullName, photoUri = selected.photoUri, size = 36.dp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selected.fullName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = selected.role,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
            Box {
                OutlinedButton(
                    onClick = { expanded = true },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                ) {
                    Text("Change", maxLines = 1)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    players.forEach { candidate ->
                        DropdownMenuItem(
                            text = { Text("${candidate.fullName} (${candidate.role})") },
                            onClick = {
                                onSelect(candidate)
                                expanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

private data class CompareRow(
    val metric: String,
    val leftText: String,
    val rightText: String,
    val leftVal: Double? = null,
    val rightVal: Double? = null,
    val lowerIsBetter: Boolean = false
)

@Composable
private fun ComparisonSectionCard(
    sectionTitle: String,
    rows: List<CompareRow>
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = sectionTitle,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            rows.forEachIndexed { index, row ->
                if (index > 0) HorizontalDivider()
                val leftWins = row.leftVal != null && row.rightVal != null && row.leftVal != row.rightVal &&
                    if (row.lowerIsBetter) row.leftVal < row.rightVal else row.leftVal > row.rightVal
                val rightWins = row.leftVal != null && row.rightVal != null && row.leftVal != row.rightVal &&
                    if (row.lowerIsBetter) row.rightVal < row.leftVal else row.rightVal > row.leftVal

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ComparisonValueBadge(
                        text = row.leftText,
                        isWinner = leftWins,
                        alignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = row.metric,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.95f)
                    )
                    ComparisonValueBadge(
                        text = row.rightText,
                        isWinner = rightWins,
                        alignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ComparisonValueBadge(
    text: String,
    isWinner: Boolean,
    alignment: Alignment.Horizontal,
    modifier: Modifier = Modifier
) {
    val isMissing = text == NOT_AVAILABLE || text == "$NOT_AVAILABLE / $NOT_AVAILABLE"
    Column(modifier = modifier, horizontalAlignment = alignment) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isWinner) ArenaDeepGreen else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (isWinner) FontWeight.Bold else FontWeight.Medium
                ),
                color = when {
                    isWinner -> ArenaPureWhite
                    isMissing -> MaterialTheme.colorScheme.onSurfaceVariant
                    else -> MaterialTheme.colorScheme.onSurface
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}
