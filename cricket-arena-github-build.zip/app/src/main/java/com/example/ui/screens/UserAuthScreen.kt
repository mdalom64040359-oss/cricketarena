package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.ui.components.PlayerAvatar
import com.example.ui.i18n.LocalArenaStrings
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent

enum class AuthMode {
    LOGIN,
    SIGN_UP,
    FORGOT_PASSWORD
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserAuthScreen(
    snackbarHostState: SnackbarHostState,
    onLogin: (emailOrHandle: String, password: String) -> Unit,
    onSignUp: (
        fullName: String,
        emailOrHandle: String,
        password: String,
        recoveryCode: String,
        cityOrPhone: String,
        bio: String,
        photoUri: String?
    ) -> Unit,
    onResetPassword: (emailOrHandle: String, recoveryCode: String, newPassword: String) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val strings = LocalArenaStrings.current
    var mode by rememberSaveable { mutableStateOf(AuthMode.LOGIN) }

    var loginHandle by rememberSaveable { mutableStateOf("") }
    var loginPassword by rememberSaveable { mutableStateOf("") }
    var loginPasswordVisible by remember { mutableStateOf(false) }

    var signUpName by rememberSaveable { mutableStateOf("") }
    var signUpHandle by rememberSaveable { mutableStateOf("") }
    var signUpPassword by rememberSaveable { mutableStateOf("") }
    var signUpConfirmPassword by rememberSaveable { mutableStateOf("") }
    var signUpRecoveryCode by rememberSaveable { mutableStateOf("") }
    var signUpCityOrPhone by rememberSaveable { mutableStateOf("") }
    var signUpBio by rememberSaveable { mutableStateOf("") }
    var signUpPhotoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var signUpPasswordVisible by remember { mutableStateOf(false) }

    var resetHandle by rememberSaveable { mutableStateOf("") }
    var resetRecoveryCode by rememberSaveable { mutableStateOf("") }
    var resetNewPassword by rememberSaveable { mutableStateOf("") }
    var resetConfirmPassword by rememberSaveable { mutableStateOf("") }
    var resetPasswordVisible by remember { mutableStateOf(false) }

    var validationError by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            signUpPhotoUri = uri.toString()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (mode) {
                            AuthMode.LOGIN -> strings.signInTitle
                            AuthMode.SIGN_UP -> strings.signUpTitle
                            AuthMode.FORGOT_PASSWORD -> strings.forgotPasswordTitle
                        },
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("auth_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 600.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Hero banner introducing Personal Cricket Arena Account
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = ArenaDeepGreen),
                    border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null,
                                tint = ArenaTurfAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "PERSONAL ACCOUNT • PRIVATE & OFFLINE",
                                style = MaterialTheme.typography.labelSmall,
                                color = ArenaTurfAccent
                            )
                        }
                        Text(
                            text = if (strings.languageCode == "bn") {
                                "আপনার ব্যক্তিগত Cricket Arena অ্যাকাউন্ট"
                            } else {
                                "Your Personal Cricket Arena Account"
                            },
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = ArenaPureWhite
                        )
                        Text(
                            text = if (strings.languageCode == "bn") {
                                "নিজের User ID, পছন্দের দল-খেলোয়াড়-লিগ, ভাষা ও প্রাইভেসি নিয়ন্ত্রণ করুন সম্পূর্ণ অফলাইন ও নিরাপদভাবে।"
                            } else {
                                "Get your unique User ID, manage your own favourite teams, players, leagues, language, and personal backups securely offline."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArenaPureWhite.copy(alpha = 0.85f)
                        )
                    }
                }

                // Mode switcher chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = mode == AuthMode.LOGIN,
                        onClick = {
                            mode = AuthMode.LOGIN
                            validationError = null
                        },
                        label = { Text(strings.signInTitle) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArenaDeepGreen,
                            selectedLabelColor = ArenaPureWhite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("auth_tab_login")
                    )
                    FilterChip(
                        selected = mode == AuthMode.SIGN_UP,
                        onClick = {
                            mode = AuthMode.SIGN_UP
                            validationError = null
                        },
                        label = { Text(strings.signUpTitle) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArenaDeepGreen,
                            selectedLabelColor = ArenaPureWhite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("auth_tab_signup")
                    )
                    FilterChip(
                        selected = mode == AuthMode.FORGOT_PASSWORD,
                        onClick = {
                            mode = AuthMode.FORGOT_PASSWORD
                            validationError = null
                        },
                        label = { Text("Reset") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArenaDeepGreen,
                            selectedLabelColor = ArenaPureWhite
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("auth_tab_forgot")
                    )
                }

                if (validationError != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = validationError ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        when (mode) {
                            AuthMode.LOGIN -> {
                                OutlinedTextField(
                                    value = loginHandle,
                                    onValueChange = {
                                        loginHandle = it
                                        validationError = null
                                    },
                                    label = { Text("Email or Username") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_login_handle_input")
                                )

                                OutlinedTextField(
                                    value = loginPassword,
                                    onValueChange = {
                                        loginPassword = it
                                        validationError = null
                                    },
                                    label = { Text("Password") },
                                    singleLine = true,
                                    visualTransformation = if (loginPasswordVisible) {
                                        VisualTransformation.None
                                    } else {
                                        PasswordVisualTransformation()
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { loginPasswordVisible = !loginPasswordVisible }) {
                                            Icon(
                                                imageVector = if (loginPasswordVisible) {
                                                    Icons.Rounded.VisibilityOff
                                                } else {
                                                    Icons.Rounded.Visibility
                                                },
                                                contentDescription = "Toggle password visibility"
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_login_password_input")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            resetHandle = loginHandle
                                            mode = AuthMode.FORGOT_PASSWORD
                                            validationError = null
                                        },
                                        modifier = Modifier.testTag("auth_forgot_link")
                                    ) {
                                        Text("${strings.forgotPasswordTitle}?")
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (loginHandle.isBlank() || loginPassword.isBlank()) {
                                            validationError = "Please enter your email/username and password."
                                        } else {
                                            onLogin(loginHandle, loginPassword)
                                        }
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ArenaDeepGreen,
                                        contentColor = ArenaPureWhite
                                    ),
                                    contentPadding = PaddingValues(vertical = 14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("auth_login_submit_button")
                                ) {
                                    Text(strings.signInTitle, style = MaterialTheme.typography.labelLarge)
                                }
                            }

                            AuthMode.SIGN_UP -> {
                                // Profile picture row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    PlayerAvatar(
                                        fullName = signUpName.ifBlank { "New User" },
                                        photoUri = signUpPhotoUri,
                                        size = 64.dp
                                    )
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "Profile Picture (Optional)",
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = {
                                                    photoPicker.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                                modifier = Modifier
                                                    .minimumInteractiveComponentSize()
                                                    .testTag("auth_signup_photo_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.AddAPhoto,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Choose Photo")
                                            }
                                            if (signUpPhotoUri != null) {
                                                TextButton(onClick = { signUpPhotoUri = null }) {
                                                    Text("Remove")
                                                }
                                            }
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = signUpName,
                                    onValueChange = {
                                        signUpName = it
                                        validationError = null
                                    },
                                    label = { Text("Full Name *") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_signup_name_input")
                                )

                                OutlinedTextField(
                                    value = signUpHandle,
                                    onValueChange = {
                                        signUpHandle = it
                                        validationError = null
                                    },
                                    label = { Text("Email or Username * (min 3 chars)") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_signup_handle_input")
                                )

                                OutlinedTextField(
                                    value = signUpPassword,
                                    onValueChange = {
                                        signUpPassword = it
                                        validationError = null
                                    },
                                    label = { Text("Password * (min 6 chars)") },
                                    singleLine = true,
                                    visualTransformation = if (signUpPasswordVisible) {
                                        VisualTransformation.None
                                    } else {
                                        PasswordVisualTransformation()
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { signUpPasswordVisible = !signUpPasswordVisible }) {
                                            Icon(
                                                imageVector = if (signUpPasswordVisible) {
                                                    Icons.Rounded.VisibilityOff
                                                } else {
                                                    Icons.Rounded.Visibility
                                                },
                                                contentDescription = "Toggle password visibility"
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_signup_password_input")
                                )

                                OutlinedTextField(
                                    value = signUpConfirmPassword,
                                    onValueChange = {
                                        signUpConfirmPassword = it
                                        validationError = null
                                    },
                                    label = { Text("Confirm Password *") },
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_signup_confirm_input")
                                )

                                OutlinedTextField(
                                    value = signUpRecoveryCode,
                                    onValueChange = {
                                        signUpRecoveryCode = it
                                        validationError = null
                                    },
                                    label = { Text("Personal Recovery Code * (min 4 chars)") },
                                    supportingText = {
                                        Text("Save this secret phrase/PIN to reset your password offline if forgotten.")
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Rounded.Key, contentDescription = null)
                                    },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_signup_recovery_input")
                                )

                                OutlinedTextField(
                                    value = signUpCityOrPhone,
                                    onValueChange = { signUpCityOrPhone = it },
                                    label = { Text("City / Phone (Optional)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = signUpBio,
                                    onValueChange = { signUpBio = it },
                                    label = { Text("Short Bio / Favourite Cricket Role (Optional)") },
                                    minLines = 2,
                                    maxLines = 3,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = {
                                        when {
                                            signUpName.isBlank() -> {
                                                validationError = "Please enter your full name."
                                            }
                                            signUpHandle.trim().length < 3 -> {
                                                validationError = "Email or username must be at least 3 characters."
                                            }
                                            signUpPassword.length < 6 -> {
                                                validationError = "Password must be at least 6 characters."
                                            }
                                            signUpPassword != signUpConfirmPassword -> {
                                                validationError = "Passwords do not match."
                                            }
                                            signUpRecoveryCode.trim().length < 4 -> {
                                                validationError = "Recovery code must be at least 4 characters."
                                            }
                                            else -> {
                                                onSignUp(
                                                    signUpName,
                                                    signUpHandle,
                                                    signUpPassword,
                                                    signUpRecoveryCode,
                                                    signUpCityOrPhone,
                                                    signUpBio,
                                                    signUpPhotoUri
                                                )
                                            }
                                        }
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ArenaDeepGreen,
                                        contentColor = ArenaPureWhite
                                    ),
                                    contentPadding = PaddingValues(vertical = 14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("auth_signup_submit_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PersonAdd,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.signUpTitle, style = MaterialTheme.typography.labelLarge)
                                }
                            }

                            AuthMode.FORGOT_PASSWORD -> {
                                Text(
                                    text = "Verify your account with the personal Recovery Code you created during Sign Up to set a new password offline.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                OutlinedTextField(
                                    value = resetHandle,
                                    onValueChange = {
                                        resetHandle = it
                                        validationError = null
                                    },
                                    label = { Text("Email or Username *") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_reset_handle_input")
                                )

                                OutlinedTextField(
                                    value = resetRecoveryCode,
                                    onValueChange = {
                                        resetRecoveryCode = it
                                        validationError = null
                                    },
                                    label = { Text("Personal Recovery Code *") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_reset_recovery_input")
                                )

                                OutlinedTextField(
                                    value = resetNewPassword,
                                    onValueChange = {
                                        resetNewPassword = it
                                        validationError = null
                                    },
                                    label = { Text("New Password * (min 6 chars)") },
                                    singleLine = true,
                                    visualTransformation = if (resetPasswordVisible) {
                                        VisualTransformation.None
                                    } else {
                                        PasswordVisualTransformation()
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { resetPasswordVisible = !resetPasswordVisible }) {
                                            Icon(
                                                imageVector = if (resetPasswordVisible) {
                                                    Icons.Rounded.VisibilityOff
                                                } else {
                                                    Icons.Rounded.Visibility
                                                },
                                                contentDescription = "Toggle password visibility"
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_reset_password_input")
                                )

                                OutlinedTextField(
                                    value = resetConfirmPassword,
                                    onValueChange = {
                                        resetConfirmPassword = it
                                        validationError = null
                                    },
                                    label = { Text("Confirm New Password *") },
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_reset_confirm_input")
                                )

                                Button(
                                    onClick = {
                                        when {
                                            resetHandle.isBlank() || resetRecoveryCode.isBlank() -> {
                                                validationError = "Please enter your email/username and recovery code."
                                            }
                                            resetNewPassword.length < 6 -> {
                                                validationError = "New password must be at least 6 characters."
                                            }
                                            resetNewPassword != resetConfirmPassword -> {
                                                validationError = "New passwords do not match."
                                            }
                                            else -> {
                                                onResetPassword(resetHandle, resetRecoveryCode, resetNewPassword)
                                                loginHandle = resetHandle
                                                mode = AuthMode.LOGIN
                                            }
                                        }
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ArenaDeepGreen,
                                        contentColor = ArenaPureWhite
                                    ),
                                    contentPadding = PaddingValues(vertical = 14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("auth_reset_submit_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.LockReset,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Reset Password", style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
