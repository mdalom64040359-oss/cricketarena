package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ArenaDarkColorScheme = darkColorScheme(
    primary = ArenaTurfAccent,
    onPrimary = ArenaPitchBlack,
    primaryContainer = ArenaDeepGreen,
    onPrimaryContainer = ArenaPureWhite,
    secondary = ArenaPitchGreen,
    onSecondary = ArenaPureWhite,
    secondaryContainer = ArenaCardDark,
    onSecondaryContainer = ArenaChalkWhite,
    tertiary = ArenaMintHighlight,
    onTertiary = ArenaPitchBlack,
    background = ArenaPitchBlack,
    onBackground = ArenaPureWhite,
    surface = ArenaCarbonBlack,
    onSurface = ArenaPureWhite,
    surfaceVariant = ArenaElevatedBlack,
    onSurfaceVariant = ArenaMutedTextDark,
    outline = ArenaDarkBorder,
    outlineVariant = ArenaCardDark,
    error = ArenaLiveRed,
    onError = ArenaPureWhite
)

private val ArenaLightColorScheme = lightColorScheme(
    primary = ArenaDeepGreen,
    onPrimary = ArenaPureWhite,
    primaryContainer = ArenaForestGreen,
    onPrimaryContainer = ArenaPureWhite,
    secondary = ArenaPitchBlack,
    onSecondary = ArenaPureWhite,
    secondaryContainer = ArenaSoftSurface,
    onSecondaryContainer = ArenaPitchBlack,
    tertiary = ArenaTurfAccent,
    onTertiary = ArenaPureWhite,
    background = ArenaChalkWhite,
    onBackground = ArenaPitchBlack,
    surface = ArenaPureWhite,
    onSurface = ArenaPitchBlack,
    surfaceVariant = ArenaSoftSurface,
    onSurfaceVariant = ArenaMutedTextLight,
    outline = ArenaLightBorder,
    outlineVariant = ArenaSoftSurface,
    error = ArenaLiveRed,
    onError = ArenaPureWhite
)

val ArenaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CricketArenaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ArenaDarkColorScheme else ArenaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CricketArenaTypography,
        shapes = ArenaShapes,
        content = content
    )
}
