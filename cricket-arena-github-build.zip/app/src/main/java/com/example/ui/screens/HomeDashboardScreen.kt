package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SportsCricket
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.MatchFormat
import com.example.ui.components.CricketArenaBrandHeader
import com.example.ui.components.PlayerAvatar
import com.example.ui.i18n.LocalArenaStrings
import com.example.ui.navigation.ArenaDestination
import com.example.ui.theme.ArenaCarbonBlack
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaForestGreen
import com.example.ui.theme.ArenaPitchBlack
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent
import com.example.ui.viewmodel.DashboardUiState
import com.example.ui.viewmodel.UserSessionUiState

@Composable
fun HomeDashboardScreen(
    uiState: DashboardUiState,
    onNavigate: (ArenaDestination) -> Unit,
    userSessionState: UserSessionUiState = UserSessionUiState(),
    modifier: Modifier = Modifier
) {
    when (uiState) {
        is DashboardUiState.Loading -> {
            Box(
                modifier = modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        }

        is DashboardUiState.Ready -> {
            BoxWithConstraints(
                modifier = modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                val isWide = maxWidth >= 600.dp

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 920.dp)
                        .align(Alignment.TopCenter),
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 16.dp,
                        bottom = 28.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    // 1. Cricket Arena Logo & App Title Header
                    item {
                        CricketArenaBrandHeader(
                            isOfflineReady = uiState.storageStatus.isOfflineReady,
                            onStorageBadgeClick = { onNavigate(ArenaDestination.StorageBackup) },
                            accountName = userSessionState.account?.fullName,
                            accountPhotoUri = userSessionState.account?.photoUri,
                            onAccountClick = { onNavigate(ArenaDestination.PersonalPanel) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // 1b. Personal Account & Control Panel Quick Entry
                    item {
                        PersonalAccountSummaryCard(
                            userSessionState = userSessionState,
                            onOpenPersonalPanel = { onNavigate(ArenaDestination.PersonalPanel) }
                        )
                    }

                    // 2. Hero Match Center Banner (Create Match & Create Tournament)
                    item {
                        HeroMatchCenterCard(
                            onCreateMatchClick = { onNavigate(ArenaDestination.CreateMatch) },
                            onCreateTournamentClick = { onNavigate(ArenaDestination.CreateTournament) }
                        )
                    }

                    // 3. Live Matches Section
                    item {
                        LiveMatchesSection(
                            liveMatches = uiState.liveMatches,
                            onViewAllMatches = { onNavigate(ArenaDestination.Matches) },
                            onCreateMatch = { onNavigate(ArenaDestination.CreateMatch) }
                        )
                    }

                    // 4. Core Management Hub Grid (Create Tournament, Teams, Players, Statistics)
                    item {
                        ManagementGridSection(
                            isWide = isWide,
                            teamCount = uiState.counts.teamCount,
                            playerCount = uiState.counts.playerCount,
                            tournamentCount = uiState.counts.tournamentCount,
                            matchCount = uiState.counts.matchCount,
                            onNavigate = onNavigate
                        )
                    }

                    // 5. Supported Formats Strip & Offline Storage Foundation Card
                    item {
                        SupportedFormatsStrip()
                    }

                    item {
                        OfflineArchitectureCard(
                            engineName = uiState.storageStatus.engineName,
                            onClick = { onNavigate(ArenaDestination.StorageBackup) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroMatchCenterCard(
    onCreateMatchClick: () -> Unit,
    onCreateTournamentClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = ArenaPitchBlack),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = ArenaTurfAccent.copy(alpha = 0.35f),
                shape = RoundedCornerShape(24.dp)
            )
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_stadium_hero),
                contentDescription = "Cricket stadium pitch under floodlights",
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.52f
            )

            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ArenaPitchBlack.copy(alpha = 0.65f),
                                ArenaDeepGreen.copy(alpha = 0.88f),
                                ArenaPitchBlack.copy(alpha = 0.94f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArenaTurfAccent.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "ARENA COMMAND CENTER",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArenaPureWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Score Every Ball.\nManage Every League.",
                        style = MaterialTheme.typography.headlineMedium,
                        color = ArenaPureWhite
                    )
                    Text(
                        text = "T10, T20, ODI, Test & Custom Overs — built to score reliably offline on your phone.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArenaPureWhite.copy(alpha = 0.82f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onCreateMatchClick,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ArenaPureWhite,
                            contentColor = ArenaPitchBlack
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("create_match_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AddCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Create Match",
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    OutlinedButton(
                        onClick = onCreateTournamentClick,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.2.dp, ArenaPureWhite.copy(alpha = 0.75f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = ArenaPureWhite,
                            containerColor = ArenaDeepGreen.copy(alpha = 0.45f)
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("create_tournament_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EmojiEvents,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Tournament",
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveMatchesSection(
    liveMatches: List<MatchEntity>,
    onViewAllMatches: () -> Unit,
    onCreateMatch: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            if (liveMatches.isNotEmpty()) ArenaTurfAccent
                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                )
                Text(
                    text = "Live Matches",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Text(
                        text = "${liveMatches.size} Active",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            TextButton(
                onClick = onViewAllMatches,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("view_all_matches_button")
            ) {
                Text(
                    text = "All Matches",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                    contentDescription = "View all matches",
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        if (liveMatches.isEmpty()) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("empty_live_matches_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(ArenaDeepGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SportsCricket,
                            contentDescription = "Live cricket matches",
                            tint = ArenaPureWhite,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "No live matches right now",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Your local matches will appear here once created and started.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        onClick = onCreateMatch,
                        shape = RoundedCornerShape(12.dp),
                        color = ArenaDeepGreen,
                        contentColor = ArenaPureWhite,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("empty_live_create_match_button")
                    ) {
                        Text(
                            text = "New",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                liveMatches.forEach { match ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = ArenaCarbonBlack),
                        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onViewAllMatches() }
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = match.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = ArenaPureWhite
                            )
                            Text(
                                text = "${match.format} • ${match.oversPerInnings} Overs",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ArenaTurfAccent
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class QuickModuleItem(
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val icon: ImageVector,
    val destination: ArenaDestination,
    val isDarkGreenHighlight: Boolean,
    val testTag: String
)

@Composable
private fun ManagementGridSection(
    isWide: Boolean,
    teamCount: Int,
    playerCount: Int,
    tournamentCount: Int,
    matchCount: Int,
    onNavigate: (ArenaDestination) -> Unit
) {
    val items = listOf(
        QuickModuleItem(
            title = "Teams",
            subtitle = "Manage squads & lineups",
            badgeText = "$teamCount Saved",
            icon = Icons.Rounded.Groups,
            destination = ArenaDestination.Teams,
            isDarkGreenHighlight = false,
            testTag = "dashboard_teams_card"
        ),
        QuickModuleItem(
            title = "Players",
            subtitle = "Batters, bowlers & roles",
            badgeText = "$playerCount Saved",
            icon = Icons.Rounded.Person,
            destination = ArenaDestination.Players,
            isDarkGreenHighlight = false,
            testTag = "dashboard_players_card"
        ),
        QuickModuleItem(
            title = "Create Tournament",
            subtitle = "20, 24, 32, 40, 50+ teams",
            badgeText = "$tournamentCount Active",
            icon = Icons.Rounded.EmojiEvents,
            destination = ArenaDestination.CreateTournament,
            isDarkGreenHighlight = true,
            testTag = "dashboard_tournament_card"
        ),
        QuickModuleItem(
            title = "Statistics",
            subtitle = "NRR, leaderboards & form",
            badgeText = "$matchCount Matches",
            icon = Icons.Rounded.BarChart,
            destination = ArenaDestination.Statistics,
            isDarkGreenHighlight = false,
            testTag = "dashboard_stats_card"
        )
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Arena Modules",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        val rows = if (isWide) listOf(items) else items.chunked(2)
        rows.forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowItems.forEach { item ->
                    ModuleActionCard(
                        item = item,
                        onClick = { onNavigate(item.destination) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ModuleActionCard(
    item: QuickModuleItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = if (item.isDarkGreenHighlight) {
        ArenaDeepGreen
    } else {
        MaterialTheme.colorScheme.surface
    }
    val titleColor = if (item.isDarkGreenHighlight) {
        ArenaPureWhite
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    val subtitleColor = if (item.isDarkGreenHighlight) {
        ArenaPureWhite.copy(alpha = 0.78f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(
            width = 1.dp,
            color = if (item.isDarkGreenHighlight) {
                ArenaTurfAccent.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.outline
            }
        ),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag(item.testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (item.isDarkGreenHighlight) ArenaForestGreen
                            else MaterialTheme.colorScheme.secondaryContainer
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = if (item.isDarkGreenHighlight) ArenaPureWhite else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (item.isDarkGreenHighlight) {
                        ArenaTurfAccent.copy(alpha = 0.2f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = item.badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (item.isDarkGreenHighlight) ArenaPureWhite else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        maxLines = 1
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = titleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = subtitleColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SupportedFormatsStrip() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Supported Formats",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MatchFormat.entries.forEach { format ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Text(
                        text = if (format == MatchFormat.CUSTOM) "Custom Overs" else "${format.label} (${format.defaultOvers}ov)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun OfflineArchitectureCard(
    engineName: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ArenaCarbonBlack),
        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("dashboard_storage_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ArenaDeepGreen),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Storage,
                    contentDescription = "Offline Storage",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = "Offline-First Architecture Ready",
                    style = MaterialTheme.typography.titleMedium,
                    color = ArenaPureWhite
                )
                Text(
                    text = "$engineName • Cloud Sync Ready",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArenaPureWhite.copy(alpha = 0.72f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = Icons.Rounded.CloudOff,
                contentDescription = "Works offline",
                tint = ArenaTurfAccent,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun PersonalAccountSummaryCard(
    userSessionState: UserSessionUiState,
    onOpenPersonalPanel: () -> Unit
) {
    val strings = LocalArenaStrings.current
    val account = userSessionState.account
    Card(
        onClick = onOpenPersonalPanel,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("dashboard_account_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (account != null) {
                PlayerAvatar(
                    fullName = account.fullName,
                    photoUri = account.photoUri,
                    size = 44.dp
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(ArenaDeepGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AccountCircle,
                        contentDescription = null,
                        tint = ArenaPureWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = account?.fullName ?: "${strings.signInTitle} / ${strings.signUpTitle}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (account != null) {
                        "ID: ${account.userId} • ${userSessionState.favourites.size} Favourites • ${strings.personalPanelTitle}"
                    } else {
                        "Create your personal profile, favourites, language (বাংলা/EN) & backup"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = ArenaDeepGreen,
                contentColor = ArenaPureWhite
            ) {
                Text(
                    text = if (account != null) "Panel" else "Open",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }
}
