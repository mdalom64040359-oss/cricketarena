package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.ArenaLocalizedStrings
import com.example.ui.i18n.LocalArenaStrings
import com.example.ui.navigation.ArenaBottomNavItems
import com.example.ui.navigation.ArenaDestination
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent

private fun localizedNavLabel(destination: ArenaDestination, strings: ArenaLocalizedStrings, fallback: String): String {
    return when (destination) {
        ArenaDestination.Home -> strings.navHome
        ArenaDestination.Matches -> strings.navMatches
        ArenaDestination.Teams -> strings.navTeams
        ArenaDestination.Tournaments -> strings.navTournaments
        ArenaDestination.Statistics -> strings.navStats
        else -> fallback
    }
}

@Composable
fun ArenaBottomNavigationBar(
    currentRoute: String?,
    onNavigate: (ArenaDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalArenaStrings.current
    NavigationBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 4.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        ArenaBottomNavItems.forEach { item ->
            val selected = currentRoute == item.destination.route
            val labelText = localizedNavLabel(item.destination, strings, item.label)
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.destination) },
                modifier = Modifier.testTag(item.testTag),
                icon = {
                    Icon(
                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = labelText,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = labelText,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ArenaPureWhite,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = ArenaDeepGreen,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
fun ArenaSideNavigationRail(
    currentRoute: String?,
    onNavigate: (ArenaDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalArenaStrings.current
    NavigationRail(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp)
            .background(MaterialTheme.colorScheme.surface),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Spacer(modifier = Modifier.height(20.dp))
        ArenaBottomNavItems.forEach { item ->
            val selected = currentRoute == item.destination.route
            val labelText = localizedNavLabel(item.destination, strings, item.label)
            NavigationRailItem(
                selected = selected,
                onClick = { onNavigate(item.destination) },
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .testTag("${item.testTag}_rail"),
                icon = {
                    Icon(
                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = labelText,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = labelText,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = ArenaPureWhite,
                    selectedTextColor = ArenaTurfAccent,
                    indicatorColor = ArenaDeepGreen,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}
