package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.TeamEntity
import com.example.data.local.entity.TournamentEntity
import com.example.data.repository.ArenaOverviewCounts
import com.example.data.repository.ArenaRepository
import com.example.data.sync.OfflineStorageStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

sealed interface DashboardUiState {
    data object Loading : DashboardUiState
    data class Ready(
        val counts: ArenaOverviewCounts,
        val liveMatches: List<MatchEntity>,
        val allMatches: List<MatchEntity>,
        val teams: List<TeamEntity>,
        val players: List<PlayerEntity>,
        val tournaments: List<TournamentEntity>,
        val storageStatus: OfflineStorageStatus
    ) : DashboardUiState
}

class DashboardViewModel(
    private val repository: ArenaRepository
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = combine(
        repository.observeOverviewCounts(),
        repository.observeLiveMatches(),
        repository.observeAllMatches(),
        repository.observeAllTeams(),
        repository.observeAllPlayers(),
        repository.observeAllTournaments()
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        DashboardUiState.Ready(
            counts = values[0] as ArenaOverviewCounts,
            liveMatches = values[1] as List<MatchEntity>,
            allMatches = values[2] as List<MatchEntity>,
            teams = values[3] as List<TeamEntity>,
            players = values[4] as List<PlayerEntity>,
            tournaments = values[5] as List<TournamentEntity>,
            storageStatus = repository.getOfflineStorageStatus()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState.Loading
    )

    class Factory(private val repository: ArenaRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
                return DashboardViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
