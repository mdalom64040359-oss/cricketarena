package com.example.ui.viewmodel

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.FavouriteType
import com.example.data.local.entity.UserAccountEntity
import com.example.data.local.entity.UserFavouriteEntity
import com.example.data.local.entity.UserPersonalSettingsEntity
import com.example.data.repository.ActiveUserBundle
import com.example.data.repository.SyncAttemptResult
import com.example.data.repository.UserAccountRepository
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UserSessionUiState(
    val activeBundle: ActiveUserBundle? = null,
    val isOnline: Boolean = false
) {
    val isSignedIn: Boolean get() = activeBundle != null
    val account: UserAccountEntity? get() = activeBundle?.account
    val settings: UserPersonalSettingsEntity? get() = activeBundle?.settings
    val favourites: List<UserFavouriteEntity> get() = activeBundle?.favourites ?: emptyList()
}

class UserAccountViewModel(
    private val repository: UserAccountRepository,
    appContext: Context
) : ViewModel() {

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val isOnlineFlow = observeNetworkOnline(appContext).distinctUntilChanged()

    val uiState: StateFlow<UserSessionUiState> = combine(
        repository.observeActiveUserBundle(),
        isOnlineFlow
    ) { bundle, online ->
        UserSessionUiState(
            activeBundle = bundle,
            isOnline = online
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSessionUiState()
    )

    fun signUp(
        fullName: String,
        emailOrHandle: String,
        password: String,
        recoveryCode: String,
        cityOrPhone: String,
        bio: String,
        photoUri: String?,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.signUp(
                fullName = fullName,
                emailOrHandle = emailOrHandle,
                password = password,
                recoveryCode = recoveryCode,
                cityOrPhone = cityOrPhone,
                bio = bio,
                photoUri = photoUri
            ).onSuccess { created ->
                _events.emit("Account created! Your User ID: ${created.userId}")
                onSuccess()
            }.onFailure { err ->
                _events.emit(err.message ?: "Sign up failed.")
            }
        }
    }

    fun login(emailOrHandle: String, password: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.login(emailOrHandle, password)
                .onSuccess { acc ->
                    _events.emit("Welcome back, ${acc.fullName}")
                    onSuccess()
                }
                .onFailure { err ->
                    _events.emit(err.message ?: "Login failed.")
                }
        }
    }

    fun logout(onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.logout()
            _events.emit("Logged out safely.")
            onDone()
        }
    }

    fun resetPasswordWithRecovery(
        emailOrHandle: String,
        recoveryCode: String,
        newPassword: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.resetPasswordWithRecovery(emailOrHandle, recoveryCode, newPassword)
                .onSuccess {
                    _events.emit("Password reset successfully. You can now log in.")
                    onSuccess()
                }
                .onFailure { err ->
                    _events.emit(err.message ?: "Password reset failed.")
                }
        }
    }

    fun updateProfile(
        fullName: String,
        bio: String,
        cityOrPhone: String,
        photoUri: String?
    ) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.updateProfile(userId, fullName, bio, cityOrPhone, photoUri)
                .onSuccess { _events.emit("Profile updated.") }
                .onFailure { err -> _events.emit(err.message ?: "Update failed.") }
        }
    }

    fun updateSettings(transform: (UserPersonalSettingsEntity) -> UserPersonalSettingsEntity) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.updateSettings(userId, transform)
                .onFailure { err -> _events.emit(err.message ?: "Could not save settings.") }
        }
    }

    fun addFavourite(type: FavouriteType, key: String, displayName: String, subtitle: String = "") {
        val userId = uiState.value.account?.userId ?: run {
            viewModelScope.launch {
                _events.emit("Please sign in to save personal favourites.")
            }
            return
        }
        viewModelScope.launch {
            repository.addOrUpdateFavourite(userId, type, key, displayName, subtitle)
                .onSuccess { _events.emit("Added $displayName to favourites.") }
                .onFailure { err -> _events.emit(err.message ?: "Could not add favourite.") }
        }
    }

    fun toggleFavouriteAlert(favId: String, enabled: Boolean) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.toggleFavouriteMatchAlert(userId, favId, enabled)
        }
    }

    fun removeFavourite(favId: String) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.removeFavourite(userId, favId)
                .onSuccess { _events.emit("Removed from favourites.") }
        }
    }

    fun clearAllFavourites() {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.clearAllFavourites(userId)
                .onSuccess { _events.emit("Cleared your personal favourites.") }
        }
    }

    fun changePassword(currentPassword: String, newPassword: String, onSuccess: () -> Unit = {}) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.changePassword(userId, currentPassword, newPassword)
                .onSuccess {
                    _events.emit("Password updated securely.")
                    onSuccess()
                }
                .onFailure { err -> _events.emit(err.message ?: "Password change failed.") }
        }
    }

    fun deleteMyAccount(confirmPassword: String, onDeleted: () -> Unit = {}) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.deleteMyAccount(userId, confirmPassword)
                .onSuccess {
                    _events.emit("Your account and personal data were permanently deleted.")
                    onDeleted()
                }
                .onFailure { err -> _events.emit(err.message ?: "Account deletion failed.") }
        }
    }

    fun exportBackup(onReady: (String) -> Unit) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.exportPersonalBackupJson(userId)
                .onSuccess { json -> onReady(json) }
                .onFailure { err -> _events.emit(err.message ?: "Backup export failed.") }
        }
    }

    fun restoreBackup(rawJson: String) {
        val userId = uiState.value.account?.userId ?: return
        viewModelScope.launch {
            repository.restorePersonalBackupJson(userId, rawJson)
                .onSuccess { count ->
                    _events.emit("Backup restored cleanly ($count favourites restored).")
                }
                .onFailure { err ->
                    _events.emit("Restore failed: ${err.message ?: "Invalid backup"}")
                }
        }
    }

    fun triggerSyncCheck() {
        val userId = uiState.value.account?.userId ?: return
        val online = uiState.value.isOnline
        viewModelScope.launch {
            when (val res = repository.attemptSyncWhenOnline(userId, online)) {
                is SyncAttemptResult.OfflineQueued -> {
                    _events.emit("Offline Mode: personal changes saved locally and queued for sync.")
                }
                is SyncAttemptResult.CloudNotConfigured -> {
                    _events.emit("Internet connected, ${res.pendingCount} local item(s) ready. Cloud sync is optional and not yet linked.")
                }
                is SyncAttemptResult.Synced -> {
                    _events.emit("Synced ${res.count} items safely.")
                }
            }
        }
    }

    private fun observeNetworkOnline(context: Context) = callbackFlow {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm == null) {
            trySend(false)
            close()
            return@callbackFlow
        }

        fun checkNow(): Boolean {
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }

        trySend(checkNow())

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(checkNow())
            }
            override fun onLost(network: Network) {
                trySend(checkNow())
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        cm.registerNetworkCallback(request, callback)
        awaitClose { cm.unregisterNetworkCallback(callback) }
    }

    class Factory(
        private val repository: UserAccountRepository,
        private val context: Context
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(UserAccountViewModel::class.java)) {
                return UserAccountViewModel(repository, context.applicationContext) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
