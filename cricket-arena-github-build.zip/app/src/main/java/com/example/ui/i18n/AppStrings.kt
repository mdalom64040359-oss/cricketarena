package com.example.ui.i18n

import androidx.compose.runtime.compositionLocalOf

data class ArenaLocalizedStrings(
    val languageCode: String,
    val navHome: String,
    val navMatches: String,
    val navTeams: String,
    val navTournaments: String,
    val navStats: String,
    val personalPanelTitle: String,
    val signInTitle: String,
    val signUpTitle: String,
    val forgotPasswordTitle: String,
    val myProfile: String,
    val editProfile: String,
    val changePhoto: String,
    val appSettings: String,
    val languageSettings: String,
    val notificationSettings: String,
    val favouriteTeams: String,
    val favouritePlayers: String,
    val favouriteLeagues: String,
    val favouriteMatches: String,
    val matchNotifications: String,
    val mySavedData: String,
    val backupRestore: String,
    val privacySettings: String,
    val changePassword: String,
    val deleteMyAccount: String,
    val logout: String
)

val EnglishArenaStrings = ArenaLocalizedStrings(
    languageCode = "en",
    navHome = "Home",
    navMatches = "Matches",
    navTeams = "Teams",
    navTournaments = "Tourneys",
    navStats = "Stats",
    personalPanelTitle = "Personal Control Panel",
    signInTitle = "Login",
    signUpTitle = "Sign Up",
    forgotPasswordTitle = "Forgot Password",
    myProfile = "My Profile",
    editProfile = "Edit Profile",
    changePhoto = "Profile Picture Change",
    appSettings = "App Settings",
    languageSettings = "Language Settings",
    notificationSettings = "Notification Settings",
    favouriteTeams = "Favourite Teams",
    favouritePlayers = "Favourite Players",
    favouriteLeagues = "Favourite Leagues",
    favouriteMatches = "Favourite Matches",
    matchNotifications = "Match Notifications",
    mySavedData = "My Saved Data",
    backupRestore = "Backup & Restore",
    privacySettings = "Privacy Settings",
    changePassword = "Change Password",
    deleteMyAccount = "Delete My Account",
    logout = "Logout"
)

val BanglaArenaStrings = ArenaLocalizedStrings(
    languageCode = "bn",
    navHome = "হোম",
    navMatches = "ম্যাচ",
    navTeams = "দল",
    navTournaments = "টুর্নামেন্ট",
    navStats = "পরিসংখ্যান",
    personalPanelTitle = "পার্সোনাল কন্ট্রোল প্যানেল",
    signInTitle = "লগইন",
    signUpTitle = "সাইন আপ",
    forgotPasswordTitle = "পাসওয়ার্ড ভুলে গেছেন",
    myProfile = "আমার প্রোফাইল",
    editProfile = "প্রোফাইল সম্পাদনা",
    changePhoto = "প্রোফাইল ছবি পরিবর্তন",
    appSettings = "অ্যাপ সেটিংস",
    languageSettings = "ভাষা সেটিংস (বাংলা / English)",
    notificationSettings = "নোটিফিকেশন সেটিংস",
    favouriteTeams = "পছন্দের দল",
    favouritePlayers = "পছন্দের খেলোয়াড়",
    favouriteLeagues = "পছন্দের লিগ",
    favouriteMatches = "পছন্দের ম্যাচ",
    matchNotifications = "ম্যাচ নোটিফিকেশন",
    mySavedData = "আমার সংরক্ষিত ডেটা",
    backupRestore = "ব্যাকআপ ও রিস্টোর",
    privacySettings = "প্রাইভেসি সেটিংস",
    changePassword = "পাসওয়ার্ড পরিবর্তন",
    deleteMyAccount = "আমার অ্যাকাউন্ট মুছুন",
    logout = "লগআউট"
)

fun stringsForLanguage(code: String): ArenaLocalizedStrings =
    if (code == "bn") BanglaArenaStrings else EnglishArenaStrings

val LocalArenaStrings = compositionLocalOf { EnglishArenaStrings }
