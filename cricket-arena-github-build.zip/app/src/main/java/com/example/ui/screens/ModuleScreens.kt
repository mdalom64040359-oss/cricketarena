package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudSync
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SportsCricket
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.navigation.ArenaDestination
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent
import com.example.ui.viewmodel.DashboardUiState

@Composable
fun MatchesFoundationScreen(
    uiState: DashboardUiState,
    onCreateMatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val count = (uiState as? DashboardUiState.Ready)?.counts?.matchCount ?: 0
    FoundationModuleBody(
        title = "Matches & Live Scoring",
        subtitle = "Ball-by-ball live scoring, innings management, and match archive.",
        icon = Icons.Rounded.SportsCricket,
        countLabel = "$count Matches Stored Locally",
        plannedFeatures = listOf(
            "Live ball-by-ball scoring console (runs, wickets, wides, no-balls, byes)",
            "Support for T10, T20, ODI, Test & Custom Overs",
            "Automatic run rate, strike rate & partnership tracking",
            "100% offline SQLite persistence during live matches"
        ),
        primaryActionLabel = "Open Match Setup",
        onPrimaryAction = onCreateMatch,
        modifier = modifier
    )
}

@Composable
fun TeamsFoundationScreen(
    uiState: DashboardUiState,
    onOpenPlayers: () -> Unit,
    modifier: Modifier = Modifier
) {
    val count = (uiState as? DashboardUiState.Ready)?.counts?.teamCount ?: 0
    FoundationModuleBody(
        title = "Team Management",
        subtitle = "Build clubs, franchise squads, and tournament rosters.",
        icon = Icons.Rounded.Groups,
        countLabel = "$count Teams Stored Locally",
        plannedFeatures = listOf(
            "Create & edit teams with custom short codes & home grounds",
            "Assign captains, wicketkeepers & playing XI lineups",
            "Reusable squads across friendly matches and tournaments"
        ),
        primaryActionLabel = "View Players Module",
        onPrimaryAction = onOpenPlayers,
        modifier = modifier
    )
}

@Composable
fun TournamentsFoundationScreen(
    uiState: DashboardUiState,
    onOpenCreateTournament: () -> Unit,
    modifier: Modifier = Modifier
) {
    val count = (uiState as? DashboardUiState.Ready)?.counts?.tournamentCount ?: 0
    FoundationModuleBody(
        title = "Tournaments & Points Tables",
        subtitle = "Scalable leagues for 20, 24, 32, 40, 50 or more teams.",
        icon = Icons.Rounded.EmojiEvents,
        countLabel = "$count Tournaments Stored Locally",
        plannedFeatures = listOf(
            "Group stage, round-robin & knockout bracket fixtures",
            "Automated standings & Net Run Rate (NRR) engine",
            "Built for large 20 to 50+ team local and regional tournaments"
        ),
        primaryActionLabel = "Open Tournament Setup",
        onPrimaryAction = onOpenCreateTournament,
        modifier = modifier
    )
}

@Composable
fun StatisticsFoundationScreen(
    directoryState: com.example.ui.viewmodel.PlayerDirectoryUiState,
    onSelectFormat: (com.example.data.local.entity.CareerFormatScope) -> Unit,
    onOpenPlayers: () -> Unit,
    onOpenComparison: () -> Unit,
    onOpenPlayerProfile: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onOpenPlayers,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
            ) {
                Text("Players (${directoryState.players.size})", maxLines = 1)
            }

            androidx.compose.material3.OutlinedButton(
                onClick = onOpenComparison,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
            ) {
                Text("Compare Players", maxLines = 1)
            }
        }

        CareerRecordsContent(
            directoryState = directoryState,
            onSelectFormat = onSelectFormat,
            onOpenPlayerProfile = onOpenPlayerProfile,
            modifier = Modifier.weight(1f)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecondaryFoundationScreen(
    destination: ArenaDestination,
    uiState: DashboardUiState,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val (icon, subtitle, countLabel, plannedFeatures) = when (destination) {
        ArenaDestination.CreateMatch -> Quadruple(
            Icons.Rounded.AddCircle,
            "Configure teams, overs, toss, and launch live ball-by-ball scoring.",
            "T10 • T20 • ODI • Test • Custom Overs",
            listOf(
                "Select Team A & Team B from your saved squads",
                "Choose T10, T20, ODI, Test, or enter custom overs",
                "Record toss decision and opening batters/bowler"
            )
        )

        ArenaDestination.CreateTournament -> Quadruple(
            Icons.Rounded.EmojiEvents,
            "Set up league groups, knockout stages, and fixtures for 20 to 50+ teams.",
            "Supports 20, 24, 32, 40, 50+ Teams",
            listOf(
                "Configure tournament name, format & overs per match",
                "Generate round-robin or group fixtures automatically",
                "Track points tables with live Net Run Rate (NRR)"
            )
        )

        ArenaDestination.Players -> {
            val playerCount = (uiState as? DashboardUiState.Ready)?.counts?.playerCount ?: 0
            Quadruple(
                Icons.Rounded.Person,
                "Player profiles, batting/bowling styles, and career statistics.",
                "$playerCount Players Stored Locally",
                listOf(
                    "Register batters, bowlers, all-rounders & wicketkeepers",
                    "Link players to one or more teams",
                    "Automatic career stat aggregation from every scored ball"
                )
            )
        }

        else -> {
            val ready = uiState as? DashboardUiState.Ready
            val totalRecords = if (ready != null) {
                ready.counts.teamCount + ready.counts.playerCount +
                    ready.counts.matchCount + ready.counts.tournamentCount
            } else 0
            Quadruple(
                Icons.Rounded.Storage,
                "On-device SQLite storage active. Works 100% offline with zero network dependency.",
                "$totalRecords Total Local Records",
                listOf(
                    "Local Room SQLite database initialized and active",
                    "All entities carry sync-status metadata for future optional cloud sync",
                    "JSON Backup & Restore module ready to be enabled in upcoming steps"
                )
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = destination.title,
                    style = MaterialTheme.typography.titleLarge
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("secondary_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Navigate back"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
            )
        )

        FoundationModuleBody(
            title = destination.title,
            subtitle = subtitle,
            icon = icon,
            countLabel = countLabel,
            plannedFeatures = plannedFeatures,
            primaryActionLabel = "Return to Dashboard",
            onPrimaryAction = onNavigateBack,
            showSyncCard = destination == ArenaDestination.StorageBackup,
            modifier = Modifier.weight(1f)
        )
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

@Composable
private fun FoundationModuleBody(
    title: String,
    subtitle: String,
    icon: ImageVector,
    countLabel: String,
    plannedFeatures: List<String>,
    primaryActionLabel: String,
    onPrimaryAction: () -> Unit,
    showSyncCard: Boolean = false,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = ArenaDeepGreen),
                    border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(ArenaPureWhite.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = title,
                                    tint = ArenaPureWhite,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(50),
                                color = ArenaTurfAccent.copy(alpha = 0.22f)
                            ) {
                                Text(
                                    text = countLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ArenaPureWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }

                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineMedium,
                            color = ArenaPureWhite
                        )
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyLarge,
                            color = ArenaPureWhite.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Module Foundation Ready",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "The navigation route and offline local database schema for this module are ready. The interactive tools below will be built in the next steps:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        plannedFeatures.forEach { feature ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = ArenaTurfAccent,
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(18.dp)
                                )
                                Text(
                                    text = feature,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = onPrimaryAction,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("module_primary_action_button")
                        ) {
                            Text(
                                text = primaryActionLabel,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            if (showSyncCard) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudSync,
                                contentDescription = "Cloud Sync Readiness",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "Future Cloud Sync Interface",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Currently running in Local-Only Offline Mode. No internet connection or API key required.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
