package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.entity.FavouriteType
import com.example.data.local.entity.UserAccountEntity
import com.example.data.local.entity.UserFavouriteEntity
import com.example.data.local.entity.UserPersonalSettingsEntity
import com.example.data.sync.SyncStatus
import com.example.ui.components.AddFavouriteDialog
import com.example.ui.components.ChangePasswordDialog
import com.example.ui.components.DeleteMyAccountDialog
import com.example.ui.components.EditPersonalProfileDialog
import com.example.ui.components.PersonalBackupDialog
import com.example.ui.components.PlayerAvatar
import com.example.ui.i18n.LocalArenaStrings
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent
import com.example.ui.viewmodel.DashboardUiState
import com.example.ui.viewmodel.UserAccountViewModel
import com.example.ui.viewmodel.UserSessionUiState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PersonalControlPanelScreen(
    userState: UserSessionUiState,
    dashboardState: DashboardUiState,
    userAccountViewModel: UserAccountViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val strings = LocalArenaStrings.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        userAccountViewModel.events.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val account = userState.account
    val settings = userState.settings

    if (account == null || settings == null) {
        UserAuthScreen(
            snackbarHostState = snackbarHostState,
            onLogin = { handle, pwd -> userAccountViewModel.login(handle, pwd) },
            onSignUp = { name, handle, pwd, rec, city, bio, photo ->
                userAccountViewModel.signUp(name, handle, pwd, rec, city, bio, photo)
            },
            onResetPassword = { handle, rec, newPwd ->
                userAccountViewModel.resetPasswordWithRecovery(handle, rec, newPwd)
            },
            onNavigateBack = onNavigateBack,
            modifier = modifier
        )
        return
    }

    BackHandler { onNavigateBack() }

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var showClearFavouritesConfirm by remember { mutableStateOf(false) }
    var addFavInitialType by remember { mutableStateOf<FavouriteType?>(null) }
    var selectedFavTab by remember { mutableStateOf<FavouriteType?>(null) } // null = All

    val quickPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userAccountViewModel.updateProfile(
                fullName = account.fullName,
                bio = account.bio,
                cityOrPhone = account.cityOrPhone,
                photoUri = uri.toString()
            )
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        userAccountViewModel.updateSettings { it.copy(notificationsEnabled = granted) }
        scope.launch {
            snackbarHostState.showSnackbar(
                if (granted) {
                    "Match notifications enabled."
                } else {
                    "Notification permission was denied. You can allow it later in Android Settings."
                }
            )
        }
    }

    val onMasterNotificationToggle: (Boolean) -> Unit = { enable ->
        if (!enable) {
            userAccountViewModel.updateSettings { it.copy(notificationsEnabled = false) }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                userAccountViewModel.updateSettings { it.copy(notificationsEnabled = true) }
            } else {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            userAccountViewModel.updateSettings { it.copy(notificationsEnabled = true) }
        }
    }

    val readyDashboard = dashboardState as? DashboardUiState.Ready
    val pendingSyncCount = userState.favourites.count { it.syncStatus == SyncStatus.PENDING_SYNC.name } +
        (if (account.syncStatus == SyncStatus.PENDING_SYNC.name) 1 else 0) +
        (if (settings.syncStatus == SyncStatus.PENDING_SYNC.name) 1 else 0)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.personalPanelTitle,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("personal_panel_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { userAccountViewModel.logout() },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("personal_panel_topbar_logout")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.Logout,
                            contentDescription = strings.logout
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 820.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. My Profile, Edit Profile & Profile Picture Change
                item {
                    MyProfileHeroCard(
                        account = account,
                        onEditProfile = { showEditProfileDialog = true },
                        onChangePhoto = {
                            quickPhotoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onCopyUserId = {
                            clipboard.setText(AnnotatedString(account.userId))
                            scope.launch {
                                snackbarHostState.showSnackbar("Copied User ID: ${account.userId}")
                            }
                        }
                    )
                }

                // 2. App Settings & Language Settings (বাংলা ও English)
                item {
                    ControlPanelSectionCard(
                        title = "${strings.appSettings} & ${strings.languageSettings}",
                        icon = Icons.Rounded.Settings
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Language,
                                contentDescription = null,
                                tint = ArenaTurfAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = strings.languageSettings,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilterChip(
                                selected = settings.languageCode == "en",
                                onClick = {
                                    userAccountViewModel.updateSettings { it.copy(languageCode = "en") }
                                },
                                label = { Text("English") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ArenaDeepGreen,
                                    selectedLabelColor = ArenaPureWhite
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("lang_chip_en")
                            )
                            FilterChip(
                                selected = settings.languageCode == "bn",
                                onClick = {
                                    userAccountViewModel.updateSettings { it.copy(languageCode = "bn") }
                                },
                                label = { Text("বাংলা (Bangla)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ArenaDeepGreen,
                                    selectedLabelColor = ArenaPureWhite
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("lang_chip_bn")
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                        Text(
                            text = if (strings.languageCode == "bn") "থিম (Theme Mode)" else "Theme Mode",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("SYSTEM" to "System", "DARK" to "Dark", "LIGHT" to "Light").forEach { (modeKey, label) ->
                                FilterChip(
                                    selected = settings.themeMode == modeKey,
                                    onClick = {
                                        userAccountViewModel.updateSettings { it.copy(themeMode = modeKey) }
                                    },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ArenaDeepGreen,
                                        selectedLabelColor = ArenaPureWhite
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .minimumInteractiveComponentSize()
                                        .testTag("theme_chip_${modeKey.lowercase()}")
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                        SettingToggleRow(
                            title = "Auto-Sync When Internet Returns",
                            subtitle = if (userState.isOnline) {
                                "Connected • $pendingSyncCount personal change(s) ready"
                            } else {
                                "Offline Mode • Changes saved safely on device"
                            },
                            checked = settings.autoSyncWhenOnline,
                            onCheckedChange = { enabled ->
                                userAccountViewModel.updateSettings { it.copy(autoSyncWhenOnline = enabled) }
                            },
                            testTag = "switch_auto_sync"
                        )

                        OutlinedButton(
                            onClick = { userAccountViewModel.triggerSyncCheck() },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("sync_check_button")
                        ) {
                            Icon(
                                imageVector = if (userState.isOnline) Icons.Rounded.Sync else Icons.Rounded.CloudOff,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (userState.isOnline) "Check Cloud Sync Readiness" else "Working Offline (Local Ready)"
                            )
                        }
                    }
                }

                // 3. Notification Settings & Match Notifications
                item {
                    ControlPanelSectionCard(
                        title = "${strings.notificationSettings} & ${strings.matchNotifications}",
                        icon = Icons.Rounded.NotificationsActive
                    ) {
                        SettingToggleRow(
                            title = strings.notificationSettings,
                            subtitle = "Enable alerts for your favourite teams, players, leagues & matches",
                            checked = settings.notificationsEnabled,
                            onCheckedChange = onMasterNotificationToggle,
                            testTag = "switch_notifications_master"
                        )

                        SettingToggleRow(
                            title = strings.matchNotifications,
                            subtitle = "Alert when your favourite teams or players have upcoming/live matches",
                            checked = settings.matchStartAlerts,
                            enabled = settings.notificationsEnabled,
                            onCheckedChange = { v ->
                                userAccountViewModel.updateSettings { it.copy(matchStartAlerts = v) }
                            },
                            testTag = "switch_match_start_alerts"
                        )

                        SettingToggleRow(
                            title = "Wicket & Key Turning-Point Alerts",
                            subtitle = "Instant match moment updates when scoring/sync updates arrive",
                            checked = settings.wicketAlerts,
                            enabled = settings.notificationsEnabled,
                            onCheckedChange = { v ->
                                userAccountViewModel.updateSettings { it.copy(wicketAlerts = v) }
                            }
                        )

                        SettingToggleRow(
                            title = "Milestone Alerts (50s, 100s, 5W)",
                            subtitle = "Celebrate milestones of your favourite players",
                            checked = settings.milestoneAlerts,
                            enabled = settings.notificationsEnabled,
                            onCheckedChange = { v ->
                                userAccountViewModel.updateSettings { it.copy(milestoneAlerts = v) }
                            }
                        )
                    }
                }

                // 4. Favourites: Favourite Teams, Players, Leagues, Matches
                item {
                    FavouritesControlCard(
                        favourites = userState.favourites,
                        selectedTab = selectedFavTab,
                        onSelectTab = { selectedFavTab = it },
                        onOpenAddDialog = { type -> addFavInitialType = type },
                        onToggleAlert = { favId, enabled ->
                            userAccountViewModel.toggleFavouriteAlert(favId, enabled)
                        },
                        onRemove = { favId ->
                            userAccountViewModel.removeFavourite(favId)
                        }
                    )
                }

                // 5. My Saved Data & Backup & Restore
                item {
                    ControlPanelSectionCard(
                        title = "${strings.mySavedData} & ${strings.backupRestore}",
                        icon = Icons.Rounded.Storage
                    ) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            SavedDataChip("My Favourites", userState.favourites.size.toString())
                            SavedDataChip("Teams", (readyDashboard?.counts?.teamCount ?: 0).toString())
                            SavedDataChip("Players", (readyDashboard?.counts?.playerCount ?: 0).toString())
                            SavedDataChip("Matches", (readyDashboard?.counts?.matchCount ?: 0).toString())
                            SavedDataChip("Tournaments", (readyDashboard?.counts?.tournamentCount ?: 0).toString())
                            SavedDataChip("Sync Pending", pendingSyncCount.toString())
                        }

                        Button(
                            onClick = { showBackupDialog = true },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ArenaDeepGreen,
                                contentColor = ArenaPureWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("open_personal_backup_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Backup,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.backupRestore)
                        }
                    }
                }

                // 6. Privacy Settings
                item {
                    ControlPanelSectionCard(
                        title = strings.privacySettings,
                        icon = Icons.Rounded.PrivacyTip
                    ) {
                        SettingToggleRow(
                            title = "Private Personal Profile",
                            subtitle = "Keep your profile, bio, and favourites strictly private to your account",
                            checked = settings.profilePrivate,
                            onCheckedChange = { v ->
                                userAccountViewModel.updateSettings { it.copy(profilePrivate = v) }
                            },
                            testTag = "switch_private_profile"
                        )

                        SettingToggleRow(
                            title = "Optional Diagnostics Opt-In",
                            subtitle = "Off by default; never shares personal data without your consent",
                            checked = settings.analyticsOptIn,
                            onCheckedChange = { v ->
                                userAccountViewModel.updateSettings { it.copy(analyticsOptIn = v) }
                            }
                        )

                        if (userState.favourites.isNotEmpty()) {
                            OutlinedButton(
                                onClick = { showClearFavouritesConfirm = true },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear My Favourites (${userState.favourites.size})")
                            }
                        }
                    }
                }

                // 7. Security Actions: Change Password, Delete My Account, Logout
                item {
                    ControlPanelSectionCard(
                        title = "Account Security",
                        icon = Icons.Rounded.Lock
                    ) {
                        OutlinedButton(
                            onClick = { showChangePasswordDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("change_password_button")
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.changePassword)
                        }

                        Button(
                            onClick = { userAccountViewModel.logout() },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ArenaDeepGreen,
                                contentColor = ArenaPureWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Logout,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.logout)
                        }

                        OutlinedButton(
                            onClick = { showDeleteAccountDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("delete_my_account_button")
                        ) {
                            Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.deleteMyAccount)
                        }
                    }
                }
            }
        }
    }

    if (showEditProfileDialog) {
        EditPersonalProfileDialog(
            account = account,
            onDismiss = { showEditProfileDialog = false },
            onSave = { name, bio, cityOrPhone, photoUri ->
                userAccountViewModel.updateProfile(name, bio, cityOrPhone, photoUri)
                showEditProfileDialog = false
            }
        )
    }

    if (showChangePasswordDialog) {
        ChangePasswordDialog(
            onDismiss = { showChangePasswordDialog = false },
            onSubmit = { currentPwd, newPwd ->
                userAccountViewModel.changePassword(currentPwd, newPwd) {
                    showChangePasswordDialog = false
                }
            }
        )
    }

    val pendingAddType = addFavInitialType
    if (pendingAddType != null) {
        AddFavouriteDialog(
            initialType = pendingAddType,
            teams = readyDashboard?.teams ?: emptyList(),
            players = readyDashboard?.players ?: emptyList(),
            matches = readyDashboard?.allMatches ?: emptyList(),
            onDismiss = { addFavInitialType = null },
            onAddFavourite = { type, key, name, sub ->
                userAccountViewModel.addFavourite(type, key, name, sub)
            }
        )
    }

    if (showBackupDialog) {
        PersonalBackupDialog(
            userId = account.userId,
            onExportJson = { cb -> userAccountViewModel.exportBackup(cb) },
            onRestoreJson = { json -> userAccountViewModel.restoreBackup(json) },
            onDismiss = { showBackupDialog = false }
        )
    }

    if (showDeleteAccountDialog) {
        DeleteMyAccountDialog(
            userId = account.userId,
            onDismiss = { showDeleteAccountDialog = false },
            onConfirmDelete = { pwd ->
                userAccountViewModel.deleteMyAccount(pwd) {
                    showDeleteAccountDialog = false
                }
            }
        )
    }

    if (showClearFavouritesConfirm) {
        AlertDialog(
            onDismissRequest = { showClearFavouritesConfirm = false },
            title = { Text("Clear Personal Favourites?") },
            text = { Text("This removes all saved teams, players, leagues, and matches from your personal favourites list.") },
            confirmButton = {
                Button(
                    onClick = {
                        userAccountViewModel.clearAllFavourites()
                        showClearFavouritesConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearFavouritesConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun MyProfileHeroCard(
    account: UserAccountEntity,
    onEditProfile: () -> Unit,
    onChangePhoto: () -> Unit,
    onCopyUserId: () -> Unit
) {
    val strings = LocalArenaStrings.current

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ArenaDeepGreen),
        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("my_profile_card")
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                PlayerAvatar(
                    fullName = account.fullName,
                    photoUri = account.photoUri,
                    size = 70.dp
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = account.fullName,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = ArenaPureWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = account.emailOrHandle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArenaPureWhite.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Surface(
                        onClick = onCopyUserId,
                        shape = RoundedCornerShape(50),
                        color = ArenaTurfAccent.copy(alpha = 0.22f),
                        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.5f)),
                        modifier = Modifier.testTag("user_id_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Badge,
                                contentDescription = null,
                                tint = ArenaPureWhite,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "ID: ${account.userId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ArenaPureWhite
                            )
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = "Copy User ID",
                                tint = ArenaPureWhite.copy(alpha = 0.8f),
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }

            if (account.cityOrPhone.isNotBlank() || account.bio.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = ArenaPureWhite.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (account.cityOrPhone.isNotBlank()) {
                            Text(
                                text = account.cityOrPhone,
                                style = MaterialTheme.typography.labelMedium,
                                color = ArenaTurfAccent
                            )
                        }
                        if (account.bio.isNotBlank()) {
                            Text(
                                text = account.bio,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ArenaPureWhite.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onEditProfile,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ArenaPureWhite,
                        contentColor = ArenaDeepGreen
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("edit_profile_button")
                ) {
                    Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.editProfile, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }

                OutlinedButton(
                    onClick = onChangePhoto,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ArenaPureWhite.copy(alpha = 0.7f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ArenaPureWhite),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("change_photo_button")
                ) {
                    Icon(Icons.Rounded.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.changePhoto, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FavouritesControlCard(
    favourites: List<UserFavouriteEntity>,
    selectedTab: FavouriteType?,
    onSelectTab: (FavouriteType?) -> Unit,
    onOpenAddDialog: (FavouriteType) -> Unit,
    onToggleAlert: (favId: String, enabled: Boolean) -> Unit,
    onRemove: (favId: String) -> Unit
) {
    val strings = LocalArenaStrings.current
    val filtered = if (selectedTab == null) {
        favourites
    } else {
        favourites.filter { it.itemType == selectedTab.name }
    }

    ControlPanelSectionCard(
        title = "Personal Favourites",
        icon = Icons.Rounded.Favorite
    ) {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedTab == null,
                onClick = { onSelectTab(null) },
                label = { Text("All (${favourites.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ArenaDeepGreen,
                    selectedLabelColor = ArenaPureWhite
                )
            )
            FavouriteType.entries.forEach { type ->
                val count = favourites.count { it.itemType == type.name }
                val label = when (type) {
                    FavouriteType.TEAM -> "${strings.favouriteTeams} ($count)"
                    FavouriteType.PLAYER -> "${strings.favouritePlayers} ($count)"
                    FavouriteType.LEAGUE -> "${strings.favouriteLeagues} ($count)"
                    FavouriteType.MATCH -> "${strings.favouriteMatches} ($count)"
                }
                FilterChip(
                    selected = selectedTab == type,
                    onClick = { onSelectTab(type) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ArenaDeepGreen,
                        selectedLabelColor = ArenaPureWhite
                    ),
                    modifier = Modifier.testTag("fav_tab_${type.name.lowercase()}")
                )
            }
        }

        // Quick-add buttons for Teams, Players, Leagues, Matches
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { onOpenAddDialog(selectedTab ?: FavouriteType.TEAM) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("add_favourite_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Favourite Team / Player / League / Match")
            }
        }

        if (filtered.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "No saved favourites in this category yet. Tap above to add your favourites and customize match alerts.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(14.dp)
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                filtered.forEach { fav ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = fav.displayName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = buildString {
                                        append(fav.itemType)
                                        if (fav.subtitle.isNotBlank()) {
                                            append(" • ${fav.subtitle}")
                                        }
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            IconButton(
                                onClick = { onToggleAlert(fav.id, !fav.matchAlertsEnabled) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = if (fav.matchAlertsEnabled) {
                                        Icons.Rounded.NotificationsActive
                                    } else {
                                        Icons.Rounded.NotificationsOff
                                    },
                                    contentDescription = "Toggle match notifications",
                                    tint = if (fav.matchAlertsEnabled) {
                                        ArenaTurfAccent
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }

                            IconButton(
                                onClick = { onRemove(fav.id) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = "Remove favourite",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlPanelSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            content()
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true,
    testTag: String? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = if (enabled) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                }
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
private fun SavedDataChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
