package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Addchart
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PostAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.CareerScopeType
import com.example.data.local.entity.MajorLeagueCatalog
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.PlayerMatchContributionEntity
import com.example.domain.CareerStatsCalculator
import com.example.domain.NOT_AVAILABLE
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPitchBlack
import com.example.ui.theme.ArenaPureWhite
import com.example.ui.theme.ArenaTurfAccent

/**
 * Reusable PlayerProfile component displaying a player's role, biography,
 * team & career background, format/league filters, and structured sections for
 * Batting, Bowling, Fielding, Personal Records, and Match Ledger.
 */
@Composable
fun PlayerProfile(
    player: PlayerEntity,
    stats: List<PlayerCareerStatEntity>,
    matchLedger: List<PlayerMatchContributionEntity>,
    selectedFormat: CareerFormatScope,
    selectedLeagueKey: String?,
    onSelectFormat: (CareerFormatScope) -> Unit,
    onSelectLeague: (String?) -> Unit,
    onEditProfile: () -> Unit,
    onEditStats: () -> Unit,
    onLogMatch: () -> Unit,
    onCompare: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formatTabs = listOf(
        CareerFormatScope.ALL_FORMAT,
        CareerFormatScope.TEST,
        CareerFormatScope.ODI,
        CareerFormatScope.T20I,
        CareerFormatScope.T20_LEAGUE,
        CareerFormatScope.DOMESTIC
    )

    val leagueStats = stats.filter { it.scopeType == CareerScopeType.LEAGUE.name }
    val activeStat = if (selectedLeagueKey != null) {
        leagueStats.find { it.scopeKey == selectedLeagueKey }
    } else {
        CareerStatsCalculator.resolveFormatStat(stats, selectedFormat)
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("player_profile_component")
    ) {
        val metricColumns = if (maxWidth >= 600.dp) 4 else 2

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 960.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Hero Header (Photo, Role, Batting/Bowling Styles, Actions)
            item {
                PlayerHeroHeader(
                    player = player,
                    onEditProfile = onEditProfile,
                    onEditStats = onEditStats,
                    onLogMatch = onLogMatch,
                    onCompare = onCompare
                )
            }

            // 2. Biography & Career Background Section
            item {
                PlayerBiographySection(player = player)
            }

            // 3. Format Career Tabs (Test, ODI, T20I, T20 League, Domestic, All Format)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Format Career Breakdown",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    val selectedIdx = formatTabs.indexOf(selectedFormat).coerceAtLeast(0)
                    ScrollableTabRow(
                        selectedTabIndex = if (selectedLeagueKey == null) selectedIdx else -1,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = ArenaTurfAccent,
                        edgePadding = 4.dp
                    ) {
                        formatTabs.forEach { fmt ->
                            val active = selectedLeagueKey == null && selectedFormat == fmt
                            Tab(
                                selected = active,
                                onClick = {
                                    onSelectLeague(null)
                                    onSelectFormat(fmt)
                                },
                                text = {
                                    Text(
                                        text = fmt.displayName.removeSuffix(" Career"),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                modifier = Modifier.testTag("format_tab_${fmt.key}")
                            )
                        }
                    }
                }
            }

            // 4. Tournament & League Selector
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Tournament & League Statistics",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    val customLeagues = leagueStats.filter { stat ->
                        MajorLeagueCatalog.leagues.none { it.key == stat.scopeKey }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(MajorLeagueCatalog.leagues) { lg ->
                            val hasData = leagueStats.any { it.scopeKey == lg.key }
                            val selected = selectedLeagueKey == lg.key
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    onSelectLeague(if (selected) null else lg.key)
                                },
                                label = {
                                    Text(if (hasData) "${lg.displayName} •" else lg.displayName)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ArenaDeepGreen,
                                    selectedLabelColor = ArenaPureWhite
                                )
                            )
                        }
                        items(customLeagues) { custom ->
                            val selected = selectedLeagueKey == custom.scopeKey
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    onSelectLeague(if (selected) null else custom.scopeKey)
                                },
                                label = { Text("${custom.scopeDisplayName} •") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ArenaDeepGreen,
                                    selectedLabelColor = ArenaPureWhite
                                )
                            )
                        }
                    }
                }
            }

            // 5. Data Provenance & Last Updated Banner
            item {
                val scopeHeading = selectedLeagueKey?.let { key ->
                    MajorLeagueCatalog.leagues.find { it.key == key }?.displayName
                        ?: leagueStats.find { it.scopeKey == key }?.scopeDisplayName
                        ?: key
                } ?: selectedFormat.displayName

                val (avail, total) = CareerStatsCalculator.countAvailableMetrics(activeStat)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = scopeHeading,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        TextButton(onClick = onEditStats) {
                            Text(if (activeStat == null) "+ Add Stats" else "Edit Stats")
                        }
                    }

                    DataProvenanceBanner(
                        sourceLabel = activeStat?.sourceLabel ?: "No Provider / Not Recorded",
                        lastUpdatedText = CareerStatsCalculator.formatTimestamp(activeStat?.lastUpdatedAt),
                        availableCount = avail,
                        totalCount = total
                    )
                }
            }

            // 6. Batting Metrics Section
            item {
                val batting = CareerStatsCalculator.computeBatting(activeStat)
                PlayerMetricsGridSection(
                    title = "Batting Career Statistics",
                    columns = metricColumns,
                    sectionTag = "player_profile_batting_section",
                    metrics = listOf(
                        "Matches" to batting.matchesText,
                        "Innings" to batting.inningsText,
                        "Runs" to batting.runsText,
                        "Balls Faced" to batting.ballsFacedText,
                        "Highest Score" to batting.highestScoreText,
                        "Batting Average" to batting.averageText,
                        "Strike Rate" to batting.strikeRateText,
                        "Fours (4s)" to batting.foursText,
                        "Sixes (6s)" to batting.sixesText,
                        "Centuries (100s)" to batting.hundredsText,
                        "Half-Centuries (50s)" to batting.fiftiesText,
                        "Double 100s (200s)" to batting.doubleHundredsText,
                        "Not Outs" to batting.notOutsText,
                        "Ducks (0s)" to batting.ducksText
                    )
                )
            }

            // 7. Bowling Metrics Section
            item {
                val bowling = CareerStatsCalculator.computeBowling(activeStat)
                PlayerMetricsGridSection(
                    title = "Bowling Career Statistics",
                    columns = metricColumns,
                    sectionTag = "player_profile_bowling_section",
                    metrics = listOf(
                        "Matches" to bowling.matchesText,
                        "Innings" to bowling.inningsText,
                        "Overs & Balls" to bowling.oversAndBallsText,
                        "Wickets" to bowling.wicketsText,
                        "Runs Conceded" to bowling.runsConcededText,
                        "Bowling Average" to bowling.averageText,
                        "Economy Rate" to bowling.economyText,
                        "Bowling Strike Rate" to bowling.strikeRateText,
                        "Best Bowling" to bowling.bestBowlingText,
                        "4 Wicket Hauls" to bowling.fourWicketsText,
                        "5 Wicket Hauls" to bowling.fiveWicketsText,
                        "10 Wicket Matches" to bowling.tenWicketsText
                    )
                )
            }

            // 8. Fielding Metrics Section
            item {
                val fielding = CareerStatsCalculator.computeFielding(activeStat)
                PlayerMetricsGridSection(
                    title = "Fielding Statistics",
                    columns = metricColumns,
                    sectionTag = "player_profile_fielding_section",
                    metrics = listOf(
                        "Catches" to fielding.catchesText,
                        "Run Outs" to fielding.runOutsText,
                        "Stumpings" to fielding.stumpingsText,
                        "Total Dismissals" to fielding.totalDismissalsText
                    )
                )
            }

            // 9. Personal Career Records
            item {
                val batting = CareerStatsCalculator.computeBatting(activeStat)
                val bowling = CareerStatsCalculator.computeBowling(activeStat)
                PlayerMetricsGridSection(
                    title = "Personal Career Records",
                    columns = metricColumns,
                    sectionTag = "player_profile_records_section",
                    metrics = listOf(
                        "Best Score" to batting.highestScoreText,
                        "Best Bowling" to bowling.bestBowlingText,
                        "Highest Partnership" to CareerStatsCalculator.formatIntOrNa(activeStat?.highestPartnership),
                        "Player of Match" to CareerStatsCalculator.formatIntOrNa(activeStat?.playerOfMatchAwards)
                    )
                )
            }

            // 10. Match Deduplication Ledger History
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Recorded Match Ledger (${matchLedger.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        if (matchLedger.isEmpty()) {
                            Text(
                                text = "No individual matches logged yet. Duplicate Match IDs are automatically blocked.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            matchLedger.take(10).forEach { entry ->
                                HorizontalDivider()
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${entry.matchTitle} (${entry.matchId})",
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                        Text(
                                            text = "${entry.scopeKey} • ${entry.sourceLabel}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = CareerStatsCalculator.formatTimestamp(entry.recordedAt),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlayerHeroHeader(
    player: PlayerEntity,
    onEditProfile: () -> Unit,
    onEditStats: () -> Unit,
    onLogMatch: () -> Unit,
    onCompare: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(ArenaDeepGreen, ArenaPitchBlack)
                    )
                )
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                PlayerAvatar(
                    fullName = player.fullName,
                    photoUri = player.photoUri,
                    size = 72.dp
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = player.fullName,
                        style = MaterialTheme.typography.headlineMedium,
                        color = ArenaPureWhite
                    )
                    Text(
                        text = "Country: ${player.country.ifBlank { NOT_AVAILABLE }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArenaPureWhite.copy(alpha = 0.85f)
                    )
                    Text(
                        text = "DOB: ${player.dateOfBirth.ifBlank { NOT_AVAILABLE }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArenaPureWhite.copy(alpha = 0.78f)
                    )
                }

                if (player.jerseyNumber != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ArenaTurfAccent.copy(alpha = 0.22f),
                        border = BorderStroke(1.dp, ArenaTurfAccent.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "#${player.jerseyNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = ArenaPureWhite,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HeroProfileChip("Role: ${player.role}")
                HeroProfileChip("Bat: ${player.battingHand.ifBlank { NOT_AVAILABLE }}")
                HeroProfileChip("Bowl: ${player.bowlingStyle.ifBlank { NOT_AVAILABLE }}")
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onEditStats,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ArenaPureWhite,
                        contentColor = ArenaPitchBlack
                    ),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.Addchart, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add/Edit Stats")
                }

                OutlinedButton(
                    onClick = onLogMatch,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ArenaPureWhite.copy(alpha = 0.7f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ArenaPureWhite),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.PostAdd, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Log Match")
                }

                OutlinedButton(
                    onClick = onEditProfile,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ArenaPureWhite.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ArenaPureWhite),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit Profile")
                }

                OutlinedButton(
                    onClick = onCompare,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ArenaTurfAccent),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ArenaPureWhite),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.AutoMirrored.Rounded.CompareArrows, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Compare")
                }
            }
        }
    }
}

@Composable
private fun PlayerBiographySection(player: PlayerEntity) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("player_profile_biography_section")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Biography & Career Background",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = player.biography.ifBlank { NOT_AVAILABLE },
                style = MaterialTheme.typography.bodyLarge,
                color = if (player.biography.isBlank()) {
                    MaterialTheme.colorScheme.onSurfaceVariant
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )

            HorizontalDivider()

            BiographyRow("Current Team", player.currentTeamName.ifBlank { NOT_AVAILABLE })
            BiographyRow("Previous Teams", player.previousTeams.ifBlank { NOT_AVAILABLE })
            BiographyRow("International Career", player.internationalCareerNote.ifBlank { NOT_AVAILABLE })
            BiographyRow("Domestic Career", player.domesticCareerNote.ifBlank { NOT_AVAILABLE })
        }
    }
}

@Composable
private fun BiographyRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
private fun HeroProfileChip(label: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = ArenaPureWhite.copy(alpha = 0.14f)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = ArenaPureWhite,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun PlayerMetricsGridSection(
    title: String,
    columns: Int,
    sectionTag: String,
    metrics: List<Pair<String, String>>
) {
    Column(
        modifier = Modifier.testTag(sectionTag),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )

        val rows = metrics.chunked(columns)
        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { (label, value) ->
                    StatMetricCell(
                        label = label,
                        value = value,
                        highlight = label in setOf(
                            "Runs",
                            "Batting Average",
                            "Strike Rate",
                            "Wickets",
                            "Economy Rate",
                            "Best Bowling",
                            "Total Dismissals"
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
                repeat(columns - row.size) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
