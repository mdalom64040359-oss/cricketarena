package com.example.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.entity.FavouriteType
import com.example.ui.components.ArenaBottomNavigationBar
import com.example.ui.components.ArenaSideNavigationRail
import com.example.ui.navigation.ArenaBottomNavItems
import com.example.ui.navigation.ArenaDestination
import com.example.ui.screens.CareerRecordsScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.MatchesFoundationScreen
import com.example.ui.screens.PersonalControlPanelScreen
import com.example.ui.screens.PlayerComparisonScreen
import com.example.ui.screens.PlayerProfileScreen
import com.example.ui.screens.PlayersDirectoryScreen
import com.example.ui.screens.SecondaryFoundationScreen
import com.example.ui.screens.StatisticsFoundationScreen
import com.example.ui.screens.TeamsFoundationScreen
import com.example.ui.screens.TournamentsFoundationScreen
import com.example.ui.viewmodel.DashboardViewModel
import com.example.ui.viewmodel.PlayerCareerViewModel
import com.example.ui.viewmodel.UserAccountViewModel

@Composable
fun CricketArenaApp(
    viewModel: DashboardViewModel,
    playerCareerViewModel: PlayerCareerViewModel,
    userAccountViewModel: UserAccountViewModel,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val directoryState by playerCareerViewModel.directoryState.collectAsStateWithLifecycle()
    val profileState by playerCareerViewModel.selectedProfileState.collectAsStateWithLifecycle()
    val userSessionState by userAccountViewModel.uiState.collectAsStateWithLifecycle()
    var comparisonSeedPlayerId by remember { mutableStateOf<String?>(null) }

    val topLevelRoutes = ArenaBottomNavItems.map { it.destination.route }.toSet()
    val showNavigationChrome = currentRoute == null || currentRoute in topLevelRoutes

    val navigateToTopLevel: (ArenaDestination) -> Unit = { destination ->
        navController.navigate(destination.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val navigateToDestination: (ArenaDestination) -> Unit = { destination ->
        if (destination.route in topLevelRoutes) {
            navigateToTopLevel(destination)
        } else {
            navController.navigate(destination.route) {
                launchSingleTop = true
            }
        }
    }

    val openPlayerProfile: (String) -> Unit = { playerId ->
        navController.navigate(ArenaDestination.PlayerProfile.createRoute(playerId)) {
            launchSingleTop = true
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavigationRail && showNavigationChrome) {
                ArenaSideNavigationRail(
                    currentRoute = currentRoute,
                    onNavigate = navigateToTopLevel
                )
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!useNavigationRail && showNavigationChrome) {
                        ArenaBottomNavigationBar(
                            currentRoute = currentRoute,
                            onNavigate = navigateToTopLevel
                        )
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = ArenaDestination.Home.route,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    composable(ArenaDestination.Home.route) {
                        HomeDashboardScreen(
                            uiState = uiState,
                            onNavigate = navigateToDestination,
                            userSessionState = userSessionState
                        )
                    }

                    composable(ArenaDestination.Matches.route) {
                        MatchesFoundationScreen(
                            uiState = uiState,
                            onCreateMatch = { navigateToDestination(ArenaDestination.CreateMatch) }
                        )
                    }

                    composable(ArenaDestination.Teams.route) {
                        TeamsFoundationScreen(
                            uiState = uiState,
                            onOpenPlayers = { navigateToDestination(ArenaDestination.Players) }
                        )
                    }

                    composable(ArenaDestination.Tournaments.route) {
                        TournamentsFoundationScreen(
                            uiState = uiState,
                            onOpenCreateTournament = {
                                navigateToDestination(ArenaDestination.CreateTournament)
                            }
                        )
                    }

                    composable(ArenaDestination.Statistics.route) {
                        StatisticsFoundationScreen(
                            directoryState = directoryState,
                            onSelectFormat = playerCareerViewModel::setRecordsFormat,
                            onOpenPlayers = { navigateToDestination(ArenaDestination.Players) },
                            onOpenComparison = {
                                comparisonSeedPlayerId = null
                                navigateToDestination(ArenaDestination.PlayerComparison)
                            },
                            onOpenPlayerProfile = openPlayerProfile
                        )
                    }

                    composable(ArenaDestination.CreateMatch.route) {
                        SecondaryFoundationScreen(
                            destination = ArenaDestination.CreateMatch,
                            uiState = uiState,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ArenaDestination.CreateTournament.route) {
                        SecondaryFoundationScreen(
                            destination = ArenaDestination.CreateTournament,
                            uiState = uiState,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ArenaDestination.Players.route) {
                        PlayersDirectoryScreen(
                            directoryState = directoryState,
                            viewModel = playerCareerViewModel,
                            onNavigateBack = { navController.popBackStack() },
                            onOpenPlayerProfile = openPlayerProfile,
                            onOpenComparison = {
                                comparisonSeedPlayerId = null
                                navigateToDestination(ArenaDestination.PlayerComparison)
                            },
                            onOpenRecords = {
                                navigateToDestination(ArenaDestination.CareerRecords)
                            }
                        )
                    }

                    composable(
                        route = ArenaDestination.PlayerProfile.route,
                        arguments = listOf(navArgument("playerId") { type = NavType.StringType })
                    ) { entry ->
                        val playerId = entry.arguments?.getString("playerId") ?: ""
                        val existingFav = userSessionState.favourites.find {
                            it.itemType == FavouriteType.PLAYER.name && it.itemKey == playerId
                        }
                        PlayerProfileScreen(
                            playerId = playerId,
                            profileState = profileState,
                            viewModel = playerCareerViewModel,
                            onNavigateBack = { navController.popBackStack() },
                            onComparePlayer = { seedId ->
                                comparisonSeedPlayerId = seedId
                                navigateToDestination(ArenaDestination.PlayerComparison)
                            },
                            isFavourite = existingFav != null,
                            onToggleFavourite = {
                                val player = profileState.player ?: return@PlayerProfileScreen
                                if (!userSessionState.isSignedIn) {
                                    navigateToDestination(ArenaDestination.PersonalPanel)
                                } else if (existingFav != null) {
                                    userAccountViewModel.removeFavourite(existingFav.id)
                                } else {
                                    userAccountViewModel.addFavourite(
                                        type = FavouriteType.PLAYER,
                                        key = player.id,
                                        displayName = player.fullName,
                                        subtitle = "${player.country} • ${player.role}"
                                    )
                                }
                            }
                        )
                    }

                    composable(ArenaDestination.PlayerComparison.route) {
                        PlayerComparisonScreen(
                            directoryState = directoryState,
                            initialPlayerAId = comparisonSeedPlayerId,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ArenaDestination.CareerRecords.route) {
                        CareerRecordsScreen(
                            directoryState = directoryState,
                            onSelectFormat = playerCareerViewModel::setRecordsFormat,
                            onOpenPlayerProfile = openPlayerProfile,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ArenaDestination.StorageBackup.route) {
                        SecondaryFoundationScreen(
                            destination = ArenaDestination.StorageBackup,
                            uiState = uiState,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ArenaDestination.PersonalPanel.route) {
                        PersonalControlPanelScreen(
                            userState = userSessionState,
                            dashboardState = uiState,
                            userAccountViewModel = userAccountViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
