package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.CareerScopeType
import com.example.data.local.entity.MajorLeagueCatalog
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.repository.MatchStatDelta
import com.example.domain.CareerStatsCalculator
import com.example.ui.theme.ArenaDeepGreen
import com.example.ui.theme.ArenaPureWhite
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlayerProfileEditorDialog(
    existingPlayer: PlayerEntity?,
    onDismiss: () -> Unit,
    onSave: (PlayerEntity) -> Unit
) {
    var fullName by remember { mutableStateOf(existingPlayer?.fullName ?: "") }
    var country by remember { mutableStateOf(existingPlayer?.country ?: "") }
    var dateOfBirth by remember { mutableStateOf(existingPlayer?.dateOfBirth ?: "") }
    var role by remember { mutableStateOf(existingPlayer?.role ?: "All-Rounder") }
    var battingHand by remember { mutableStateOf(existingPlayer?.battingHand ?: "Right-hand bat") }
    var bowlingStyle by remember { mutableStateOf(existingPlayer?.bowlingStyle ?: "Right-arm medium") }
    var currentTeam by remember { mutableStateOf(existingPlayer?.currentTeamName ?: "") }
    var previousTeams by remember { mutableStateOf(existingPlayer?.previousTeams ?: "") }
    var intlNote by remember { mutableStateOf(existingPlayer?.internationalCareerNote ?: "") }
    var domesticNote by remember { mutableStateOf(existingPlayer?.domesticCareerNote ?: "") }
    var biography by remember { mutableStateOf(existingPlayer?.biography ?: "") }
    var jerseyText by remember { mutableStateOf(existingPlayer?.jerseyNumber?.toString() ?: "") }
    var photoUri by remember { mutableStateOf(existingPlayer?.photoUri) }
    var dataSource by remember { mutableStateOf(existingPlayer?.dataSource ?: "Manual / Admin") }
    var nameError by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    val roles = listOf("Batter", "Bowler", "All-Rounder", "Wicketkeeper")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existingPlayer == null) "Add Player Profile" else "Edit Player Profile",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PlayerAvatar(fullName = fullName.ifBlank { "CA" }, photoUri = photoUri, size = 56.dp)
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PhotoLibrary,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (photoUri == null) "Choose Photo" else "Change Photo")
                    }
                }

                OutlinedTextField(
                    value = fullName,
                    onValueChange = {
                        fullName = it
                        nameError = false
                    },
                    label = { Text("Full Name *") },
                    isError = nameError,
                    supportingText = if (nameError) {
                        { Text("Player name is required") }
                    } else null,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_player_name")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = country,
                        onValueChange = { country = it },
                        label = { Text("Country") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = dateOfBirth,
                        onValueChange = { dateOfBirth = it },
                        label = { Text("Date of Birth") },
                        placeholder = { Text("DD MMM YYYY") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Text(
                    text = "Playing Role",
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    roles.forEach { option ->
                        FilterChip(
                            selected = role == option,
                            onClick = { role = option },
                            label = { Text(option) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ArenaDeepGreen,
                                selectedLabelColor = ArenaPureWhite
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = battingHand,
                        onValueChange = { battingHand = it },
                        label = { Text("Batting Style") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = jerseyText,
                        onValueChange = { jerseyText = it.filter(Char::isDigit) },
                        label = { Text("Jersey #") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.55f)
                    )
                }

                OutlinedTextField(
                    value = bowlingStyle,
                    onValueChange = { bowlingStyle = it },
                    label = { Text("Bowling Style") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = currentTeam,
                    onValueChange = { currentTeam = it },
                    label = { Text("Current Team") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = previousTeams,
                    onValueChange = { previousTeams = it },
                    label = { Text("Previous Teams (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = intlNote,
                    onValueChange = { intlNote = it },
                    label = { Text("International Career Info") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = domesticNote,
                    onValueChange = { domesticNote = it },
                    label = { Text("Domestic Career Info") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = biography,
                    onValueChange = { biography = it },
                    label = { Text("Player Biography") },
                    placeholder = { Text("Career background, milestones, playing style notes") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_player_biography")
                )

                OutlinedTextField(
                    value = dataSource,
                    onValueChange = { dataSource = it },
                    label = { Text("Data Source") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = fullName.trim()
                    if (trimmed.isEmpty()) {
                        nameError = true
                        return@Button
                    }
                    val now = System.currentTimeMillis()
                    onSave(
                        PlayerEntity(
                            id = existingPlayer?.id ?: UUID.randomUUID().toString(),
                            fullName = trimmed,
                            teamId = existingPlayer?.teamId,
                            role = role,
                            battingHand = battingHand.trim().ifEmpty { "Not Available" },
                            bowlingStyle = bowlingStyle.trim().ifEmpty { "Not Available" },
                            country = country.trim(),
                            dateOfBirth = dateOfBirth.trim(),
                            photoUri = photoUri,
                            currentTeamName = currentTeam.trim(),
                            previousTeams = previousTeams.trim(),
                            internationalCareerNote = intlNote.trim(),
                            domesticCareerNote = domesticNote.trim(),
                            biography = biography.trim(),
                            jerseyNumber = jerseyText.toIntOrNull(),
                            dataSource = dataSource.trim().ifEmpty { "Manual / Admin" },
                            createdAt = existingPlayer?.createdAt ?: now,
                            updatedAt = now
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("editor_save_player_button")
            ) {
                Text("Save Profile")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CareerStatEditorDialog(
    playerId: String,
    initialScopeType: CareerScopeType,
    initialScopeKey: String,
    initialScopeName: String,
    existingStat: PlayerCareerStatEntity?,
    onDismiss: () -> Unit,
    onSave: (PlayerCareerStatEntity) -> Unit
) {
    var scopeType by remember { mutableStateOf(initialScopeType) }
    var scopeKey by remember { mutableStateOf(initialScopeKey) }
    var scopeName by remember { mutableStateOf(initialScopeName) }
    var customLeagueName by remember { mutableStateOf("") }

    var bMatches by remember { mutableStateOf(existingStat?.battingMatches?.toString() ?: "") }
    var bInnings by remember { mutableStateOf(existingStat?.battingInnings?.toString() ?: "") }
    var runs by remember { mutableStateOf(existingStat?.runsScored?.toString() ?: "") }
    var ballsFaced by remember { mutableStateOf(existingStat?.ballsFaced?.toString() ?: "") }
    var hs by remember { mutableStateOf(existingStat?.highestScore?.toString() ?: "") }
    var hsNotOut by remember { mutableStateOf(existingStat?.highestScoreNotOut ?: false) }
    var notOuts by remember { mutableStateOf(existingStat?.notOuts?.toString() ?: "") }
    var fours by remember { mutableStateOf(existingStat?.fours?.toString() ?: "") }
    var sixes by remember { mutableStateOf(existingStat?.sixes?.toString() ?: "") }
    var hundreds by remember { mutableStateOf(existingStat?.hundreds?.toString() ?: "") }
    var fifties by remember { mutableStateOf(existingStat?.fifties?.toString() ?: "") }
    var doubleHundreds by remember { mutableStateOf(existingStat?.doubleHundreds?.toString() ?: "") }
    var ducks by remember { mutableStateOf(existingStat?.ducks?.toString() ?: "") }

    var wMatches by remember { mutableStateOf(existingStat?.bowlingMatches?.toString() ?: "") }
    var wInnings by remember { mutableStateOf(existingStat?.bowlingInnings?.toString() ?: "") }
    var oversBowled by remember {
        mutableStateOf(
            existingStat?.ballsBowled?.let { "${it / 6}.${it % 6}" } ?: ""
        )
    }
    var wickets by remember { mutableStateOf(existingStat?.wicketsTaken?.toString() ?: "") }
    var runsConceded by remember { mutableStateOf(existingStat?.runsConceded?.toString() ?: "") }
    var bestWickets by remember { mutableStateOf(existingStat?.bestBowlingWickets?.toString() ?: "") }
    var bestRuns by remember { mutableStateOf(existingStat?.bestBowlingRuns?.toString() ?: "") }
    var fourW by remember { mutableStateOf(existingStat?.fourWicketHauls?.toString() ?: "") }
    var fiveW by remember { mutableStateOf(existingStat?.fiveWicketHauls?.toString() ?: "") }
    var tenW by remember { mutableStateOf(existingStat?.tenWicketMatches?.toString() ?: "") }

    var catches by remember { mutableStateOf(existingStat?.catches?.toString() ?: "") }
    var runOuts by remember { mutableStateOf(existingStat?.runOuts?.toString() ?: "") }
    var stumpings by remember { mutableStateOf(existingStat?.stumpings?.toString() ?: "") }
    var highestPartnership by remember { mutableStateOf(existingStat?.highestPartnership?.toString() ?: "") }
    var pomAwards by remember { mutableStateOf(existingStat?.playerOfMatchAwards?.toString() ?: "") }
    var sourceLabel by remember { mutableStateOf(existingStat?.sourceLabel ?: "Manual / Admin") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Add / Edit Career Stats",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Leave any unknown field blank — missing data stays 'Not Available' (never 0).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = scopeType == CareerScopeType.FORMAT,
                        onClick = {
                            scopeType = CareerScopeType.FORMAT
                            if (CareerFormatScope.fromKey(scopeKey) == null) {
                                scopeKey = CareerFormatScope.T20I.key
                                scopeName = CareerFormatScope.T20I.displayName
                            }
                        },
                        label = { Text("Format") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArenaDeepGreen,
                            selectedLabelColor = ArenaPureWhite
                        )
                    )
                    FilterChip(
                        selected = scopeType == CareerScopeType.LEAGUE,
                        onClick = {
                            scopeType = CareerScopeType.LEAGUE
                            val firstLeague = MajorLeagueCatalog.leagues.first()
                            if (CareerFormatScope.fromKey(scopeKey) != null) {
                                scopeKey = firstLeague.key
                                scopeName = firstLeague.displayName
                            }
                        },
                        label = { Text("Tournament / League") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArenaDeepGreen,
                            selectedLabelColor = ArenaPureWhite
                        )
                    )
                }

                if (scopeType == CareerScopeType.FORMAT) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CareerFormatScope.entries.forEach { fmt ->
                            FilterChip(
                                selected = scopeKey == fmt.key,
                                onClick = {
                                    scopeKey = fmt.key
                                    scopeName = fmt.displayName
                                },
                                label = { Text(fmt.shortLabel) }
                            )
                        }
                    }
                } else {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MajorLeagueCatalog.leagues.forEach { lg ->
                            FilterChip(
                                selected = scopeKey == lg.key,
                                onClick = {
                                    scopeKey = lg.key
                                    scopeName = lg.displayName
                                    customLeagueName = ""
                                },
                                label = { Text(lg.displayName) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = customLeagueName,
                        onValueChange = {
                            customLeagueName = it
                            if (it.isNotBlank()) {
                                scopeKey = it.trim().uppercase().replace(Regex("\\s+"), "_")
                                scopeName = it.trim()
                            }
                        },
                        label = { Text("Or Custom League / Tournament") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                HorizontalDivider()
                Text("Batting Statistics", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                TwoNumFields("Matches", bMatches, { bMatches = it }, "Innings", bInnings, { bInnings = it })
                TwoNumFields("Runs", runs, { runs = it }, "Balls Faced", ballsFaced, { ballsFaced = it })
                TwoNumFields("Highest Score", hs, { hs = it }, "Not Outs", notOuts, { notOuts = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = hsNotOut, onCheckedChange = { hsNotOut = it })
                    Text("Highest score was Not Out (*)", style = MaterialTheme.typography.bodyMedium)
                }
                TwoNumFields("Fours (4s)", fours, { fours = it }, "Sixes (6s)", sixes, { sixes = it })
                TwoNumFields("100s", hundreds, { hundreds = it }, "50s", fifties, { fifties = it })
                TwoNumFields("200s", doubleHundreds, { doubleHundreds = it }, "Ducks (0s)", ducks, { ducks = it })

                HorizontalDivider()
                Text("Bowling Statistics", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                TwoNumFields("Matches", wMatches, { wMatches = it }, "Innings", wInnings, { wInnings = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = oversBowled,
                        onValueChange = { oversBowled = it },
                        label = { Text("Overs (e.g. 45.3)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = wickets,
                        onValueChange = { wickets = it.filter(Char::isDigit) },
                        label = { Text("Wickets") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                TwoNumFields("Runs Conceded", runsConceded, { runsConceded = it }, "4W Hauls", fourW, { fourW = it })
                TwoNumFields("Best Wickets", bestWickets, { bestWickets = it }, "Best Runs", bestRuns, { bestRuns = it })
                TwoNumFields("5W Hauls", fiveW, { fiveW = it }, "10W Matches", tenW, { tenW = it })

                HorizontalDivider()
                Text("Fielding & Records", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                TwoNumFields("Catches", catches, { catches = it }, "Run Outs", runOuts, { runOuts = it })
                TwoNumFields("Stumpings", stumpings, { stumpings = it }, "Best Partnership", highestPartnership, { highestPartnership = it })
                OutlinedTextField(
                    value = pomAwards,
                    onValueChange = { pomAwards = it.filter(Char::isDigit) },
                    label = { Text("Player of the Match Awards") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = sourceLabel,
                    onValueChange = { sourceLabel = it },
                    label = { Text("Data Source") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val stat = PlayerCareerStatEntity(
                        id = "${playerId}_${scopeType.name}_${scopeKey}",
                        playerId = playerId,
                        scopeType = scopeType.name,
                        scopeKey = scopeKey,
                        scopeDisplayName = scopeName,
                        battingMatches = bMatches.toIntOrNull(),
                        battingInnings = bInnings.toIntOrNull(),
                        runsScored = runs.toIntOrNull(),
                        ballsFaced = ballsFaced.toIntOrNull(),
                        highestScore = hs.toIntOrNull(),
                        highestScoreNotOut = hsNotOut,
                        notOuts = notOuts.toIntOrNull(),
                        fours = fours.toIntOrNull(),
                        sixes = sixes.toIntOrNull(),
                        hundreds = hundreds.toIntOrNull(),
                        fifties = fifties.toIntOrNull(),
                        doubleHundreds = doubleHundreds.toIntOrNull(),
                        ducks = ducks.toIntOrNull(),
                        bowlingMatches = wMatches.toIntOrNull(),
                        bowlingInnings = wInnings.toIntOrNull(),
                        ballsBowled = CareerStatsCalculator.parseOversToBalls(oversBowled),
                        wicketsTaken = wickets.toIntOrNull(),
                        runsConceded = runsConceded.toIntOrNull(),
                        bestBowlingWickets = bestWickets.toIntOrNull(),
                        bestBowlingRuns = bestRuns.toIntOrNull(),
                        fourWicketHauls = fourW.toIntOrNull(),
                        fiveWicketHauls = fiveW.toIntOrNull(),
                        tenWicketMatches = tenW.toIntOrNull(),
                        catches = catches.toIntOrNull(),
                        runOuts = runOuts.toIntOrNull(),
                        stumpings = stumpings.toIntOrNull(),
                        highestPartnership = highestPartnership.toIntOrNull(),
                        playerOfMatchAwards = pomAwards.toIntOrNull(),
                        sourceLabel = sourceLabel.trim().ifEmpty { "Manual / Admin" },
                        lastUpdatedAt = System.currentTimeMillis()
                    )
                    onSave(stat)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                ),
                modifier = Modifier.testTag("editor_save_stats_button")
            ) {
                Text("Save Stats")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RecordMatchContributionDialog(
    onDismiss: () -> Unit,
    onSubmit: (MatchStatDelta) -> Unit
) {
    var matchId by remember { mutableStateOf("") }
    var matchTitle by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf(CareerFormatScope.T20I) }
    var batted by remember { mutableStateOf(true) }
    var runs by remember { mutableStateOf("") }
    var ballsFaced by remember { mutableStateOf("") }
    var isNotOut by remember { mutableStateOf(false) }
    var fours by remember { mutableStateOf("") }
    var sixes by remember { mutableStateOf("") }
    var bowled by remember { mutableStateOf(false) }
    var overs by remember { mutableStateOf("") }
    var wickets by remember { mutableStateOf("") }
    var runsConceded by remember { mutableStateOf("") }
    var catches by remember { mutableStateOf("") }
    var pom by remember { mutableStateOf(false) }
    var idError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Single Match Stats", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Each Match ID can only be recorded once per player format to prevent double counting.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = matchId,
                    onValueChange = {
                        matchId = it
                        idError = false
                    },
                    label = { Text("Unique Match ID *") },
                    placeholder = { Text("e.g. MATCH-2026-001") },
                    isError = idError,
                    supportingText = if (idError) {
                        { Text("Match ID is required") }
                    } else null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = matchTitle,
                    onValueChange = { matchTitle = it },
                    label = { Text("Match Title") },
                    placeholder = { Text("e.g. Team A vs Team B") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        CareerFormatScope.TEST,
                        CareerFormatScope.ODI,
                        CareerFormatScope.T20I,
                        CareerFormatScope.DOMESTIC
                    ).forEach { fmt ->
                        FilterChip(
                            selected = selectedFormat == fmt,
                            onClick = { selectedFormat = fmt },
                            label = { Text(fmt.shortLabel) }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = batted, onCheckedChange = { batted = it })
                    Text("Player Batted")
                }
                if (batted) {
                    TwoNumFields("Runs", runs, { runs = it }, "Balls Faced", ballsFaced, { ballsFaced = it })
                    TwoNumFields("4s", fours, { fours = it }, "6s", sixes, { sixes = it })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isNotOut, onCheckedChange = { isNotOut = it })
                        Text("Not Out")
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = bowled, onCheckedChange = { bowled = it })
                    Text("Player Bowled")
                }
                if (bowled) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = overs,
                            onValueChange = { overs = it },
                            label = { Text("Overs (e.g. 4.0)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = wickets,
                            onValueChange = { wickets = it.filter(Char::isDigit) },
                            label = { Text("Wickets") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = runsConceded,
                        onValueChange = { runsConceded = it.filter(Char::isDigit) },
                        label = { Text("Runs Conceded") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = catches,
                    onValueChange = { catches = it.filter(Char::isDigit) },
                    label = { Text("Catches") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = pom, onCheckedChange = { pom = it })
                    Text("Player of the Match Award")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (matchId.trim().isEmpty()) {
                        idError = true
                        return@Button
                    }
                    onSubmit(
                        MatchStatDelta(
                            matchId = matchId.trim(),
                            matchTitle = matchTitle.trim(),
                            scopeType = CareerScopeType.FORMAT.name,
                            scopeKey = selectedFormat.key,
                            scopeDisplayName = selectedFormat.displayName,
                            sourceLabel = "Match Log (Deduplicated)",
                            batted = batted,
                            runsScored = runs.toIntOrNull(),
                            ballsFaced = ballsFaced.toIntOrNull(),
                            isNotOut = isNotOut,
                            fours = fours.toIntOrNull(),
                            sixes = sixes.toIntOrNull(),
                            bowled = bowled,
                            ballsBowled = CareerStatsCalculator.parseOversToBalls(overs),
                            wicketsTaken = wickets.toIntOrNull(),
                            runsConceded = runsConceded.toIntOrNull(),
                            catches = catches.toIntOrNull(),
                            isPlayerOfMatch = pom
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                )
            ) {
                Text("Record Match")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun PlayerJsonImportDialog(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var rawJson by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current

    val jsonSchemaGuide = """
        {
          "fullName": "Player Name",
          "country": "Country",
          "dateOfBirth": "DD MMM YYYY",
          "role": "All-Rounder",
          "battingHand": "Left-hand bat",
          "bowlingStyle": "Left-arm orthodox",
          "currentTeamName": "Team Name",
          "dataSource": "Admin JSON Import",
          "careerStats": [
            {
              "scopeType": "FORMAT",
              "scopeKey": "ODI",
              "battingMatches": 10,
              "battingInnings": 10,
              "runsScored": 450,
              "ballsFaced": 480,
              "highestScore": 105,
              "notOuts": 2
            }
          ]
        }
    """.trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import Player Career JSON", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Paste verified JSON player profile & career stats. Omitted fields remain 'Not Available'.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(jsonSchemaGuide)) },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Copy JSON Format Template")
                }

                OutlinedTextField(
                    value = rawJson,
                    onValueChange = { rawJson = it },
                    label = { Text("Player JSON") },
                    minLines = 6,
                    maxLines = 12,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onImport(rawJson) },
                enabled = rawJson.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArenaDeepGreen,
                    contentColor = ArenaPureWhite
                )
            ) {
                Text("Validate & Import")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun TwoNumFields(
    label1: String,
    value1: String,
    onChange1: (String) -> Unit,
    label2: String,
    value2: String,
    onChange2: (String) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = value1,
            onValueChange = { onChange1(it.filter(Char::isDigit)) },
            label = { Text(label1) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = value2,
            onValueChange = { onChange2(it.filter(Char::isDigit)) },
            label = { Text(label2) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
    }
}
