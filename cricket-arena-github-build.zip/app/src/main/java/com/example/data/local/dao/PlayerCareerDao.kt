package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.PlayerMatchContributionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerCareerDao {
    @Query("SELECT * FROM players ORDER BY fullName COLLATE NOCASE ASC")
    fun observeAllPlayers(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE id = :playerId LIMIT 1")
    fun observePlayerById(playerId: String): Flow<PlayerEntity?>

    @Query("SELECT * FROM players WHERE id = :playerId LIMIT 1")
    suspend fun getPlayerById(playerId: String): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlayer(player: PlayerEntity)

    @Query("DELETE FROM players WHERE id = :playerId")
    suspend fun deletePlayerById(playerId: String)

    @Query("SELECT * FROM player_career_stats WHERE playerId = :playerId ORDER BY lastUpdatedAt DESC")
    fun observeStatsForPlayer(playerId: String): Flow<List<PlayerCareerStatEntity>>

    @Query("SELECT * FROM player_career_stats")
    fun observeAllCareerStats(): Flow<List<PlayerCareerStatEntity>>

    @Query(
        "SELECT * FROM player_career_stats WHERE playerId = :playerId AND scopeType = :scopeType AND scopeKey = :scopeKey LIMIT 1"
    )
    suspend fun getStatByScope(
        playerId: String,
        scopeType: String,
        scopeKey: String
    ): PlayerCareerStatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCareerStat(stat: PlayerCareerStatEntity)

    @Query("DELETE FROM player_career_stats WHERE playerId = :playerId")
    suspend fun deleteStatsForPlayer(playerId: String)

    @Query("SELECT * FROM player_match_ledger WHERE playerId = :playerId ORDER BY recordedAt DESC")
    fun observeMatchLedgerForPlayer(playerId: String): Flow<List<PlayerMatchContributionEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMatchLedger(entry: PlayerMatchContributionEntity): Long

    @Query("DELETE FROM player_match_ledger WHERE playerId = :playerId")
    suspend fun deleteLedgerForPlayer(playerId: String)

    @Transaction
    suspend fun deletePlayerCascade(playerId: String) {
        deleteStatsForPlayer(playerId)
        deleteLedgerForPlayer(playerId)
        deletePlayerById(playerId)
    }
}
