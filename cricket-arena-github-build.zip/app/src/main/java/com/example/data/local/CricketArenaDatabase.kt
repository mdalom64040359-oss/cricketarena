package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.ArenaDao
import com.example.data.local.dao.PlayerCareerDao
import com.example.data.local.dao.UserAccountDao
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.PlayerMatchContributionEntity
import com.example.data.local.entity.TeamEntity
import com.example.data.local.entity.TournamentEntity
import com.example.data.local.entity.UserAccountEntity
import com.example.data.local.entity.UserFavouriteEntity
import com.example.data.local.entity.UserPersonalSettingsEntity

@Database(
    entities = [
        TeamEntity::class,
        PlayerEntity::class,
        PlayerCareerStatEntity::class,
        PlayerMatchContributionEntity::class,
        MatchEntity::class,
        TournamentEntity::class,
        UserAccountEntity::class,
        UserPersonalSettingsEntity::class,
        UserFavouriteEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class CricketArenaDatabase : RoomDatabase() {
    abstract fun arenaDao(): ArenaDao
    abstract fun playerCareerDao(): PlayerCareerDao
    abstract fun userAccountDao(): UserAccountDao

    companion object {
        @Volatile
        private var INSTANCE: CricketArenaDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE players ADD COLUMN country TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE players ADD COLUMN dateOfBirth TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE players ADD COLUMN photoUri TEXT")
                db.execSQL("ALTER TABLE players ADD COLUMN currentTeamName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE players ADD COLUMN previousTeams TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE players ADD COLUMN internationalCareerNote TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE players ADD COLUMN domesticCareerNote TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE players ADD COLUMN jerseyNumber INTEGER")
                db.execSQL("ALTER TABLE players ADD COLUMN dataSource TEXT NOT NULL DEFAULT 'Manual / Admin'")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `player_career_stats` (
                        `id` TEXT NOT NULL,
                        `playerId` TEXT NOT NULL,
                        `scopeType` TEXT NOT NULL,
                        `scopeKey` TEXT NOT NULL,
                        `scopeDisplayName` TEXT NOT NULL,
                        `battingMatches` INTEGER,
                        `battingInnings` INTEGER,
                        `runsScored` INTEGER,
                        `ballsFaced` INTEGER,
                        `highestScore` INTEGER,
                        `highestScoreNotOut` INTEGER NOT NULL,
                        `notOuts` INTEGER,
                        `fours` INTEGER,
                        `sixes` INTEGER,
                        `hundreds` INTEGER,
                        `fifties` INTEGER,
                        `doubleHundreds` INTEGER,
                        `ducks` INTEGER,
                        `explicitBattingAverage` REAL,
                        `explicitStrikeRate` REAL,
                        `bowlingMatches` INTEGER,
                        `bowlingInnings` INTEGER,
                        `ballsBowled` INTEGER,
                        `wicketsTaken` INTEGER,
                        `runsConceded` INTEGER,
                        `bestBowlingWickets` INTEGER,
                        `bestBowlingRuns` INTEGER,
                        `fourWicketHauls` INTEGER,
                        `fiveWicketHauls` INTEGER,
                        `tenWicketMatches` INTEGER,
                        `explicitBowlingAverage` REAL,
                        `explicitEconomyRate` REAL,
                        `explicitBowlingStrikeRate` REAL,
                        `catches` INTEGER,
                        `runOuts` INTEGER,
                        `stumpings` INTEGER,
                        `highestPartnership` INTEGER,
                        `playerOfMatchAwards` INTEGER,
                        `sourceLabel` TEXT NOT NULL,
                        `lastUpdatedAt` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_player_career_stats_playerId` ON `player_career_stats` (`playerId`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_player_career_stats_playerId_scopeType_scopeKey` ON `player_career_stats` (`playerId`, `scopeType`, `scopeKey`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `player_match_ledger` (
                        `entryId` TEXT NOT NULL,
                        `playerId` TEXT NOT NULL,
                        `matchId` TEXT NOT NULL,
                        `matchTitle` TEXT NOT NULL,
                        `scopeType` TEXT NOT NULL,
                        `scopeKey` TEXT NOT NULL,
                        `sourceLabel` TEXT NOT NULL,
                        `recordedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`entryId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_player_match_ledger_playerId_matchId_scopeKey` ON `player_match_ledger` (`playerId`, `matchId`, `scopeKey`)")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE players ADD COLUMN biography TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `user_accounts` (
                        `userId` TEXT NOT NULL,
                        `fullName` TEXT NOT NULL,
                        `emailOrHandle` TEXT NOT NULL,
                        `bio` TEXT NOT NULL,
                        `cityOrPhone` TEXT NOT NULL,
                        `photoUri` TEXT,
                        `passwordHash` TEXT NOT NULL,
                        `passwordSalt` TEXT NOT NULL,
                        `recoveryCodeHash` TEXT NOT NULL,
                        `recoveryCodeSalt` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`userId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_user_accounts_emailOrHandle` ON `user_accounts` (`emailOrHandle`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `user_personal_settings` (
                        `userId` TEXT NOT NULL,
                        `languageCode` TEXT NOT NULL,
                        `themeMode` TEXT NOT NULL,
                        `notificationsEnabled` INTEGER NOT NULL,
                        `matchStartAlerts` INTEGER NOT NULL,
                        `wicketAlerts` INTEGER NOT NULL,
                        `milestoneAlerts` INTEGER NOT NULL,
                        `profilePrivate` INTEGER NOT NULL,
                        `analyticsOptIn` INTEGER NOT NULL,
                        `autoSyncWhenOnline` INTEGER NOT NULL,
                        `lastSyncedAt` INTEGER,
                        `updatedAt` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`userId`)
                    )
                    """.trimIndent()
                )

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `user_favourites` (
                        `id` TEXT NOT NULL,
                        `userId` TEXT NOT NULL,
                        `itemType` TEXT NOT NULL,
                        `itemKey` TEXT NOT NULL,
                        `displayName` TEXT NOT NULL,
                        `subtitle` TEXT NOT NULL,
                        `matchAlertsEnabled` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_user_favourites_userId` ON `user_favourites` (`userId`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_user_favourites_userId_itemType_itemKey` ON `user_favourites` (`userId`, `itemType`, `itemKey`)")
            }
        }

        fun getInstance(context: Context): CricketArenaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CricketArenaDatabase::class.java,
                    "cricket_arena.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
