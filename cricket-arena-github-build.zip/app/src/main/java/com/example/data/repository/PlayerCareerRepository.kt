package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.CricketArenaDatabase
import com.example.data.local.dao.PlayerCareerDao
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.PlayerMatchContributionEntity
import com.example.domain.CareerStatsCalculator
import com.example.domain.PlayerJsonCodec
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class MatchStatDelta(
    val matchId: String,
    val matchTitle: String,
    val scopeType: String,
    val scopeKey: String,
    val scopeDisplayName: String,
    val sourceLabel: String,
    val batted: Boolean = false,
    val runsScored: Int? = null,
    val ballsFaced: Int? = null,
    val isNotOut: Boolean = false,
    val fours: Int? = null,
    val sixes: Int? = null,
    val bowled: Boolean = false,
    val ballsBowled: Int? = null,
    val wicketsTaken: Int? = null,
    val runsConceded: Int? = null,
    val catches: Int? = null,
    val runOuts: Int? = null,
    val stumpings: Int? = null,
    val partnershipRuns: Int? = null,
    val isPlayerOfMatch: Boolean = false
)

sealed interface MatchContributionResult {
    data object Applied : MatchContributionResult
    data class DuplicateBlocked(val matchId: String) : MatchContributionResult
    data class Error(val message: String) : MatchContributionResult
}

interface PlayerCareerRepository {
    fun observeAllPlayers(): Flow<List<PlayerEntity>>
    fun observePlayerById(playerId: String): Flow<PlayerEntity?>
    fun observeStatsForPlayer(playerId: String): Flow<List<PlayerCareerStatEntity>>
    fun observeAllCareerStats(): Flow<List<PlayerCareerStatEntity>>
    fun observeMatchLedgerForPlayer(playerId: String): Flow<List<PlayerMatchContributionEntity>>

    suspend fun savePlayer(player: PlayerEntity)
    suspend fun deletePlayer(playerId: String)
    suspend fun upsertCareerStat(stat: PlayerCareerStatEntity)
    suspend fun applyMatchContribution(playerId: String, delta: MatchStatDelta): MatchContributionResult
    suspend fun importPlayerJson(rawJson: String): Result<PlayerEntity>
}

class OfflinePlayerCareerRepository(
    private val database: CricketArenaDatabase,
    private val dao: PlayerCareerDao = database.playerCareerDao()
) : PlayerCareerRepository {

    override fun observeAllPlayers(): Flow<List<PlayerEntity>> = dao.observeAllPlayers()

    override fun observePlayerById(playerId: String): Flow<PlayerEntity?> = dao.observePlayerById(playerId)

    override fun observeStatsForPlayer(playerId: String): Flow<List<PlayerCareerStatEntity>> =
        dao.observeStatsForPlayer(playerId)

    override fun observeAllCareerStats(): Flow<List<PlayerCareerStatEntity>> = dao.observeAllCareerStats()

    override fun observeMatchLedgerForPlayer(playerId: String): Flow<List<PlayerMatchContributionEntity>> =
        dao.observeMatchLedgerForPlayer(playerId)

    override suspend fun savePlayer(player: PlayerEntity) {
        dao.upsertPlayer(player.copy(updatedAt = System.currentTimeMillis()))
    }

    override suspend fun deletePlayer(playerId: String) {
        dao.deletePlayerCascade(playerId)
    }

    override suspend fun upsertCareerStat(stat: PlayerCareerStatEntity) {
        val normalizedId = "${stat.playerId}_${stat.scopeType}_${stat.scopeKey}"
        dao.upsertCareerStat(
            stat.copy(
                id = normalizedId,
                lastUpdatedAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun applyMatchContribution(
        playerId: String,
        delta: MatchStatDelta
    ): MatchContributionResult {
        val cleanMatchId = delta.matchId.trim()
        if (cleanMatchId.isEmpty()) {
            return MatchContributionResult.Error("Match ID is required to prevent duplicate counting.")
        }

        return database.withTransaction {
            val ledgerId = "${playerId}::${cleanMatchId}::${delta.scopeKey}"
            val insertedRowId = dao.insertMatchLedger(
                PlayerMatchContributionEntity(
                    entryId = ledgerId,
                    playerId = playerId,
                    matchId = cleanMatchId,
                    matchTitle = delta.matchTitle.ifBlank { cleanMatchId },
                    scopeType = delta.scopeType,
                    scopeKey = delta.scopeKey,
                    sourceLabel = delta.sourceLabel,
                    recordedAt = System.currentTimeMillis()
                )
            )

            if (insertedRowId == -1L) {
                return@withTransaction MatchContributionResult.DuplicateBlocked(cleanMatchId)
            }

            val existing = dao.getStatByScope(playerId, delta.scopeType, delta.scopeKey)
            val now = System.currentTimeMillis()

            fun addNullable(current: Int?, increment: Int?): Int? {
                if (current == null && increment == null) return null
                return (current ?: 0) + (increment ?: 0)
            }

            val newBattingMatches = addNullable(existing?.battingMatches, 1)
            val newBattingInnings = if (delta.batted) addNullable(existing?.battingInnings, 1) else existing?.battingInnings
            val newRuns = if (delta.batted) addNullable(existing?.runsScored, delta.runsScored) else existing?.runsScored
            val newBallsFaced = if (delta.batted) addNullable(existing?.ballsFaced, delta.ballsFaced) else existing?.ballsFaced
            val newNotOuts = if (delta.batted && delta.isNotOut) addNullable(existing?.notOuts, 1) else existing?.notOuts
            val newFours = if (delta.batted) addNullable(existing?.fours, delta.fours) else existing?.fours
            val newSixes = if (delta.batted) addNullable(existing?.sixes, delta.sixes) else existing?.sixes

            val matchRuns = delta.runsScored
            var newHs = existing?.highestScore
            var newHsNo = existing?.highestScoreNotOut ?: false
            if (delta.batted && matchRuns != null) {
                if (newHs == null || matchRuns > newHs || (matchRuns == newHs && delta.isNotOut && !newHsNo)) {
                    newHs = matchRuns
                    newHsNo = delta.isNotOut
                }
            }

            val addDoubleCentury = if (delta.batted && matchRuns != null && matchRuns >= 200) 1 else null
            val addCentury = if (delta.batted && matchRuns != null && matchRuns in 100..199) 1 else null
            val addFifty = if (delta.batted && matchRuns != null && matchRuns in 50..99) 1 else null
            val addDuck = if (delta.batted && matchRuns != null && matchRuns == 0 && !delta.isNotOut) 1 else null

            val newBowlingMatches = addNullable(existing?.bowlingMatches, 1)
            val newBowlingInnings = if (delta.bowled) addNullable(existing?.bowlingInnings, 1) else existing?.bowlingInnings
            val newBallsBowled = if (delta.bowled) addNullable(existing?.ballsBowled, delta.ballsBowled) else existing?.ballsBowled
            val newWickets = if (delta.bowled) addNullable(existing?.wicketsTaken, delta.wicketsTaken) else existing?.wicketsTaken
            val newRunsConceded = if (delta.bowled) addNullable(existing?.runsConceded, delta.runsConceded) else existing?.runsConceded

            var newBestW = existing?.bestBowlingWickets
            var newBestR = existing?.bestBowlingRuns
            if (delta.bowled && delta.wicketsTaken != null && delta.runsConceded != null) {
                if (newBestW == null || newBestR == null ||
                    CareerStatsCalculator.isBetterBowling(delta.wicketsTaken, delta.runsConceded, newBestW, newBestR)
                ) {
                    newBestW = delta.wicketsTaken
                    newBestR = delta.runsConceded
                }
            }

            val add4W = if (delta.bowled && delta.wicketsTaken != null && delta.wicketsTaken == 4) 1 else null
            val add5W = if (delta.bowled && delta.wicketsTaken != null && delta.wicketsTaken >= 5) 1 else null
            val add10W = if (delta.bowled && delta.wicketsTaken != null && delta.wicketsTaken >= 10) 1 else null

            val newPartnership = listOfNotNull(existing?.highestPartnership, delta.partnershipRuns).maxOrNull()
            val newPom = if (delta.isPlayerOfMatch) addNullable(existing?.playerOfMatchAwards, 1) else existing?.playerOfMatchAwards

            val updated = PlayerCareerStatEntity(
                id = existing?.id ?: "${playerId}_${delta.scopeType}_${delta.scopeKey}",
                playerId = playerId,
                scopeType = delta.scopeType,
                scopeKey = delta.scopeKey,
                scopeDisplayName = delta.scopeDisplayName,
                battingMatches = newBattingMatches,
                battingInnings = newBattingInnings,
                runsScored = newRuns,
                ballsFaced = newBallsFaced,
                highestScore = newHs,
                highestScoreNotOut = newHsNo,
                notOuts = newNotOuts,
                fours = newFours,
                sixes = newSixes,
                hundreds = addNullable(existing?.hundreds, addCentury),
                fifties = addNullable(existing?.fifties, addFifty),
                doubleHundreds = addNullable(existing?.doubleHundreds, addDoubleCentury),
                ducks = addNullable(existing?.ducks, addDuck),
                bowlingMatches = newBowlingMatches,
                bowlingInnings = newBowlingInnings,
                ballsBowled = newBallsBowled,
                wicketsTaken = newWickets,
                runsConceded = newRunsConceded,
                bestBowlingWickets = newBestW,
                bestBowlingRuns = newBestR,
                fourWicketHauls = addNullable(existing?.fourWicketHauls, add4W),
                fiveWicketHauls = addNullable(existing?.fiveWicketHauls, add5W),
                tenWicketMatches = addNullable(existing?.tenWicketMatches, add10W),
                catches = addNullable(existing?.catches, delta.catches),
                runOuts = addNullable(existing?.runOuts, delta.runOuts),
                stumpings = addNullable(existing?.stumpings, delta.stumpings),
                highestPartnership = newPartnership,
                playerOfMatchAwards = newPom,
                sourceLabel = delta.sourceLabel,
                lastUpdatedAt = now
            )

            dao.upsertCareerStat(updated)
            MatchContributionResult.Applied
        }
    }

    override suspend fun importPlayerJson(rawJson: String): Result<PlayerEntity> {
        val parsed = PlayerJsonCodec.parsePlayerImportJson(rawJson)
        return parsed.map { bundle ->
            database.withTransaction {
                val safeId = bundle.player.id.ifBlank { UUID.randomUUID().toString() }
                val playerToSave = bundle.player.copy(id = safeId)
                dao.upsertPlayer(playerToSave)
                bundle.stats.forEach { stat ->
                    dao.upsertCareerStat(
                        stat.copy(
                            id = "${safeId}_${stat.scopeType}_${stat.scopeKey}",
                            playerId = safeId
                        )
                    )
                }
                playerToSave
            }
        }
    }
}
