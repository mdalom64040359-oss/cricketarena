package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.CricketArenaDatabase
import com.example.data.local.SessionStorage
import com.example.data.local.dao.UserAccountDao
import com.example.data.local.entity.FavouriteType
import com.example.data.local.entity.UserAccountEntity
import com.example.data.local.entity.UserFavouriteEntity
import com.example.data.local.entity.UserPersonalSettingsEntity
import com.example.data.security.PasswordHasher
import com.example.data.sync.CloudSyncAdapter
import com.example.data.sync.LocalOnlySyncAdapter
import com.example.data.sync.SyncStatus
import com.example.domain.PersonalBackupCodec
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import java.util.UUID

data class ActiveUserBundle(
    val account: UserAccountEntity,
    val settings: UserPersonalSettingsEntity,
    val favourites: List<UserFavouriteEntity>
)

sealed interface SyncAttemptResult {
    data class Synced(val count: Int) : SyncAttemptResult
    data object OfflineQueued : SyncAttemptResult
    data class CloudNotConfigured(val pendingCount: Int) : SyncAttemptResult
}

interface UserAccountRepository {
    fun observeActiveUserBundle(): Flow<ActiveUserBundle?>

    suspend fun signUp(
        fullName: String,
        emailOrHandle: String,
        password: String,
        recoveryCode: String,
        cityOrPhone: String,
        bio: String,
        photoUri: String?
    ): Result<UserAccountEntity>

    suspend fun login(emailOrHandle: String, password: String): Result<UserAccountEntity>

    suspend fun logout()

    suspend fun resetPasswordWithRecovery(
        emailOrHandle: String,
        recoveryCode: String,
        newPassword: String
    ): Result<Unit>

    suspend fun updateProfile(
        userId: String,
        fullName: String,
        bio: String,
        cityOrPhone: String,
        photoUri: String?
    ): Result<Unit>

    suspend fun updateSettings(userId: String, transform: (UserPersonalSettingsEntity) -> UserPersonalSettingsEntity): Result<Unit>

    suspend fun addOrUpdateFavourite(
        userId: String,
        type: FavouriteType,
        itemKey: String,
        displayName: String,
        subtitle: String = ""
    ): Result<Unit>

    suspend fun toggleFavouriteMatchAlert(userId: String, favId: String, enabled: Boolean): Result<Unit>

    suspend fun removeFavourite(userId: String, favId: String): Result<Unit>

    suspend fun clearAllFavourites(userId: String): Result<Unit>

    suspend fun changePassword(userId: String, currentPassword: String, newPassword: String): Result<Unit>

    suspend fun deleteMyAccount(userId: String, confirmPassword: String): Result<Unit>

    suspend fun exportPersonalBackupJson(userId: String): Result<String>

    suspend fun restorePersonalBackupJson(userId: String, rawJson: String): Result<Int>

    suspend fun attemptSyncWhenOnline(userId: String, isOnline: Boolean): SyncAttemptResult
}

class OfflineFirstUserAccountRepository(
    private val database: CricketArenaDatabase,
    private val sessionStore: SessionStorage,
    private val dao: UserAccountDao = database.userAccountDao(),
    private val cloudSyncAdapter: CloudSyncAdapter = LocalOnlySyncAdapter()
) : UserAccountRepository {

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeActiveUserBundle(): Flow<ActiveUserBundle?> {
        return sessionStore.activeUserId.flatMapLatest { activeId ->
            if (activeId.isNullOrBlank()) {
                flowOf(null)
            } else {
                combine(
                    dao.observeAccount(activeId),
                    dao.observeSettings(activeId),
                    dao.observeFavourites(activeId)
                ) { account, settings, favourites ->
                    account?.let {
                        ActiveUserBundle(
                            account = it,
                            settings = settings ?: UserPersonalSettingsEntity(userId = it.userId),
                            favourites = favourites
                        )
                    }
                }
            }
        }
    }

    private suspend fun verifySessionOwnership(expectedUserId: String) {
        val current = dao.getAccount(expectedUserId)
            ?: throw SecurityException("Active user account not found.")
        if (current.userId != expectedUserId) {
            throw SecurityException("Cross-user access denied.")
        }
    }

    override suspend fun signUp(
        fullName: String,
        emailOrHandle: String,
        password: String,
        recoveryCode: String,
        cityOrPhone: String,
        bio: String,
        photoUri: String?
    ): Result<UserAccountEntity> = runCatching {
        val cleanName = fullName.trim()
        val cleanHandle = emailOrHandle.trim().lowercase()
        val cleanRecovery = recoveryCode.trim()

        require(cleanName.isNotEmpty()) { "Name is required." }
        require(cleanHandle.length >= 3) { "Email or username must be at least 3 characters." }
        require(password.length >= 6) { "Password must be at least 6 characters." }
        require(cleanRecovery.length >= 4) { "Recovery code must be at least 4 characters." }

        val existing = dao.findByHandle(cleanHandle)
        require(existing == null) { "An account with this email/username already exists." }

        val now = System.currentTimeMillis()
        val userId = "USR-" + UUID.randomUUID().toString().take(8).uppercase()
        val pwdHash = PasswordHasher.hashSecret(password)
        val recHash = PasswordHasher.hashSecret(cleanRecovery)

        val account = UserAccountEntity(
            userId = userId,
            fullName = cleanName,
            emailOrHandle = cleanHandle,
            bio = bio.trim(),
            cityOrPhone = cityOrPhone.trim(),
            photoUri = photoUri,
            passwordHash = pwdHash.hashBase64,
            passwordSalt = pwdHash.saltBase64,
            recoveryCodeHash = recHash.hashBase64,
            recoveryCodeSalt = recHash.saltBase64,
            createdAt = now,
            updatedAt = now,
            syncStatus = SyncStatus.PENDING_SYNC.name
        )

        val defaultSettings = UserPersonalSettingsEntity(
            userId = userId,
            updatedAt = now,
            syncStatus = SyncStatus.PENDING_SYNC.name
        )

        database.withTransaction {
            dao.upsertAccount(account)
            dao.upsertSettings(defaultSettings)
        }
        sessionStore.setActiveUserId(userId)
        account
    }

    override suspend fun login(emailOrHandle: String, password: String): Result<UserAccountEntity> =
        runCatching {
            val cleanHandle = emailOrHandle.trim().lowercase()
            require(cleanHandle.isNotEmpty() && password.isNotEmpty()) {
                "Email/username and password are required."
            }
            val account = dao.findByHandle(cleanHandle)
                ?: throw IllegalArgumentException("Invalid email/username or password.")

            val valid = PasswordHasher.verifySecret(
                secret = password,
                expectedHashBase64 = account.passwordHash,
                saltBase64 = account.passwordSalt
            )
            require(valid) { "Invalid email/username or password." }

            if (dao.getSettings(account.userId) == null) {
                dao.upsertSettings(UserPersonalSettingsEntity(userId = account.userId))
            }
            sessionStore.setActiveUserId(account.userId)
            account
        }

    override suspend fun logout() {
        sessionStore.setActiveUserId(null)
    }

    override suspend fun resetPasswordWithRecovery(
        emailOrHandle: String,
        recoveryCode: String,
        newPassword: String
    ): Result<Unit> = runCatching {
        val cleanHandle = emailOrHandle.trim().lowercase()
        require(newPassword.length >= 6) { "New password must be at least 6 characters." }
        val account = dao.findByHandle(cleanHandle)
            ?: throw IllegalArgumentException("Account not found for that email/username.")

        val validRecovery = PasswordHasher.verifySecret(
            secret = recoveryCode.trim(),
            expectedHashBase64 = account.recoveryCodeHash,
            saltBase64 = account.recoveryCodeSalt
        )
        require(validRecovery) { "Recovery code does not match this account." }

        val newHash = PasswordHasher.hashSecret(newPassword)
        dao.upsertAccount(
            account.copy(
                passwordHash = newHash.hashBase64,
                passwordSalt = newHash.saltBase64,
                updatedAt = System.currentTimeMillis(),
                syncStatus = SyncStatus.PENDING_SYNC.name
            )
        )
    }

    override suspend fun updateProfile(
        userId: String,
        fullName: String,
        bio: String,
        cityOrPhone: String,
        photoUri: String?
    ): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        val cleanName = fullName.trim()
        require(cleanName.isNotEmpty()) { "Name cannot be empty." }
        val current = dao.getAccount(userId)!!
        dao.upsertAccount(
            current.copy(
                fullName = cleanName,
                bio = bio.trim(),
                cityOrPhone = cityOrPhone.trim(),
                photoUri = photoUri,
                updatedAt = System.currentTimeMillis(),
                syncStatus = SyncStatus.PENDING_SYNC.name
            )
        )
    }

    override suspend fun updateSettings(
        userId: String,
        transform: (UserPersonalSettingsEntity) -> UserPersonalSettingsEntity
    ): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        val current = dao.getSettings(userId) ?: UserPersonalSettingsEntity(userId = userId)
        val updated = transform(current).copy(
            userId = userId,
            updatedAt = System.currentTimeMillis(),
            syncStatus = SyncStatus.PENDING_SYNC.name
        )
        dao.upsertSettings(updated)
    }

    override suspend fun addOrUpdateFavourite(
        userId: String,
        type: FavouriteType,
        itemKey: String,
        displayName: String,
        subtitle: String
    ): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        val cleanKey = itemKey.trim()
        val cleanName = displayName.trim()
        require(cleanKey.isNotEmpty() && cleanName.isNotEmpty()) { "Favourite name is required." }

        val fav = UserFavouriteEntity(
            id = "${userId}::${type.name}::${cleanKey}",
            userId = userId,
            itemType = type.name,
            itemKey = cleanKey,
            displayName = cleanName,
            subtitle = subtitle.trim(),
            matchAlertsEnabled = true,
            createdAt = System.currentTimeMillis(),
            syncStatus = SyncStatus.PENDING_SYNC.name
        )
        dao.upsertFavourite(fav)
    }

    override suspend fun toggleFavouriteMatchAlert(
        userId: String,
        favId: String,
        enabled: Boolean
    ): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        val existing = dao.getFavouritesOnce(userId).find { it.id == favId }
            ?: throw IllegalArgumentException("Favourite not found for your account.")
        dao.upsertFavourite(
            existing.copy(
                matchAlertsEnabled = enabled,
                syncStatus = SyncStatus.PENDING_SYNC.name
            )
        )
    }

    override suspend fun removeFavourite(userId: String, favId: String): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        dao.removeFavourite(favId, userId)
    }

    override suspend fun clearAllFavourites(userId: String): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        dao.deleteAllFavouritesForUser(userId)
    }

    override suspend fun changePassword(
        userId: String,
        currentPassword: String,
        newPassword: String
    ): Result<Unit> = runCatching {
        verifySessionOwnership(userId)
        require(newPassword.length >= 6) { "New password must be at least 6 characters." }
        val account = dao.getAccount(userId)!!
        val matches = PasswordHasher.verifySecret(
            secret = currentPassword,
            expectedHashBase64 = account.passwordHash,
            saltBase64 = account.passwordSalt
        )
        require(matches) { "Current password is incorrect." }

        val nextHash = PasswordHasher.hashSecret(newPassword)
        dao.upsertAccount(
            account.copy(
                passwordHash = nextHash.hashBase64,
                passwordSalt = nextHash.saltBase64,
                updatedAt = System.currentTimeMillis(),
                syncStatus = SyncStatus.PENDING_SYNC.name
            )
        )
    }

    override suspend fun deleteMyAccount(userId: String, confirmPassword: String): Result<Unit> =
        runCatching {
            verifySessionOwnership(userId)
            val account = dao.getAccount(userId)!!
            val matches = PasswordHasher.verifySecret(
                secret = confirmPassword,
                expectedHashBase64 = account.passwordHash,
                saltBase64 = account.passwordSalt
            )
            require(matches) { "Password verification failed." }

            dao.deleteUserAccountCascade(userId)
            sessionStore.setActiveUserId(null)
        }

    override suspend fun exportPersonalBackupJson(userId: String): Result<String> = runCatching {
        verifySessionOwnership(userId)
        val account = dao.getAccount(userId)!!
        val settings = dao.getSettings(userId) ?: UserPersonalSettingsEntity(userId = userId)
        val favs = dao.getFavouritesOnce(userId)
        PersonalBackupCodec.exportBackupJson(account, settings, favs)
    }

    override suspend fun restorePersonalBackupJson(userId: String, rawJson: String): Result<Int> =
        runCatching {
            verifySessionOwnership(userId)
            val restored = PersonalBackupCodec.parseAndValidateBackup(rawJson, userId).getOrThrow()
            val account = dao.getAccount(userId)!!

            database.withTransaction {
                dao.upsertAccount(
                    account.copy(
                        fullName = restored.fullName,
                        bio = restored.bio,
                        cityOrPhone = restored.cityOrPhone,
                        updatedAt = System.currentTimeMillis(),
                        syncStatus = SyncStatus.PENDING_SYNC.name
                    )
                )
                dao.upsertSettings(restored.settings)
                dao.deleteAllFavouritesForUser(userId)
                restored.favourites.forEach { fav ->
                    dao.upsertFavourite(fav)
                }
            }
            restored.favourites.size
        }

    override suspend fun attemptSyncWhenOnline(userId: String, isOnline: Boolean): SyncAttemptResult {
        val favs = dao.getFavouritesOnce(userId)
        val pendingCount = favs.count { it.syncStatus == SyncStatus.PENDING_SYNC.name } + 1
        if (!isOnline) {
            return SyncAttemptResult.OfflineQueued
        }
        return if (!cloudSyncAdapter.isConfigured) {
            SyncAttemptResult.CloudNotConfigured(pendingCount)
        } else {
            val count = cloudSyncAdapter.pushPendingChanges().getOrDefault(0)
            SyncAttemptResult.Synced(count)
        }
    }
}
