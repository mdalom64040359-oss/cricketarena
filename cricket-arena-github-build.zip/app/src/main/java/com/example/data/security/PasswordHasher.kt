package com.example.data.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Cryptographic password & recovery-code helper using salted PBKDF2WithHmacSHA256.
 * Never stores plaintext secrets in Room or DataStore.
 */
object PasswordHasher {
    private const val ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val ITERATIONS = 10_000
    private const val KEY_LENGTH_BITS = 256
    private const val SALT_BYTES = 16

    data class SaltedHash(val hashBase64: String, val saltBase64: String)

    fun generateSalt(): String {
        val salt = ByteArray(SALT_BYTES)
        SecureRandom().nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }

    fun hashSecret(secret: String, saltBase64: String = generateSalt()): SaltedHash {
        val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
        val spec = PBEKeySpec(secret.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS)
        return try {
            val factory = SecretKeyFactory.getInstance(ALGORITHM)
            val derived = factory.generateSecret(spec).encoded
            SaltedHash(
                hashBase64 = Base64.encodeToString(derived, Base64.NO_WRAP),
                saltBase64 = saltBase64
            )
        } finally {
            spec.clearPassword()
        }
    }

    fun verifySecret(secret: String, expectedHashBase64: String, saltBase64: String): Boolean {
        val computed = hashSecret(secret, saltBase64)
        val expectedBytes = Base64.decode(expectedHashBase64, Base64.NO_WRAP)
        val actualBytes = Base64.decode(computed.hashBase64, Base64.NO_WRAP)
        return MessageDigest.isEqual(expectedBytes, actualBytes)
    }
}
