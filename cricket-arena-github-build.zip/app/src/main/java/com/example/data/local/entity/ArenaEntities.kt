package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.sync.SyncStatus

@Entity(tableName = "teams")
data class TeamEntity(
    @PrimaryKey val id: String,
    val name: String,
    val shortCode: String,
    val homeGround: String = "",
    val accentHex: String = "#0A2F1D",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.LOCAL_ONLY.name
)

@Entity(tableName = "players")
data class PlayerEntity(
    @PrimaryKey val id: String,
    val fullName: String,
    val teamId: String? = null,
    val role: String = "All-Rounder",
    val battingHand: String = "Right-hand bat",
    val bowlingStyle: String = "Right-arm medium",
    val country: String = "",
    val dateOfBirth: String = "",
    val photoUri: String? = null,
    val currentTeamName: String = "",
    val previousTeams: String = "",
    val internationalCareerNote: String = "",
    val domesticCareerNote: String = "",
    val biography: String = "",
    val jerseyNumber: Int? = null,
    val dataSource: String = "Manual / Admin",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.LOCAL_ONLY.name
)

enum class CareerScopeType {
    FORMAT,
    LEAGUE
}

enum class CareerFormatScope(val key: String, val displayName: String, val shortLabel: String) {
    ALL_FORMAT("ALL_FORMAT", "All Format Career", "All"),
    TEST("TEST", "Test Career", "Test"),
    ODI("ODI", "ODI Career", "ODI"),
    T20I("T20I", "T20I Career", "T20I"),
    T20_LEAGUE("T20_LEAGUE", "T20 League Career", "T20L"),
    DOMESTIC("DOMESTIC", "Domestic Career", "Dom");

    companion object {
        val individualFormats = listOf(TEST, ODI, T20I, T20_LEAGUE, DOMESTIC)
        fun fromKey(key: String): CareerFormatScope? = entries.find { it.key == key }
    }
}

data class LeagueCatalogItem(
    val key: String,
    val displayName: String,
    val region: String
)

object MajorLeagueCatalog {
    val leagues = listOf(
        LeagueCatalogItem("IPL", "IPL", "India"),
        LeagueCatalogItem("BPL", "BPL", "Bangladesh"),
        LeagueCatalogItem("BBL", "BBL", "Australia"),
        LeagueCatalogItem("PSL", "PSL", "Pakistan"),
        LeagueCatalogItem("CPL", "CPL", "Caribbean"),
        LeagueCatalogItem("LPL", "LPL", "Sri Lanka"),
        LeagueCatalogItem("SA20", "SA20", "South Africa"),
        LeagueCatalogItem("ILT20", "ILT20", "UAE"),
        LeagueCatalogItem("GT20_CANADA", "Global T20 Canada", "Canada"),
        LeagueCatalogItem("CANADA_60", "Canada 60", "Canada"),
        LeagueCatalogItem("EUROPEAN_CRICKET_LEAGUE", "European Cricket League", "Europe"),
        LeagueCatalogItem("THE_HUNDRED", "The Hundred", "England"),
        LeagueCatalogItem("T20_BLAST", "T20 Blast", "England"),
        LeagueCatalogItem("SUPER_SMASH", "Super Smash", "New Zealand"),
        LeagueCatalogItem("ABU_DHABI_T10", "Abu Dhabi T10", "UAE")
    )
}

/**
 * Stores format-wise or tournament/league-wise career statistics for a player.
 * Numeric fields are intentionally nullable so missing/unrecorded statistics
 * render as "Not Available" instead of fabricating 0s.
 */
@Entity(
    tableName = "player_career_stats",
    indices = [
        Index(value = ["playerId"]),
        Index(value = ["playerId", "scopeType", "scopeKey"], unique = true)
    ]
)
data class PlayerCareerStatEntity(
    @PrimaryKey val id: String,
    val playerId: String,
    val scopeType: String, // CareerScopeType.name
    val scopeKey: String,  // CareerFormatScope.key or League key
    val scopeDisplayName: String,

    // Batting Career Statistics (all nullable for strict Not Available handling)
    val battingMatches: Int? = null,
    val battingInnings: Int? = null,
    val runsScored: Int? = null,
    val ballsFaced: Int? = null,
    val highestScore: Int? = null,
    val highestScoreNotOut: Boolean = false,
    val notOuts: Int? = null,
    val fours: Int? = null,
    val sixes: Int? = null,
    val hundreds: Int? = null,
    val fifties: Int? = null,
    val doubleHundreds: Int? = null,
    val ducks: Int? = null,
    val explicitBattingAverage: Double? = null,
    val explicitStrikeRate: Double? = null,

    // Bowling Career Statistics (all nullable)
    val bowlingMatches: Int? = null,
    val bowlingInnings: Int? = null,
    val ballsBowled: Int? = null,
    val wicketsTaken: Int? = null,
    val runsConceded: Int? = null,
    val bestBowlingWickets: Int? = null,
    val bestBowlingRuns: Int? = null,
    val fourWicketHauls: Int? = null,
    val fiveWicketHauls: Int? = null,
    val tenWicketMatches: Int? = null,
    val explicitBowlingAverage: Double? = null,
    val explicitEconomyRate: Double? = null,
    val explicitBowlingStrikeRate: Double? = null,

    // Fielding Statistics (all nullable)
    val catches: Int? = null,
    val runOuts: Int? = null,
    val stumpings: Int? = null,

    // Career Records & Honours (nullable)
    val highestPartnership: Int? = null,
    val playerOfMatchAwards: Int? = null,

    // Data Accuracy & Provenance
    val sourceLabel: String = "Manual / Admin",
    val lastUpdatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.LOCAL_ONLY.name
)

/**
 * Deduplication ledger guaranteeing that the same match's statistics
 * are never added twice to the same player + scope.
 */
@Entity(
    tableName = "player_match_ledger",
    indices = [
        Index(value = ["playerId", "matchId", "scopeKey"], unique = true)
    ]
)
data class PlayerMatchContributionEntity(
    @PrimaryKey val entryId: String, // "$playerId::$matchId::$scopeKey"
    val playerId: String,
    val matchId: String,
    val matchTitle: String,
    val scopeType: String,
    val scopeKey: String,
    val sourceLabel: String,
    val recordedAt: Long = System.currentTimeMillis()
)

enum class MatchFormat(val label: String, val defaultOvers: Int) {
    T10("T10", 10),
    T20("T20", 20),
    ODI("ODI", 50),
    TEST("Test", 90),
    CUSTOM("Custom", 15)
}

enum class MatchStatus {
    UPCOMING,
    LIVE,
    COMPLETED
}

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey val id: String,
    val title: String,
    val teamAId: String,
    val teamBId: String,
    val format: String = MatchFormat.T20.name,
    val oversPerInnings: Int = 20,
    val status: String = MatchStatus.UPCOMING.name,
    val venue: String = "",
    val tournamentId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.LOCAL_ONLY.name
)

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey val id: String,
    val name: String,
    val format: String = MatchFormat.T20.name,
    val teamCapacity: Int = 20,
    val oversPerInnings: Int = 20,
    val status: String = "DRAFT",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.LOCAL_ONLY.name
)

enum class FavouriteType {
    TEAM,
    PLAYER,
    LEAGUE,
    MATCH
}

@Entity(
    tableName = "user_accounts",
    indices = [Index(value = ["emailOrHandle"], unique = true)]
)
data class UserAccountEntity(
    @PrimaryKey val userId: String,
    val fullName: String,
    val emailOrHandle: String,
    val bio: String = "",
    val cityOrPhone: String = "",
    val photoUri: String? = null,
    val passwordHash: String,
    val passwordSalt: String,
    val recoveryCodeHash: String,
    val recoveryCodeSalt: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.PENDING_SYNC.name
)

@Entity(tableName = "user_personal_settings")
data class UserPersonalSettingsEntity(
    @PrimaryKey val userId: String,
    val languageCode: String = "en", // "en" or "bn"
    val themeMode: String = "SYSTEM", // "SYSTEM", "DARK", "LIGHT"
    val notificationsEnabled: Boolean = false,
    val matchStartAlerts: Boolean = true,
    val wicketAlerts: Boolean = false,
    val milestoneAlerts: Boolean = false,
    val profilePrivate: Boolean = true,
    val analyticsOptIn: Boolean = false,
    val autoSyncWhenOnline: Boolean = true,
    val lastSyncedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.PENDING_SYNC.name
)

@Entity(
    tableName = "user_favourites",
    indices = [
        Index(value = ["userId"]),
        Index(value = ["userId", "itemType", "itemKey"], unique = true)
    ]
)
data class UserFavouriteEntity(
    @PrimaryKey val id: String, // "${userId}::${itemType}::${itemKey}"
    val userId: String,
    val itemType: String, // FavouriteType.name
    val itemKey: String,
    val displayName: String,
    val subtitle: String = "",
    val matchAlertsEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val syncStatus: String = SyncStatus.PENDING_SYNC.name
)

