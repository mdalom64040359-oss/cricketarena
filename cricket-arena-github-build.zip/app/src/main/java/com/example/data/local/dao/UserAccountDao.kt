package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entity.UserAccountEntity
import com.example.data.local.entity.UserFavouriteEntity
import com.example.data.local.entity.UserPersonalSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserAccountDao {
    @Query("SELECT * FROM user_accounts WHERE emailOrHandle = :normalizedHandle LIMIT 1")
    suspend fun findByHandle(normalizedHandle: String): UserAccountEntity?

    @Query("SELECT * FROM user_accounts WHERE userId = :userId LIMIT 1")
    fun observeAccount(userId: String): Flow<UserAccountEntity?>

    @Query("SELECT * FROM user_accounts WHERE userId = :userId LIMIT 1")
    suspend fun getAccount(userId: String): UserAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccount(account: UserAccountEntity)

    @Query("SELECT * FROM user_personal_settings WHERE userId = :userId LIMIT 1")
    fun observeSettings(userId: String): Flow<UserPersonalSettingsEntity?>

    @Query("SELECT * FROM user_personal_settings WHERE userId = :userId LIMIT 1")
    suspend fun getSettings(userId: String): UserPersonalSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettings(settings: UserPersonalSettingsEntity)

    @Query("SELECT * FROM user_favourites WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeFavourites(userId: String): Flow<List<UserFavouriteEntity>>

    @Query("SELECT * FROM user_favourites WHERE userId = :userId")
    suspend fun getFavouritesOnce(userId: String): List<UserFavouriteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFavourite(fav: UserFavouriteEntity)

    @Query("DELETE FROM user_favourites WHERE id = :favId AND userId = :userId")
    suspend fun removeFavourite(favId: String, userId: String)

    @Query("DELETE FROM user_favourites WHERE userId = :userId")
    suspend fun deleteAllFavouritesForUser(userId: String)

    @Query("DELETE FROM user_personal_settings WHERE userId = :userId")
    suspend fun deleteSettingsForUser(userId: String)

    @Query("DELETE FROM user_accounts WHERE userId = :userId")
    suspend fun deleteAccountForUser(userId: String)

    @Transaction
    suspend fun deleteUserAccountCascade(userId: String) {
        deleteAllFavouritesForUser(userId)
        deleteSettingsForUser(userId)
        deleteAccountForUser(userId)
    }
}
