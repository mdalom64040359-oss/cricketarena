package com.example.data.sync

/**
 * Sync status attached to every locally persisted entity so the app works
 * 100% offline-first while staying structurally ready for optional future cloud sync.
 */
enum class SyncStatus {
    LOCAL_ONLY,
    PENDING_SYNC,
    SYNCED
}

enum class SyncConnectionState {
    OFFLINE_LOCAL_MODE,
    SYNC_READY,
    SYNCING
}

data class OfflineStorageStatus(
    val engineName: String = "Local Arena Storage",
    val isOfflineReady: Boolean = true,
    val syncState: SyncConnectionState = SyncConnectionState.OFFLINE_LOCAL_MODE,
    val pendingSyncCount: Int = 0
)

/**
 * Contract for optional future cloud synchronization providers (no network required for local use).
 */
interface CloudSyncAdapter {
    val isConfigured: Boolean
    suspend fun pushPendingChanges(): Result<Int>
    suspend fun pullRemoteUpdates(): Result<Int>
}

class LocalOnlySyncAdapter : CloudSyncAdapter {
    override val isConfigured: Boolean = false
    override suspend fun pushPendingChanges(): Result<Int> = Result.success(0)
    override suspend fun pullRemoteUpdates(): Result<Int> = Result.success(0)
}
