package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.TeamEntity
import com.example.data.local.entity.TournamentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ArenaDao {
    @Query("SELECT COUNT(*) FROM teams")
    fun observeTeamCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM players")
    fun observePlayerCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM matches")
    fun observeMatchCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM matches WHERE status = 'LIVE'")
    fun observeLiveMatchCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tournaments")
    fun observeTournamentCount(): Flow<Int>

    @Query("SELECT * FROM matches WHERE status = 'LIVE' ORDER BY updatedAt DESC")
    fun observeLiveMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches ORDER BY updatedAt DESC")
    fun observeAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM teams ORDER BY name ASC")
    fun observeAllTeams(): Flow<List<TeamEntity>>

    @Query("SELECT * FROM players ORDER BY fullName ASC")
    fun observeAllPlayers(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM tournaments ORDER BY updatedAt DESC")
    fun observeAllTournaments(): Flow<List<TournamentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTeam(team: TeamEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlayer(player: PlayerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMatch(match: MatchEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTournament(tournament: TournamentEntity)
}
