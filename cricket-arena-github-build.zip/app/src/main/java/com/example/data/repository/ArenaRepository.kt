package com.example.data.repository

import com.example.data.local.dao.ArenaDao
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.local.entity.TeamEntity
import com.example.data.local.entity.TournamentEntity
import com.example.data.sync.CloudSyncAdapter
import com.example.data.sync.LocalOnlySyncAdapter
import com.example.data.sync.OfflineStorageStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class ArenaOverviewCounts(
    val teamCount: Int = 0,
    val playerCount: Int = 0,
    val matchCount: Int = 0,
    val liveMatchCount: Int = 0,
    val tournamentCount: Int = 0
)

interface ArenaRepository {
    fun observeOverviewCounts(): Flow<ArenaOverviewCounts>
    fun observeLiveMatches(): Flow<List<MatchEntity>>
    fun observeAllMatches(): Flow<List<MatchEntity>>
    fun observeAllTeams(): Flow<List<TeamEntity>>
    fun observeAllPlayers(): Flow<List<PlayerEntity>>
    fun observeAllTournaments(): Flow<List<TournamentEntity>>
    fun getOfflineStorageStatus(): OfflineStorageStatus
}

class OfflineFirstArenaRepository(
    private val dao: ArenaDao,
    private val syncAdapter: CloudSyncAdapter = LocalOnlySyncAdapter()
) : ArenaRepository {

    override fun observeOverviewCounts(): Flow<ArenaOverviewCounts> {
        return combine(
            dao.observeTeamCount(),
            dao.observePlayerCount(),
            dao.observeMatchCount(),
            dao.observeLiveMatchCount(),
            dao.observeTournamentCount()
        ) { teams, players, matches, liveMatches, tournaments ->
            ArenaOverviewCounts(
                teamCount = teams,
                playerCount = players,
                matchCount = matches,
                liveMatchCount = liveMatches,
                tournamentCount = tournaments
            )
        }
    }

    override fun observeLiveMatches(): Flow<List<MatchEntity>> = dao.observeLiveMatches()

    override fun observeAllMatches(): Flow<List<MatchEntity>> = dao.observeAllMatches()

    override fun observeAllTeams(): Flow<List<TeamEntity>> = dao.observeAllTeams()

    override fun observeAllPlayers(): Flow<List<PlayerEntity>> = dao.observeAllPlayers()

    override fun observeAllTournaments(): Flow<List<TournamentEntity>> = dao.observeAllTournaments()

    override fun getOfflineStorageStatus(): OfflineStorageStatus {
        return OfflineStorageStatus(
            engineName = "On-Device SQLite (Offline-First)",
            isOfflineReady = true,
            syncState = if (syncAdapter.isConfigured) {
                com.example.data.sync.SyncConnectionState.SYNC_READY
            } else {
                com.example.data.sync.SyncConnectionState.OFFLINE_LOCAL_MODE
            }
        )
    }
}
