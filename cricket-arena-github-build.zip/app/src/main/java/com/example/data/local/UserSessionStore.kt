package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sessionDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "cricket_arena_session"
)

interface SessionStorage {
    val activeUserId: Flow<String?>
    suspend fun setActiveUserId(userId: String?)
}

/**
 * Persists only the currently active User ID across app restarts.
 * Never stores passwords or another user's private settings.
 */
class UserSessionStore(private val context: Context) : SessionStorage {
    private val activeUserIdKey = stringPreferencesKey("active_user_id")

    override val activeUserId: Flow<String?> = context.sessionDataStore.data.map { prefs ->
        prefs[activeUserIdKey]
    }

    override suspend fun setActiveUserId(userId: String?) {
        context.sessionDataStore.edit { prefs ->
            if (userId.isNullOrBlank()) {
                prefs.remove(activeUserIdKey)
            } else {
                prefs[activeUserIdKey] = userId
            }
        }
    }
}
