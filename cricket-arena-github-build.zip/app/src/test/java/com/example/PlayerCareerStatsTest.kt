package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CricketArenaDatabase
import com.example.data.local.entity.CareerFormatScope
import com.example.data.local.entity.CareerScopeType
import com.example.data.local.entity.PlayerCareerStatEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.repository.MatchContributionResult
import com.example.data.repository.MatchStatDelta
import com.example.data.repository.OfflinePlayerCareerRepository
import com.example.domain.CareerStatsCalculator
import com.example.domain.NOT_AVAILABLE
import com.example.domain.PlayerJsonCodec
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PlayerCareerStatsTest {

    private lateinit var database: CricketArenaDatabase
    private lateinit var repository: OfflinePlayerCareerRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, CricketArenaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = OfflinePlayerCareerRepository(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `missing stats return Not Available instead of zero`() {
        val computedBat = CareerStatsCalculator.computeBatting(null)
        val computedBowl = CareerStatsCalculator.computeBowling(null)
        val computedField = CareerStatsCalculator.computeFielding(null)

        assertEquals(NOT_AVAILABLE, computedBat.runsText)
        assertEquals(NOT_AVAILABLE, computedBat.averageText)
        assertEquals(NOT_AVAILABLE, computedBowl.wicketsText)
        assertEquals(NOT_AVAILABLE, computedField.totalDismissalsText)
    }

    @Test
    fun `batting and bowling metrics calculate accurately`() {
        val stat = PlayerCareerStatEntity(
            id = "p1_FORMAT_ODI",
            playerId = "p1",
            scopeType = CareerScopeType.FORMAT.name,
            scopeKey = CareerFormatScope.ODI.key,
            scopeDisplayName = CareerFormatScope.ODI.displayName,
            battingMatches = 12,
            battingInnings = 12,
            runsScored = 500,
            ballsFaced = 500,
            highestScore = 112,
            highestScoreNotOut = true,
            notOuts = 2,
            bowlingMatches = 12,
            bowlingInnings = 10,
            ballsBowled = 600, // 100.0 overs
            wicketsTaken = 20,
            runsConceded = 450,
            bestBowlingWickets = 5,
            bestBowlingRuns = 28
        )

        val bat = CareerStatsCalculator.computeBatting(stat)
        val bowl = CareerStatsCalculator.computeBowling(stat)

        assertEquals("50.00", bat.averageText)
        assertEquals("100.00", bat.strikeRateText)
        assertEquals("112*", bat.highestScoreText)
        assertEquals("22.50", bowl.averageText)
        assertEquals("4.50", bowl.economyText)
        assertEquals("30.00", bowl.strikeRateText)
        assertEquals("5/28", bowl.bestBowlingText)
        assertEquals("100.0 ov (600 balls)", bowl.oversAndBallsText)
    }

    @Test
    fun `duplicate match contribution is blocked by ledger`() = runTest {
        val player = PlayerEntity(id = "player-1", fullName = "Shakib Test")
        repository.savePlayer(player)

        val delta = MatchStatDelta(
            matchId = "MATCH-99",
            matchTitle = "Final",
            scopeType = CareerScopeType.FORMAT.name,
            scopeKey = CareerFormatScope.T20I.key,
            scopeDisplayName = CareerFormatScope.T20I.displayName,
            sourceLabel = "Test Scorer",
            batted = true,
            runsScored = 65,
            ballsFaced = 40,
            fours = 6,
            sixes = 3,
            bowled = true,
            ballsBowled = 24,
            wicketsTaken = 2,
            runsConceded = 22
        )

        val first = repository.applyMatchContribution(player.id, delta)
        val second = repository.applyMatchContribution(player.id, delta)

        assertTrue(first is MatchContributionResult.Applied)
        assertTrue(second is MatchContributionResult.DuplicateBlocked)

        val stats = repository.observeStatsForPlayer(player.id).first()
        assertEquals(1, stats.size)
        assertEquals(65, stats.first().runsScored)
        assertEquals(2, stats.first().wicketsTaken)
        assertEquals(1, stats.first().battingMatches)
    }

    @Test
    fun `json import parses partial stats cleanly without inventing zeros`() {
        val json = """
            {
              "fullName": "Tamim Sample",
              "country": "Bangladesh",
              "role": "Batter",
              "careerStats": [
                {
                  "scopeType": "LEAGUE",
                  "scopeKey": "BPL",
                  "scopeDisplayName": "BPL",
                  "battingMatches": 15,
                  "runsScored": 480
                }
              ]
            }
        """.trimIndent()

        val result = PlayerJsonCodec.parsePlayerImportJson(json)
        assertTrue(result.isSuccess)
        val bundle = result.getOrThrow()
        assertEquals("Tamim Sample", bundle.player.fullName)
        assertEquals(480, bundle.stats.first().runsScored)
        assertEquals(null, bundle.stats.first().wicketsTaken)
        assertEquals(null, bundle.stats.first().ballsFaced)
    }

    @Test
    fun `player biography and role persist in Room and JSON codec`() = runTest {
        val player = PlayerEntity(
            id = "bio-1",
            fullName = "Mustafiz Test",
            role = "Bowler",
            biography = "Left-arm seam bowler known for off-cutters."
        )
        repository.savePlayer(player)

        val loaded = repository.observePlayerById("bio-1").first()
        assertEquals("Bowler", loaded?.role)
        assertEquals("Left-arm seam bowler known for off-cutters.", loaded?.biography)

        val exportedJson = PlayerJsonCodec.exportPlayerJson(loaded!!, emptyList())
        val reimported = PlayerJsonCodec.parsePlayerImportJson(exportedJson).getOrThrow()
        assertEquals("Left-arm seam bowler known for off-cutters.", reimported.player.biography)
    }
}
