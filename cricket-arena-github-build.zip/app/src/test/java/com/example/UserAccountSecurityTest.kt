package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CricketArenaDatabase
import com.example.data.local.SessionStorage
import com.example.data.local.entity.FavouriteType
import com.example.data.local.entity.PlayerEntity
import com.example.data.repository.OfflineFirstUserAccountRepository
import com.example.data.security.PasswordHasher
import com.example.domain.PersonalBackupCodec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class InMemorySessionStorage : SessionStorage {
    private val state = MutableStateFlow<String?>(null)
    override val activeUserId: Flow<String?> = state
    override suspend fun setActiveUserId(userId: String?) {
        state.value = userId
    }
    fun currentId(): String? = state.value
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UserAccountSecurityTest {

    private lateinit var database: CricketArenaDatabase
    private lateinit var sessionStorage: InMemorySessionStorage
    private lateinit var repository: OfflineFirstUserAccountRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, CricketArenaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        sessionStorage = InMemorySessionStorage()
        repository = OfflineFirstUserAccountRepository(database, sessionStorage)
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `password hasher creates salted hashes and verifies accurately`() {
        val first = PasswordHasher.hashSecret("Cricket2026!")
        val second = PasswordHasher.hashSecret("Cricket2026!")

        assertNotEquals(first.saltBase64, second.saltBase64)
        assertNotEquals(first.hashBase64, second.hashBase64)

        assertTrue(PasswordHasher.verifySecret("Cricket2026!", first.hashBase64, first.saltBase64))
        assertTrue(PasswordHasher.verifySecret("Cricket2026!", second.hashBase64, second.saltBase64))
        assertFalse(PasswordHasher.verifySecret("WrongPass", first.hashBase64, first.saltBase64))
    }

    @Test
    fun `signUp creates unique userId, rejects duplicates, and supports login logout recovery`() = runBlocking {
        val user1 = repository.signUp(
            fullName = "Arif Hasan",
            emailOrHandle = "arif@cricket.local",
            password = "secret123",
            recoveryCode = "dhaka99",
            cityOrPhone = "Dhaka",
            bio = "Opening batter",
            photoUri = null
        ).getOrThrow()

        assertTrue(user1.userId.startsWith("USR-"))
        assertEquals(user1.userId, sessionStorage.currentId())

        // Duplicate handle rejected
        val dup = repository.signUp(
            fullName = "Another Arif",
            emailOrHandle = "ARIF@cricket.local",
            password = "otherPassword",
            recoveryCode = "code1234",
            cityOrPhone = "",
            bio = "",
            photoUri = null
        )
        assertTrue(dup.isFailure)

        // Logout clears session
        repository.logout()
        assertNull(sessionStorage.currentId())

        // Wrong password rejected
        assertTrue(repository.login("arif@cricket.local", "wrongpass").isFailure)

        // Recovery code reset password
        assertTrue(repository.resetPasswordWithRecovery("arif@cricket.local", "badcode", "newPass123").isFailure)
        assertTrue(repository.resetPasswordWithRecovery("arif@cricket.local", "dhaka99", "newPass123").isSuccess)

        // Old password fails, new password succeeds
        assertTrue(repository.login("arif@cricket.local", "secret123").isFailure)
        val loggedIn = repository.login("arif@cricket.local", "newPass123").getOrThrow()
        assertEquals(user1.userId, loggedIn.userId)
    }

    @Test
    fun `personal settings, language, and favourites are strictly isolated per user`() = runBlocking {
        val userA = repository.signUp(
            fullName = "User Alpha",
            emailOrHandle = "alpha",
            password = "passA123",
            recoveryCode = "recA",
            cityOrPhone = "Sylhet",
            bio = "Fast bowler",
            photoUri = null
        ).getOrThrow()

        repository.updateSettings(userA.userId) {
            it.copy(languageCode = "bn", themeMode = "DARK", notificationsEnabled = true)
        }
        repository.addOrUpdateFavourite(userA.userId, FavouriteType.TEAM, "tigers", "Bangladesh Tigers", "National")
        repository.addOrUpdateFavourite(userA.userId, FavouriteType.LEAGUE, "BPL", "BPL", "Bangladesh")

        val bundleA = repository.observeActiveUserBundle().first()
        assertNotNull(bundleA)
        assertEquals("bn", bundleA!!.settings.languageCode)
        assertEquals(2, bundleA.favourites.size)

        // Create User B -> switches active session to User B
        val userB = repository.signUp(
            fullName = "User Beta",
            emailOrHandle = "beta",
            password = "passB123",
            recoveryCode = "recB",
            cityOrPhone = "Chattogram",
            bio = "Wicketkeeper",
            photoUri = null
        ).getOrThrow()

        assertNotEquals(userA.userId, userB.userId)

        val bundleB = repository.observeActiveUserBundle().first()
        assertNotNull(bundleB)
        assertEquals(userB.userId, bundleB!!.account.userId)
        assertEquals("en", bundleB.settings.languageCode) // User B starts clean in English
        assertEquals(0, bundleB.favourites.size) // User A's favourites are invisible to User B

        // Cross-user alert toggle attempt by User B on User A's favourite must fail
        val favAId = "${userA.userId}::TEAM::tigers"
        assertTrue(repository.toggleFavouriteMatchAlert(userB.userId, favAId, false).isFailure)
    }

    @Test
    fun `personal backup excludes password hashes and restores strictly for owning user`() = runBlocking {
        val user = repository.signUp(
            fullName = "Nadia Rahman",
            emailOrHandle = "nadia",
            password = "myStrongPassword",
            recoveryCode = "recNadia",
            cityOrPhone = "Khulna",
            bio = "All-rounder",
            photoUri = null
        ).getOrThrow()

        repository.updateSettings(user.userId) {
            it.copy(languageCode = "bn", themeMode = "DARK", wicketAlerts = true)
        }
        repository.addOrUpdateFavourite(user.userId, FavouriteType.PLAYER, "shakib", "Shakib Al Hasan", "Bangladesh")

        val exported = repository.exportPersonalBackupJson(user.userId).getOrThrow()
        assertFalse(exported.contains("passwordHash"))
        assertFalse(exported.contains("passwordSalt"))
        assertFalse(exported.contains("myStrongPassword"))
        assertTrue(exported.contains("Shakib Al Hasan"))

        // Clear favourites and switch language back to English, then restore
        repository.clearAllFavourites(user.userId)
        repository.updateSettings(user.userId) { it.copy(languageCode = "en", themeMode = "SYSTEM") }

        val restoredCount = repository.restorePersonalBackupJson(user.userId, exported).getOrThrow()
        assertEquals(1, restoredCount)

        val bundle = repository.observeActiveUserBundle().first()!!
        assertEquals("bn", bundle.settings.languageCode)
        assertEquals("DARK", bundle.settings.themeMode)
        assertEquals("Shakib Al Hasan", bundle.favourites.single().displayName)

        // Invalid JSON fails cleanly
        assertTrue(PersonalBackupCodec.parseAndValidateBackup("not json", user.userId).isFailure)
    }

    @Test
    fun `deleteMyAccount removes only target user and keeps other users and cricket data safe`() = runBlocking {
        database.arenaDao().upsertPlayer(
            PlayerEntity(
                id = "player-1",
                fullName = "Tamim Iqbal",
                country = "Bangladesh",
                role = "Batter"
            )
        )

        val user1 = repository.signUp("First User", "first_user", "pwd1111", "rec1", "", "", null).getOrThrow()
        repository.addOrUpdateFavourite(user1.userId, FavouriteType.PLAYER, "player-1", "Tamim Iqbal", "Bangladesh")

        val user2 = repository.signUp("Second User", "second_user", "pwd2222", "rec2", "", "", null).getOrThrow()
        repository.addOrUpdateFavourite(user2.userId, FavouriteType.LEAGUE, "IPL", "IPL", "India")

        // Delete User 1 with wrong password -> fails
        assertTrue(repository.deleteMyAccount(user1.userId, "wrong").isFailure)
        // Delete User 1 with right password -> succeeds
        assertTrue(repository.deleteMyAccount(user1.userId, "pwd1111").isSuccess)

        val dao = database.userAccountDao()
        assertNull(dao.getAccount(user1.userId))
        assertNull(dao.getSettings(user1.userId))
        assertEquals(0, dao.getFavouritesOnce(user1.userId).size)

        // User 2 and shared Cricket Arena player record remain intact
        assertNotNull(dao.getAccount(user2.userId))
        assertEquals(1, dao.getFavouritesOnce(user2.userId).size)
        assertNotNull(database.arenaDao().observeAllPlayers().first().find { it.id == "player-1" })
    }
}
