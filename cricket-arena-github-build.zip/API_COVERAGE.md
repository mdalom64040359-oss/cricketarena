# Cricket Arena — API Coverage Matrix
সর্বশেষ আপডেট: 18 November 2026

## মূল নীতি
- কোনো ডেটা-প্রোভাইডার যুক্ত না থাকলে অ্যাপ কখনোই ভুয়া লাইভ স্কোর, ভুয়া ফিকচার বা ভুয়া খেলোয়াড়ের তথ্য দেখাবে না।
- প্রতিটি প্রতিযোগিতার পাশে বাস্তব Coverage Status দেখানো হবে: `Fixtures`, `Live Scores`, `Ball-by-ball`, `Squads`, `Players`, `Stats`।
- API-তে তথ্য না থাকলে Admin ম্যানুয়ালি League, Season, Team, Squad, Player ও Fixture যোগ করতে পারবেন।

## বর্তমান API প্রোভাইডার অবস্থা
- **সক্রিয় প্রোভাইডার:** নেই (Player Career পরিসংখ্যানের জন্য Manual Entry ও JSON Import চালু আছে; কোনো ভুয়া API ডেটা ব্যবহার করা হয় না)
- **API Key অবস্থান:** ব্যবহার করা হলে শুধু server-side secret/environment-এ রাখা হবে (অ্যাপ কোড বা রিপোজিটরিতে নয়)।

## পরিকল্পিত Global Cricket Hub প্রতিযোগিতা ও বর্তমান স্ট্যাটাস

| অঞ্চল / ধরন | প্রতিযোগিতা | বর্তমান স্ট্যাটাস |
|---|---|---|
| আন্তর্জাতিক (পুরুষ/নারী) | Test, ODI, T20I, Bilateral, ICC Events | API যুক্ত নয় — Player Career Manual/JSON Active |
| ভারত / এশিয়া | IPL, WPL, BPL, PSL, LPL | API যুক্ত নয় — Player Career Manual/JSON Active |
| অস্ট্রেলিয়া / নিউজিল্যান্ড | BBL, WBBL, Sheffield Shield, Super Smash | API যুক্ত নয় — Player Career Manual/JSON Active |
| ক্যারিবিয়ান / আফ্রিকা / মধ্যপ্রাচ্য / আমেরিকা | CPL, SA20, ILT20, Abu Dhabi T10, MLC, Global T20 Canada, Canada 60 | API যুক্ত নয় — Player Career Manual/JSON Active |
| ইংল্যান্ড ও ইউরোপ | The Hundred, T20 Blast, County Championship, ECL, ECC, ECS, Italy T10, Belgium Leagues | API যুক্ত নয় — Player Career Manual/JSON Active |
