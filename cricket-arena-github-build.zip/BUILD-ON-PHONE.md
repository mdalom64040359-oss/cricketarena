# Build Cricket Arena APK using an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.
It builds a debug APK on GitHub's hosted runner, so the Android phone does not need to run Gradle.

## Steps
1. Sign in to GitHub in Chrome and create a new **private** repository (recommended).
2. Upload the contents of this ZIP to the repository's main branch. Make sure the `.github/workflows/android-apk.yml` file is included. If the GitHub mobile upload page hides dot-folders, use the browser's **Desktop site** option.
3. Open the repository's **Actions** tab.
4. Select **Build Cricket Arena APK** and tap **Run workflow** (or wait for the first push build to finish).
5. Open the completed workflow run, scroll to **Artifacts**, and download `Cricket-Arena-debug-apk`.
6. Extract the downloaded artifact ZIP, tap the APK, and allow Chrome/Files to install unknown apps if Android asks.

The workflow creates a **debug APK** for testing. It is not a Play Store release build. Do not publish API keys or secrets in the repository. If the app needs a Gemini API key at runtime, configure it securely rather than committing a real key.
