# Cricket Arena — স্থায়ী Project Master Document
সংস্করণ: 1.0
তারিখ: 17 November 2026
প্রজেক্ট রানটাইম নোট (18 November 2026): বর্তমান AI Studio প্রজেক্টটি **Native Android (Kotlin + Jetpack Compose + Room SQLite)** পরিবেশে নির্মিত। অফলাইন স্টোরেজের জন্য ব্রাউজারের IndexedDB-এর পরিবর্তে Android-এর নিজস্ব **Room (SQLite)** ব্যবহার করা হয়েছে।

এই ডকুমেন্টটি Cricket Arena অ্যাপের মূল পরিকল্পনা, বর্তমান সিদ্ধান্ত, ফিচার, প্রযুক্তিগত নিয়ম এবং ভবিষ্যৎ আপডেটের নির্দেশনা সংরক্ষণের জন্য তৈরি। এটি Google AI Studio-তে আপলোড/পেস্ট করে ভবিষ্যতে অ্যাপ আপডেটের সময় রেফারেন্স হিসেবে ব্যবহার করা যাবে।

## 1. প্রজেক্ট পরিচিতি
- অ্যাপের নাম: Cricket Arena
- লক্ষ্য: স্থানীয় ক্রিকেট ম্যাচ, টুর্নামেন্ট এবং আন্তর্জাতিক ক্রিকেট/ফ্র্যাঞ্চাইজি লিগের তথ্য এক জায়গায় দেখা ও পরিচালনা করা।
- প্ল্যাটফর্ম: বর্তমান বিল্ড — Native Android App (Kotlin + Jetpack Compose); ভবিষ্যতে প্রয়োজন হলে Web/PWA সংস্করণ আলাদাভাবে বিবেচনা করা যাবে।
- ব্যবহারকারী: সাধারণ ব্যবহারকারী; প্রয়োজন হলে আলাদা Admin সুবিধা।
- ব্যবহার সহজ, পরিষ্কার এবং Android ফোনে ভালোভাবে কাজ করতে হবে।
- ভাষা: বাংলা ও English—দুই ভাষার ব্যবস্থা রাখা ভালো।

## 2. মূল নীতি
1. বিদ্যমান প্রজেক্ট, ডিজাইন, ফিচার ও ডেটা না বুঝে কখনো মুছে বা নতুন করে তৈরি করবে না।
2. প্রতিটি আপডেটের আগে বর্তমান প্রজেক্ট পরীক্ষা করবে এবং কী পরিবর্তন দরকার তা সংক্ষেপে জানাবে।
3. ব্যবহারকারীর অনুমতি ছাড়া বড় পরিবর্তন, ডেটাবেস মুছে ফেলা, ডেটা ফরম্যাট বদলানো বা কাজ করা ফিচার সরাবে না।
4. প্রতিটি আপডেটের পরে কী কী বদলেছে, কোন ফাইল/অংশ বদলেছে, কীভাবে পরীক্ষা করতে হবে—সহজ বাংলায় CHANGELOG লিখবে।
5. অ্যাপের সম্পূর্ণ প্রযুক্তিগত ও ব্যবহারকারী-সংক্রান্ত ডকুমেন্টেশন নিয়মিত আপডেট করবে।
6. বাস্তবে API থেকে পাওয়া নয় এমন কোনো লাইভ স্কোর, ফিকচার, খেলোয়াড় বা পরিসংখ্যান বানিয়ে দেখাবে না।
7. কোনো API বা সার্ভিসের কভারেজ না থাকলে “তথ্য পাওয়া যাচ্ছে না/ম্যানুয়ালি যোগ করুন” দেখাবে; ভুয়া লাইভ তথ্য নয়।
8. ব্যবহারকারীর API key, password বা secret কখনো public frontend code, screenshot, বা repository-তে প্রকাশ করবে না।

## 3. ক্রিকেট ফরম্যাট
- T10
- T20
- ODI
- Test
- Custom Overs

## 4. Local Match Scoring
- দুই দলের নাম, লোগো, খেলোয়াড় তালিকা ও অধিনায়ক।
- টস, ব্যাটিং/বোলিং দল, ইনিংস এবং ম্যাচের অবস্থা।
- বল-বাই-বল রান, উইকেট, অতিরিক্ত রান, ওভার ও বল।
- স্ট্রাইকার/নন-স্ট্রাইকার, বোলার, ওভার পরিবর্তন।
- ব্যাটিং ও বোলিং স্কোরকার্ড।
- পার্টনারশিপ, Fall of Wickets, Target, Required Run Rate।
- Commentary এবং স্কোর সংশোধন/Undo।
- ম্যাচ শেষ হলে ফলাফল ও পূর্ণ স্কোরকার্ড সংরক্ষণ।

## 5. Team ও Player Management
- দল তৈরি/সম্পাদনা, লোগো, নাম, এলাকা ও বিবরণ।
- খেলোয়াড়ের নাম, ছবি, জার্সি নম্বর, ভূমিকা, ব্যাটিং/বোলিং ধরন।
- Captain ও Vice-captain।
- খেলোয়াড়ের ম্যাচ, রান, উইকেট ও অন্যান্য পরিসংখ্যান।
- একই খেলোয়াড়/দলের ডুপ্লিকেট এন্ট্রি এড়ানোর ব্যবস্থা।

## 6. Tournament Management
- কমপক্ষে ২০টি দল; ২০, ২৪, ৩২, ৪০, ৫০ বা তার বেশি দল সমর্থন।
- Round Robin, Groups, League, Knockout ও Hybrid format।
- স্বয়ংক্রিয় Fixture তৈরি এবং প্রয়োজন হলে হাতে সম্পাদনা।
- Points Table, Played, Won, Lost, Tied, No Result, Points, NRR।
- Tie-breaker, Qualifier, Playoff, Semi-final, Final ও Champion।
- Tournament-এর দল, খেলোয়াড়, ম্যাচ ও ফলাফল সংরক্ষণ।

## 7. Global Cricket Hub
আন্তর্জাতিক ক্রিকেট:
- আন্তর্জাতিক পুরুষ ও নারী দল।
- Test, ODI, T20I ম্যাচ।
- দ্বিপাক্ষিক সিরিজ, ICC ইভেন্ট এবং আঞ্চলিক প্রতিযোগিতা।
- Fixture, সময়সূচি, ফলাফল, স্কোয়াড, Playing XI ও ভেন্যু—যে তথ্য ডেটা-প্রোভাইডার দেয়।

ফ্র্যাঞ্চাইজি/ঘরোয়া লিগের উদাহরণ:
- IPL, WPL, BPL, BBL, WBBL
- PSL, LPL, CPL (Caribbean Premier League)
- SA20, ILT20, MLC
- The Hundred, T20 Blast, County Championship
- Sheffield Shield, Super Smash
- Abu Dhabi T10
- Global T20 Canada, Canada 60
- European Cricket League, European Cricket Championship, ECS
- Italy T10 এবং Belgium-এর প্রাসঙ্গিক প্রতিযোগিতা
- ভবিষ্যতে নতুন দেশ/লিগ যোগ করার সুবিধা।

গুরুত্বপূর্ণ:
- কোনো ডেটা-প্রোভাইডার সব দেশের সব লিগ, সব মৌসুম, সব স্কোয়াড বা বল-বাই-বল লাইভ কভার করে—এমন নিশ্চয়তা দেওয়া যাবে না।
- প্রতিটি প্রতিযোগিতার জন্য Coverage Status দেখাবে: Fixtures / Live Scores / Ball-by-ball / Squads / Players / Stats—কোনটি পাওয়া যায়।
- প্রতিযোগিতার নাম বা বানান অস্পষ্ট হলে অনুমান করে ভুল লিগ তৈরি করবে না; Admin-কে নিশ্চিত করতে বলবে।
- API-তে না থাকলে Admin যেন হাতে League, Season, Team, Squad, Player ও Fixture যোগ/সম্পাদনা করতে পারে।

## 8. Live Data ও API নিয়ম
- লাইভ তথ্যের জন্য অনুমোদিত ক্রিকেট ডেটা-প্রোভাইডারের API ব্যবহার করতে হবে।
- API key শুধু নিরাপদ server-side environment variable/secret storage-এ থাকবে।
- API key frontend bundle, public GitHub repository বা সাধারণ ডকুমেন্টে রাখা যাবে না।
- Provider integration এমনভাবে modular করতে হবে যেন ভবিষ্যতে provider বদলানো যায়।
- API rate limit, caching, retry, error handling এবং last-updated time দেখাতে হবে।
- API না চললে শেষবার সংরক্ষিত তথ্য দেখাবে এবং “শেষ আপডেট” সময় জানাবে।
- Provider-এর Terms, licensing ও data usage rules মানতে হবে।
- কোনো provider যুক্ত না থাকলে “Live” বলে দাবি করা যাবে না; manual scoring আলাদা থাকবে।

## 9. Offline ও Data Backup
- Local scoring ও tournament data অফলাইন-ফার্স্ট হিসেবে ডিভাইসের local database-এ (Android Room SQLite) সংরক্ষণের ব্যবস্থা।
- Export/Import Backup (JSON)।
- Backup restore করার আগে confirmation এবং data validation।
- একই ডিভাইসের offline data অন্য ডিভাইসে নিজে থেকে sync হবে না।
- ভবিষ্যতে নিরাপদ cloud sync যোগ করা যেতে পারে; conflict handling থাকতে হবে।

## 10. প্রযুক্তিগত দিকনির্দেশনা
- বর্তমান AI Studio প্রজেক্টের framework: **Native Android (Kotlin, Jetpack Compose, Material 3, Room SQLite, Navigation Compose)**।
- অকারণে প্রযুক্তি বদলানো যাবে না; প্রতিটি আপডেটের আগে বর্তমান প্রজেক্টের ফাইল ও আর্কিটেকচার পরীক্ষা করতে হবে।
- Secret/API keys থাকলে AI Studio Secrets / নিরাপদ backend proxy ব্যবহার করতে হবে।

## 11. Admin Panel
Admin যেন:
- League/competition ও season যোগ/সম্পাদনা/বন্ধ করতে পারে।
- Team, player, squad ও fixture হাতে যোগ/সম্পাদনা করতে পারে।
- API coverage এবং sync status দেখতে পারে।
- Fixture import/export করতে পারে।
- ভুল তথ্য সংশোধন করতে পারে।
- Backup তৈরি ও restore করতে পারে।
- প্রয়োজনীয় পরিবর্তনের audit/history দেখতে পারে।

## 12. ভবিষ্যৎ সম্ভাব্য ফিচার
- Live match centre ও ball-by-ball commentary (শুধু বৈধ API থাকলে)।
- News, rankings, records ও highlights (অনুমোদিত উৎস থেকে)।
- User accounts, favourites, notifications।
- Community features।
- Live video কেবল লাইসেন্স/অনুমোদিত সম্প্রচার উৎস থাকলে।

## 13. Google AI Studio-র জন্য স্থায়ী নির্দেশনা
নিচের নির্দেশনাটি প্রতিবার ভবিষ্যৎ আপডেটের সময় এই ডকুমেন্টের সঙ্গে ব্যবহার করতে হবে:

“তুমি Cricket Arena প্রজেক্টের ধারাবাহিক AI development assistant। প্রথমে সংযুক্ত Cricket Arena Master Document এবং বর্তমান project files পরীক্ষা করো। এই ডকুমেন্টকে project-এর স্থায়ী requirement ও decision reference হিসেবে ধরো, তবে বর্তমান code-ই বাস্তব implementation-এর source of truth। আগের কাজ না বুঝে কিছু মুছে ফেলবে না। প্রথমে বর্তমান অবস্থা, সম্পন্ন ফিচার, অসম্পূর্ণ ফিচার, known issues এবং প্রস্তাবিত পরিবর্তন সংক্ষেপে রিপোর্ট করো। আমি যে নির্দিষ্ট update চাই শুধু সেটিই implement করো; প্রয়োজন হলে আগে একটি পরিষ্কার প্রশ্ন করো। বিদ্যমান data ও backward compatibility রক্ষা করো। কোনো live data/API result বানিয়ে দেখাবে না। API key বা secret কখনো frontend/public code-এ রাখবে না। কাজ শেষে পরীক্ষা চালাও, পরিবর্তিত ফাইল/ফিচারের তালিকা, কীভাবে ব্যবহার করব, কী পরীক্ষা করা হয়েছে, কী বাকি আছে এবং পরবর্তী কাজসহ CHANGELOG.md ও PROJECT_STATUS.md আপডেট করো। এই Master Document-এ নতুন সিদ্ধান্ত বা requirement যোগ হলে version/date বাড়িয়ে সম্পূর্ণ updated copy তৈরি করে আমাকে Markdown (.md) এবং plain text (.txt) হিসেবে export করার উপায় দাও।”

## 14. প্রতিটি আপডেটের পর যে ডকুমেন্টগুলো রাখতে হবে
1. `CRICKET_ARENA_MASTER.md` — সম্পূর্ণ স্থায়ী পরিকল্পনা ও সিদ্ধান্ত।
2. `PROJECT_STATUS.md` — বর্তমানে কী তৈরি হয়েছে, কী বাকি।
3. `CHANGELOG.md` — প্রতিটি আপডেটের তারিখ ও পরিবর্তন।
4. `API_COVERAGE.md` — কোন লিগ/দেশে কোন API তথ্য পাওয়া যায়।
5. `DATA_BACKUP_GUIDE.md` — ব্যাকআপ নেওয়া ও ফিরিয়ে আনার নিয়ম।

## 15. নতুন আপডেটের আগে চেকলিস্ট
- [x] বর্তমান Master Document পড়া হয়েছে।
- [x] বর্তমান project files পরীক্ষা করা হয়েছে।
- [x] আগের feature/data অক্ষত রাখার পরিকল্পনা আছে।
- [x] API ও coverage যাচাই করা হয়েছে।
- [x] পরিবর্তনের পর পরীক্ষা করা হয়েছে।
- [x] CHANGELOG ও PROJECT_STATUS আপডেট হয়েছে।
- [x] Master Document প্রজেক্টে সংরক্ষিত হয়েছে।
