# Cricket Arena — CHANGELOG

## [v0.5.0] - 2026-11-18 (Modules 333–999 Complete & Automated QA Verified)
### কী পরিবর্তন ও ঠিক করা হয়েছে
- **নতুন ক্রিকেট রুল ইঞ্জিন (`web-pwa/engine.js`):** বল-ইভেন্ট থেকে স্বয়ংক্রিয় T10/T20/ODI/Test/Custom Overs গণনা, Free Hit আইন, মেইডেন ওভার, Test Follow-On (>=200 লিড), Declaration, Innings Victory, ৫-দিনের ড্র, ২০–৫০+ দলের ডুপ্লিকেট-মুক্ত ফিক্সচার, QF/SF/Final অগ্রগতি, অল-আউট পূর্ণ ওভার NRR ও ৯টি লিডারবোর্ড।
- **নিরবচ্ছিন্ন মোবাইল UI ও বাগ সংশোধন (`web-pwa/app.js`, `styles.css`, `sw.js`):**
  - `window.prompt()` সরিয়ে Android মোবাইল-বান্ধব ইনলাইন Wicket, Extras ও Fixture Result এডিটর যুক্ত।
  - Team rename ক্যাসকেড (দলের নাম বদলালে খেলোয়াড়ের দলের নামও হালনাগাদ) ও Team Search কার্সার ফোকাস বজায় রাখা।
  - Playing XI (১১ জন বাছাই) + ম্যাচ ক্যাপ্টেন ও উইকেটরক্ষক নির্বাচন এবং Team Roster-এ Edit Player সুবিধা।
  - Test Cricket ইনিন্স বিজয় লজিকে Follow-On ছাড়াও এক ইনিংসে বিপক্ষের দুই ইনিংস ছাড়িয়ে যাওয়ার কেস ঠিক করা হয়েছে।
- **অটোমেটেড QA টেস্ট (`web-pwa/tests/qa.test.mjs`):** ৮টি টেস্ট স্যুইট (`node --test`) সব পাস।

---

## [v0.4.0] - 2026-11-18 (Debug APK + Installable Website & PWA Edition)
### কী পরিবর্তন হয়েছে
- **বাস্তব Android Debug APK (`.build-outputs/app-debug.apk`):** `gradle :app:assembleDebug` দিয়ে পূর্ণাঙ্গ ও সাইনকৃত ইন্সটলযোগ্য Android ডিবাগ APK তৈরি করে প্রজেক্টের `.build-outputs/app-debug.apk` অবস্থানে সংরক্ষণ করা হয়েছে।
- **রেসপন্সিভ ওয়েবসাইট ও Installable PWA (`/web-pwa/`):**
  - `web-pwa/manifest.webmanifest` ও আসল PNG আইকন (`192x192`, `512x512`, `maskable`, `apple-touch-icon`) সহ ব্র্যান্ডেড Splash Screen।
  - `web-pwa/sw.js` ও `web-pwa/offline.html` — প্রথমবার লোডের পর সম্পূর্ণ অফলাইনে অ্যাপ চালু হওয়ার সুবিধা।
  - `web-pwa/index.html` ও `web-pwa/styles.css` — মোবাইল (Bottom Bar), ট্যাবলেট ও ডেস্কটপের (Left Rail) জন্য রেসপন্সিভ ডিজাইন, Accessible page titles (`document.title`), মেটাডাটা এবং পরিষ্কার Offline Indicator।
  - `web-pwa/db.js` ও `web-pwa/app.js` — ব্রাউজারের `IndexedDB`-তে লোকাল ডেটা সংরক্ষণ (ম্যাচ বল-বাই-বল স্কোরিং, দল, খেলোয়াড়, ২০–৫০+ দলের টুর্নামেন্ট ও NRR, User Account & Personal Control Panel, JSON ব্যাকআপ/রিস্টোর) এবং Android Chrome `beforeinstallprompt` ইনস্টল প্রম্পট।

---

## [v0.3.0] - 2026-11-18 (User Profile & Personal Control Panel)
### কী পরিবর্তন হয়েছে
- **নতুন User Account সিস্টেম (`UserAuthScreen` ও `UserAccountRepository`):** Sign Up, Login, Logout, Recovery Code-ভিত্তিক Forgot Password, প্রোফাইল ছবি (Photo Picker) এবং প্রত্যেক ব্যবহারকারীর স্বতন্ত্র User ID (`USR-XXXXXXXX`)।
- **Personal Control Panel (`PersonalControlPanelScreen`):** সাধারণ ব্যবহারকারীদের জন্য ব্যক্তিগত ড্যাশবোর্ড—My Profile, Edit Profile, Profile Picture Change, App Settings (থিম মোড ও অফলাইন/সিঙ্ক স্ট্যাটাস), Language Settings (বাংলা ও English), Notification Settings ও Match Notifications (`POST_NOTIFICATIONS` রানটাইম অনুমতিসহ), Favourite Teams/Players/Leagues/Matches, My Saved Data, Personal Backup & Restore (JSON Export/Import), Privacy Settings, Change Password, Delete My Account এবং Logout।
- **নিরাপত্তা ও ব্যক্তিগত ডেটা বিচ্ছিন্নতা:** PBKDF2WithHmacSHA256 সল্টেড হ্যাশিং (`PasswordHasher`), DataStore সেশন (`UserSessionStore`), এবং Room v4 (`MIGRATION_3_4` — পূর্বের কোনো ডেটা না হারিয়ে `user_accounts`, `user_personal_settings` ও `user_favourites` টেবিল)।
- **Player Profile থেকে সরাসরি Favourite:** যেকোনো খেলোয়াড়ের প্রোফাইল থেকে সরাসরি নিজের পছন্দের খেলোয়াড়ে যোগ/বাদ দেওয়ার হার্ট বাটন যুক্ত হয়েছে।

---

## [v0.2.1] - 2026-11-18 (PlayerProfile Component & Biography Support)
### কী পরিবর্তন হয়েছে
- **নতুন `PlayerProfile` কম্পোনেন্ট (`ui/components/PlayerProfile.kt`):** খেলোয়াড়ের ভূমিকা (Role), বায়োগ্রাফি, ক্যারিয়ার ব্যাকগ্রাউন্ড, ফরম্যাট/লিগ ফিল্টার এবং Batting, Bowling ও Fielding মেট্রিক্স সেকশনসহ একটি স্বতন্ত্র পুনর্ব্যবহারযোগ্য কম্পোনেন্ট তৈরি করা হয়েছে।
- **Room ডেটাবেস আপগ্রেড (`MIGRATION_2_3`):** `players` টেবিলে `biography` কলাম যুক্ত করে ডেটাবেস ভার্সন ৩-এ উন্নীত করা হয়েছে (পূর্বের কোনো ডেটা না হারিয়ে)।
- **এডিটর ও JSON কোডেক আপডেট:** প্রোফাইল এডিটর ও JSON Import/Export-এ `biography` যুক্ত করা হয়েছে।

---

## [v0.2.0] - 2026-11-18 (Player Career Statistics & Records System)
### কী পরিবর্তন হয়েছে
- **ডেটাবেস আপগ্রেড (`MIGRATION_1_2`):** `CricketArenaDatabase` ভার্সন ২-এ উন্নীত করা হয়েছে আগের ডেটা অক্ষত রেখে। `players` টেবিলে দেশ, জন্মতারিখ, ছবি (URI), বর্তমান/পূর্বের দল ও ক্যারিয়ার নোট যুক্ত হয়েছে এবং নতুন `player_career_stats` ও ডুপ্লিকেট-প্রতিরোধী `player_match_ledger` টেবিল যুক্ত হয়েছে।
- **Player Directory ও Profile Dashboard:** `PlayersDirectoryScreen` ও `PlayerProfileScreen` তৈরি করা হয়েছে—যেখানে ৬টি ফরম্যাট ট্যাব (`All Format, Test, ODI, T20I, T20 League, Domestic`), ফ্র্যাঞ্চাইজি লিগ (`IPL, BPL, BBL, PSL, CPL, LPL, SA20, ILT20, Global T20 Canada, Canada 60, European Cricket League` ও কাস্টম লিগ), সম্পূর্ণ Batting/Bowling/Fielding স্কোরকার্ড এবং `Source` ও `Last Updated` দেখানো হয়েছে।
- **Data Accuracy:** কোনো পরিসংখ্যান না থাকলে `0` না দেখিয়ে `Not Available` দেখানো হয়, এবং একই `Match ID` দ্বিতীয়বার যোগ করা হলে স্বয়ংক্রিয়ভাবে ব্লক হয়।
- **Career Records ও Comparison:** `CareerRecordsScreen` (এবং `Stats` ট্যাব) ও পাশাপাশি তুলনার জন্য `PlayerComparisonScreen` যুক্ত করা হয়েছে।
- **Admin Tools:** Android Photo Picker-সহ প্রোফাইল তৈরি/সম্পাদনা, ফরম্যাট/লিগ স্ট্যাট এডিটর, Match Logger, এবং JSON Import/Export যুক্ত হয়েছে।

### কীভাবে পরীক্ষা করবেন
1. **Teams -> View Players Module** বা **Stats -> Players** ট্যাব থেকে Players Hub খুলুন।
2. `+` বাটনে চাপ দিয়ে একজন খেলোয়াড় তৈরি করুন (ছবি, দেশ, জন্মতারিখ, বর্তমান/পূর্বের দল সহ), অথবা **Import JSON** ব্যবহার করুন।
3. প্রোফাইল পেজ থেকে ফরম্যাট ও লিগ ট্যাব পরিবর্তন করে **Add/Edit Stats** এবং **Log Match** (একই Match ID দুইবার দিয়ে ডুপ্লিকেট ব্লক) পরীক্ষা করুন।
4. অন্তত ২ জন খেলোয়াড় যোগ করে **Compare** ও **Career Records / Stats** ট্যাব পরীক্ষা করুন।

---

## [v0.1.1] - 2026-11-18 (Documentation Alignment)
### কী পরিবর্তন হয়েছে
- প্রজেক্টের জন্য ৫টি স্থায়ী লিভিং ডকুমেন্ট তৈরি করা হয়েছে (`CRICKET_ARENA_MASTER.md`, `PROJECT_STATUS.md`, `CHANGELOG.md`, `API_COVERAGE.md`, `DATA_BACKUP_GUIDE.md`)।

---

## [v0.1.0] - 2026-11-18 (Task 1: App Foundation & Home Dashboard)
### কী তৈরি হয়েছে
- Dark Green, Black ও White থিম, কাস্টম ফন্ট, কাস্টম লঞ্চার আইকন, রেসপন্সিভ Home Dashboard, ৫-ট্যাব Bottom Navigation এবং Room SQLite ভিত্তি।
